#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Optional

import pika
from pika import exceptions  # type: ignore[attr-defined]
import argparse
import logging
import sys


def setup_logger(log_stdout: bool, log_file: str = None):
    logger = logging.getLogger("RabbitMQConsumer")
    logger.setLevel(logging.INFO)

    formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')

    if log_stdout:
        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def consume_messages(host: str, port: int, username: str, password: str, queue_name: str, logger: logging.Logger):
    connection: Optional[pika.BlockingConnection] = None
    try:
        connection = pika.BlockingConnection(pika.ConnectionParameters(
            host=host, port=port, credentials=pika.PlainCredentials(username, password)
        ))
        channel = connection.channel()

        def callback(ch, method, properties, body):
            logger.info(f"Received: {body.decode('utf-8')}")

        channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=False)

        logger.info(f"Listening for messages on queue '{queue_name}'... Press Ctrl+C to exit.")
        channel.start_consuming()

    except pika.exceptions.AMQPConnectionError as e:
        logger.error(f"Connection error: {e}")
    except KeyboardInterrupt:
        logger.info("Stopped by user.")
    finally:
        try:
            connection.close()
            logger.info("Connection closed.")
        except Exception as e:
            logger.error(f"Error : {e}", exc_info=True)


def main():
    parser = argparse.ArgumentParser(description="RabbitMQ CLI Consumer Tool with Logging")
    parser.add_argument('--host', type=str, default='localhost', help='RabbitMQ host')
    parser.add_argument('--port', type=int, default=5672, help='RabbitMQ port')
    parser.add_argument('--username', type=str, required=True, help='RabbitMQ username')
    parser.add_argument('--password', type=str, required=True, help='RabbitMQ password')
    parser.add_argument('--queue', type=str, required=True, help='Queue name to consume from')
    parser.add_argument('--log-stdout', action='store_true', help='Enable logging to stdout')
    parser.add_argument('--log-file', type=str, help='Log messages to this file')

    args = parser.parse_args()

    logger = setup_logger(args.log_stdout, args.log_file)

    consume_messages(
        host=args.host,
        port=args.port,
        username=args.username,
        password=args.password,
        queue_name=args.queue,
        logger=logger
    )


if __name__ == '__main__':
    main()
