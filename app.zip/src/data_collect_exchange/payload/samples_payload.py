#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import logging
import os
from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, Field, field_validator

logger = logging.getLogger(__name__)


class RegisterValue(BaseModel):
    enQty: str = Field(..., description="Energy quantity or timestamp")
    attribute: int = Field(..., description="Attribute identifier")
    RegisterID: str = Field(..., description="Register identifier")


class Payload(BaseModel):
    dvcIdN: str = Field(..., description="Device ID Number")
    mobAppDataUniqueId: str = Field(..., description="Unique ID for the mobile app data")
    userId: str = Field(..., description="User's ID")
    dataSource: str = Field(..., description="Source of the data, e.g., OPTICALPORT/BLUETOOTH")
    remarks: Optional[str] = Field(None, description="Additional remarks or notes from the user")
    exportDTTM: datetime = Field(..., description="Export date and time")
    MeterDTTM: datetime = Field(..., description="Meter reading date and time")
    phase: str = Field(..., description="Phase information")
    profileCode: str = Field(..., description="Profile code for the meter reading")
    preVEE: List[RegisterValue] = Field(..., description="List of register values in the metering profile")

    @field_validator("dataSource")
    def validate_data_source(cls, value):
        valid_sources = {"OPTICALPORT", "BLUETOOTH"}
        if value not in valid_sources:
            raise ValueError(f"Invalid dataSource. Must be one of {valid_sources}.")
        return value

    @field_validator("profileCode")
    def validate_profile_code(cls, value):
        valid_codes = [code.strip() for code in os.environ.get('valid_obis', '').split(',')]
        logger.info(valid_codes)
        if value not in valid_codes:
            raise ValueError(f"Invalid profileCode. Must be one of {valid_codes}.")
        return value
