#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class RegisterValue(BaseModel):
    formattedRegisterObisCode: str = Field(..., description="OBIS code of the register")
    formattedValue: str = Field(..., description="Formatted value of the register")
    attributeId: int = Field(..., description="Attribute ID of the register")
    unit: int = Field(..., description="Unit of the register value")
    scalar: int = Field(..., description="Scalar value for the register")


class MeteringData(BaseModel):
    mobAppDataUniqueId: str = Field(..., description="Unique ID for the mobile app data")
    deviceId: str = Field(..., description="Device ID of the meter")
    formattedProfileObisCode: str = Field(..., description="Formatted OBIS code for the profile")
    registerValues: List[RegisterValue] = Field(..., description="List of register values for the meter")
    sampleTime: datetime = Field(..., description="Time of the sample data")
    sampleCaptureTime: datetime = Field(..., description="Time when the sample data was captured")
    userId: str = Field(..., description="User ID of the user")
    dataSource: str = Field(..., description="Source of the data, e.g., OPTICALPORT/BLUETOOTH")
    remarks: Optional[str] = Field(None, description="Additional remarks or notes from the user")

    @field_validator("formattedProfileObisCode")
    def validate_formatted_profile_obis_code(cls, value):
        valid_codes = [code.strip() for code in os.environ.get('valid_obis', '').split(',')]
        if len(valid_codes) == 0:
            raise ValueError("No valid formattedProfileObisCode found in environment variables.")
        if value not in valid_codes:
            raise ValueError(f"Invalid formattedProfileObisCode. Must be one of {valid_codes}.")
        if len(value) > 15:
            raise ValueError("formattedProfileObisCode length must not exceed 15 characters.")
        return value
