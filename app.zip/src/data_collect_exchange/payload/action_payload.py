#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class Payload(BaseModel):
    dvcIdN: str = Field(..., description="Device ID Number")
    phase: str = Field(..., description="Phase information")
    mobAppJobUniqueId: str = Field(..., description="Unique ID for the mobile app job")
    jobExecutionTime: datetime = Field(..., description="Execution time of the job")
    commandType: str = Field(..., description="Type of command issued")
    commandStatus: str = Field(..., description="Status of the command execution")
    failureStep: str = Field(..., description="Failure step identifier")
    progress: Optional[str] = Field(None, description="Progress status, if applicable")
    userId: str = Field(..., description="User's ID")
    dataSource: str = Field(..., description="Source of the data, e.g., OPTICALPORT/BLUETOOTH")
    remarks: Optional[str] = Field(None, description="Additional remarks or notes from the user")

    @field_validator("commandType")
    def validate_command_type(cls, value):
        valid_commands = {"CONNECT", "DISCONNECT"}
        if value not in valid_commands:
            raise ValueError(f"Invalid commandType. Must be one of {valid_commands}.")
        return value

    @field_validator("commandStatus")
    def validate_command_status(cls, value):
        valid_statuses = {"SUCCESS", "FAILED", "PENDING"}
        if value not in valid_statuses:
            raise ValueError(f"Invalid commandStatus. Must be one of {valid_statuses}.")
        return value

    @field_validator("failureStep")
    def validate_failure_step(cls, value):
        if not value.isdigit():
            raise ValueError("failureStep must be a string.")
        return value

    @field_validator("dataSource")
    def validate_data_source(cls, value):
        valid_sources = {"OPTICALPORT", "BLUETOOTH"}
        if value not in valid_sources:
            raise ValueError(f"Invalid dataSource. Must be one of {valid_sources}.")
        return value

