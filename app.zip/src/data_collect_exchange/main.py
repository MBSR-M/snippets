#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict

import uvicorn
from fastapi import FastAPI, Depends
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.security import HTTPBasicCredentials
from starlette.middleware.cors import CORSMiddleware

from data_collect_exchange.authentication import verify_api_key, verify_credentials
from data_collect_exchange.router.samples_route import data_router as router_probus_route
from data_collect_exchange.utils import parse_command_line, read_config, validate_config, configure_logging

logger = logging.getLogger(__name__)
app_version = str(os.environ.get('app_version'))
logger.info('Initializing app version: %s' % app_version)

# FastAPI app setup
app = FastAPI(title="Probus Data Collector API",
              version=app_version,
              openapi_url="/openapi.json")

# CORS middleware setup
app.add_middleware(
    CORSMiddleware,  # type: ignore
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui(credentials: HTTPBasicCredentials = Depends(verify_credentials)):
    openapi_url = "/openapi.json"
    return get_swagger_ui_html(openapi_url=openapi_url, title="Swagger UI")


@app.on_event("shutdown")
async def shutdown_event():
    logger.info(f"Shutting down Probus Data Collector API...")


@app.get("/", summary="Home", tags=["Home"])
async def root(api_key: str = Depends(verify_api_key)) -> Dict[str, Any]:
    logger.debug("Root endpoint accessed")
    return {"message": f"Welcome to Probus Data Collector API!", "status": "healthy",
            "version": app_version}


@app.get("/health", summary="Health Check", tags=["Utilities"])
def health_check(api_key: str = Depends(verify_api_key)) -> Dict[str, Any]:
    """
    Endpoint to check the health of the API with API key authentication.
    """
    return {
        "status": "healthy",
        "version": app_version,
        "success": True,
    }


def start_uvicorn(ip_address: str, port: int, workers: int) -> None:
    """
    Starts the Uvicorn server with the specified configuration.
    """
    try:
        logger.info(f"Starting Uvicorn with host={ip_address}, port={port}, workers={workers}")
        uvicorn.run(
            "data_collect_exchange.main:app",
            host=ip_address,
            port=int(port),
            workers=int(workers)
        )
    except Exception as e:
        logger.error("Unexpected error while starting Uvicorn: %s", e)
        sys.exit(1)


def start_gunicorn(ip_address: str, port: int, workers: int, path: Path) -> None:
    """
    Starts the Gunicorn server with Uvicorn workers and specified configuration.
    """

    venv_python = sys.executable  # Ensure correct virtual environment

    try:
        # Install dependencies if not already installed
        subprocess.run([venv_python, "-m", "pip", "install", "gunicorn", "uvicorn"], check=True)

        # Log the starting configuration
        logger.info(f"Starting Gunicorn with Uvicorn workers: host={ip_address}, port={port}, workers={workers}")

        # Validate input parameters
        if not ip_address or not isinstance(ip_address, str):
            raise ValueError("Invalid IP address provided.")
        if not isinstance(port, int) or port <= 0:
            raise ValueError(f"Invalid port: {port}. Must be a positive integer.")
        if not isinstance(workers, int) or workers <= 0:
            raise ValueError(f"Invalid worker count: {workers}. Must be a positive integer.")

        # Construct Gunicorn command
        command = [
            venv_python, "-m", "gunicorn",  # Ensure using correct Python environment
            "-k", "uvicorn.workers.UvicornWorker",
            "-w", str(workers),
            "-b", f"{ip_address}:{port}",
            "data_collect_exchange.main:app",
            "--timeout", "60",
            "--access-logfile", str(path),
            "--error-logfile", str(path),
            "--log-level", "info",
            "--capture-output"
        ]

        # Run Gunicorn process
        result = subprocess.run(command, capture_output=True, text=True, check=True)

        # Log Gunicorn output
        logger.info("Gunicorn started successfully.")
        logger.debug("Gunicorn Output: %s", result.stdout)

    except ValueError as ve:
        logger.error("Validation error: %s", ve)
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        logger.error("Error while starting Gunicorn: %s", e.stderr)
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error while starting Gunicorn: %s", str(e))
        sys.exit(1)


# Include the Probus data route
app.include_router(router_probus_route)


def main() -> None:
    """
    Main function to parse arguments, configure the application, and start the server.
    """
    args = parse_command_line()

    try:
        os.environ.setdefault("config_file", args.config_file)
        cfg = read_config(args.config_file)
        validate_config(cfg)
        app_config = cfg["probus_config"]
        ip_address = app_config["ip_address"]
        port = app_config["port"]
        workers = app_config["workers"]
        valid_obis = app_config["valid_obis"]

        valid_username = app_config["valid_username"]
        valid_password = app_config["valid_password"]
        valid_api_key = app_config["valid_api_key"]

        os.environ.setdefault("app_version", app_config["app_version"])
        os.environ.setdefault("valid_username", valid_username)
        os.environ.setdefault("valid_password", valid_password)
        os.environ.setdefault("valid_api_key", valid_api_key)
        os.environ.setdefault("valid_obis", valid_obis)
        # Logging configuration
        configure_logging(Path(args.log_file), args.log_file_retention_days, args.debug)
        if platform.system() == "Windows":
            logger.info("Windows detected: Using Uvicorn directly.")
            start_uvicorn(ip_address, port, workers)
        else:
            logger.info("Linux detected: Using Gunicorn.")
            start_gunicorn(ip_address=ip_address, port=int(port), workers=int(workers), path=Path(args.log_file))
    except (KeyError, ValueError) as e:
        logger.error("Configuration error: %s", e)
        sys.exit(1)
    except Exception as e:
        logger.exception("Unexpected error: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
