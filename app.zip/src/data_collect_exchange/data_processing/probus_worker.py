#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import logging
import os
from typing import List, Union, Dict

import pika
from pika import exceptions  # type: ignore[attr-defined]
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from data_collect_exchange.kafka_client import KafkaConfig, RabbitMQConfig
from data_collect_exchange.kafka_client.consumer_client import KafkaConsumerClient
from data_collect_exchange.kafka_client.producer_client import KafkaProducerClient
from data_collect_exchange.utils import read_config, parse_bool

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class KafkaProcessor:
    def __init__(self, topic_key: str):
        self.topic_key = topic_key
        self.config_file_path = os.environ.get('config_file')
        if not self.config_file_path:
            raise ValueError("Missing 'config_file' environment variable.")
        self.__cfg = read_config(self.config_file_path)
        self.topic_group_id = self._get_group_id()
        self.kafka_conf = KafkaConfig(
            bootstrap_servers=self.__cfg['kafka']['bootstrap_servers'],
            ssl_check_hostname=parse_bool(self.__cfg['kafka']['ssl_check_hostname']),
            username=self.__cfg['kafka']['user'],
            password=self.__cfg['kafka']['password'],
            cafile=self.__cfg['kafka']['cafile'],
            topic=self.__cfg['kafka'][self.topic_key],
            topic_group_id=self.topic_group_id,
            topic_partitions=int(self.__cfg['kafka']['topic_partitions']),
            topic_replication_factor=int(self.__cfg['kafka']['topic_replication_factor']),
            topic_retention_ms=int(self.__cfg['kafka']['topic_retention_ms']),
            flush_timeout_s=float(self.__cfg['kafka']['flush_timeout_s']),
        )

        self.producer = KafkaProducerClient(self.kafka_conf)
        self.kafka_consumer = KafkaConsumerClient(self.kafka_conf)
        self.rmq_conf = RabbitMQConfig(
            host=self.__cfg['rabbitmq_queue_config']['host'],
            port=int(self.__cfg['rabbitmq_queue_config']['port']),
            queue_name=self.__cfg['rabbitmq_queue_config']['queue'],
            exchange_name=self.__cfg['rabbitmq_queue_config']['exchange'],
            username=self.__cfg['rabbitmq']['username'],
            password=self.__cfg['rabbitmq']['password'],
        )

    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=1, max=10),
           retry=retry_if_exception_type(Exception))
    def send_messages(self, messages: List[dict]) -> bool:
        for message in messages:
            self.producer.send_message(message)
            self.forward_messages()
        return True

    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=1, max=10),
           retry=retry_if_exception_type(pika.exceptions.AMQPError))
    def send_to_rabbitmq(self, message: Union[str, Dict]):
        headers = {
            "header-1": "header-1-value",
            "header-2": "header-2-value",
            "header-3": "header-3-value",
        }
        if isinstance(message, dict):
            message = json.dumps(message)
        if isinstance(message, str):
            message = message.encode('utf-8')

        connection = pika.BlockingConnection(pika.ConnectionParameters(
            host=self.rmq_conf.get_host(),
            port=self.rmq_conf.get_port(),
            credentials=pika.PlainCredentials(self.rmq_conf.get_username(),
                                              self.rmq_conf.get_password()),
        ))
        try:
            channel = connection.channel()
            channel.exchange_declare(
                exchange=self.rmq_conf.get_exchange_name(),
                exchange_type='direct',
                durable=True,
            )

            channel.basic_publish(
                exchange=self.rmq_conf.get_exchange_name(),
                routing_key=self.rmq_conf.get_queue_name(),
                body=message,
                properties=pika.BasicProperties(
                    delivery_mode=2,
                    headers=headers
                )
            )

            logger.info("Message forwarded to RabbitMQ.")
        finally:
            connection.close()

    def forward_messages(self):
        logger.info("Starting Kafka to RabbitMQ message forwarding...")
        try:
            for message in self.kafka_consumer.consumer:
                kafka_message = message.value
                logger.info(f"Received Kafka message: {kafka_message}")
                try:
                    self.send_to_rabbitmq(kafka_message)
                    self.kafka_consumer.consumer.commit()
                    logger.info("Kafka offset committed.")
                except Exception as e:
                    logger.error(f"Failed to forward message to RabbitMQ: {e}")
                    raise
        except KeyboardInterrupt:
            logger.warning("Interrupted by user.")
        except Exception as e:
            logger.exception(f"Unhandled exception during forwarding.: {e}")
        finally:
            self.cleanup()

    def cleanup(self):
        try:
            if self.kafka_consumer:
                self.kafka_consumer.close()
                logger.info("Kafka consumer closed.")
        except Exception as e:
            logger.error(f"Failed to close Kafka consumer: {e}")

    def _get_group_id(self) -> str:
        if self.topic_key == 'topic_meter_action':
            return self.__cfg['kafka']['topic_group_id_meter_action']
        elif self.topic_key == 'topic_meter_sample':
            return self.__cfg['kafka']['topic_group_id_meter_sample']
        else:
            raise ValueError(f"Unknown topic key: {self.topic_key}")


def process_meter_data(processed_data: List[List[dict]], topic_key: str, batch_size=50):
    processor = KafkaProcessor(topic_key)
    for batch in processed_data:
        for i in range(0, len(batch), batch_size):
            sub_batch = batch[i:i + batch_size]
            processor.send_messages(sub_batch)


def process_meter_sample_data(processed_data: List[List[dict]]):
    process_meter_data(processed_data, 'topic_meter_sample')


def process_meter_action_data(processed_data: List[dict]):
    process_mrt_action_data(processed_data, 'topic_meter_action')


def process_mrt_action_data(processed_data: List[dict], topic_key: str, batch_size=50):
    processor = KafkaProcessor(topic_key)
    for i in range(0, len(processed_data), batch_size):
        batch = processed_data[i:i + batch_size]
        processor.send_messages(batch)
