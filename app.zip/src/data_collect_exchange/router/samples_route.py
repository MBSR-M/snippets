#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import uuid
from typing import List

from fastapi import APIRouter, status, Depends, BackgroundTasks
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBasicCredentials

from data_collect_exchange.authentication import security, apikey_header, authenticate
from data_collect_exchange.data_processing.probus_worker import process_meter_action_data, process_meter_sample_data
from data_collect_exchange.payload.action_payload import Payload as MeterActionPayload
from data_collect_exchange.payload.samples_payload import Payload as MeterSamplePayload

# Initialize logger
logger = logging.getLogger(__name__)

# Create a router for data-related endpoints
data_router = APIRouter(prefix="/mobApp/data/collect", tags=["Data Collection"])


@data_router.post("/meter-samples", summary="Collect Metering Data", status_code=status.HTTP_201_CREATED)
async def collect_data(background_tasks: BackgroundTasks, data: List[MeterSamplePayload],
                       credentials: HTTPBasicCredentials = Depends(security),
                       api_key: str = Depends(apikey_header)):
    """
    Endpoint to collect metering data from Probus.
    This will validate and save the incoming data payload.
    """
    try:
        authenticate(credentials, api_key)
        unique_job_id = uuid.uuid4()
        processed_data_list = []
        for sample in data:
            processed_sample = sample.dict()  # Convert each item to a dictionary
            processed_sample["exportDTTM"] = sample.exportDTTM.strftime("%Y-%m-%dT%H:%M:%S")
            processed_sample["MeterDTTM"] = sample.MeterDTTM.strftime("%Y-%m-%dT%H:%M:%S")
            processed_data_list.append(processed_sample)
        background_tasks.add_task(process_meter_sample_data, [processed_data_list])
        logger.info("Data processed in background tasks")
        return JSONResponse(
            status_code=status.HTTP_201_CREATED,
            content={
                "message": "Data collected successfully",
                "success": True,
                "status_code": status.HTTP_201_CREATED
            },
        )
    except ValueError as ve:
        logger.warning("Validation error: %s", str(ve))
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"message": f"Validation error: {str(ve)}",
                     "success": False,
                     "status_code": status.HTTP_400_BAD_REQUEST},
        )
    except Exception as e:
        logger.error("An unexpected error occurred: %s", str(e))
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "An unexpected error occurred. Please try again later.",
                     "success": False,
                     "status_code": status.HTTP_500_INTERNAL_SERVER_ERROR},
        )


@data_router.post("/meter-action", summary="Collect Metering Data", status_code=status.HTTP_201_CREATED)
async def collect_data(background_tasks: BackgroundTasks, data: MeterActionPayload,
                       credentials: HTTPBasicCredentials = Depends(security),
                       api_key: str = Depends(apikey_header)):
    """
    Endpoint to collect metering data from Probus.
    This will validate and save the incoming data payload.
    """
    try:
        authenticate(credentials, api_key)
        unique_job_id = uuid.uuid4()
        processed_data = data.dict()
        processed_data["jobExecutionTime"] = data.jobExecutionTime.strftime("%Y-%m-%dT%H:%M:%S")
        background_tasks.add_task(process_meter_action_data, [processed_data])
        logger.info("Data processed in background tasks")
        return JSONResponse(
            status_code=status.HTTP_201_CREATED,
            content={
                "message": "Data collected successfully",
                "success": True,
                "status_code": status.HTTP_201_CREATED
            },
        )
    except ValueError as ve:
        logger.warning("Validation error: %s", str(ve))
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"message": f"Validation error: {str(ve)}",
                     "success": False,
                     "status_code": status.HTTP_400_BAD_REQUEST},
        )
    except Exception as e:
        logger.error("An unexpected error occurred: %s", str(e))
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": "An unexpected error occurred. Please try again later.",
                     "success": False,
                     "status_code": status.HTTP_500_INTERNAL_SERVER_ERROR},
        )
