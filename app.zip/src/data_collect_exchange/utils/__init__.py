#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import configparser
import functools
import logging
import logging.handlers
import os
import time

from pathlib import Path
from typing import Callable

# Initialize logger
logger = logging.getLogger(__name__)


def configure_logging(log_file: Path, retention_days: int, debug: bool) -> None:
    """
    Configures application logging with a timed rotating file handler.
    """
    log_level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        format="%(asctime)s  %(levelname)-5s  %(message)s",
        level=log_level,
    )

    if retention_days < 1:
        logging.warning("Log retention days should be at least 1. Setting to default value of 7.")
        retention_days = 7

    file_handler = logging.handlers.TimedRotatingFileHandler(
        log_file, when="midnight", backupCount=retention_days
    )
    file_handler.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-5s  %(message)s"))
    logging.getLogger().addHandler(file_handler)


def read_config(config_file):
    # read configuration file
    cfg = configparser.ConfigParser()
    cfg.read(config_file)

    # apply defaults
    for sec, key, envkey, default_val in (
            ("probus_config", "valid_username", "valid_username", "Probus_Mubashir2025"),
            ("probus_config", "valid_password", "valid_password", "df0Uwcr5R_Fu8phjUifduQ"),
            ("probus_config", "valid_api_key", "valid_api_key", "vgoJCA3N1yIsQvEsivu-fm8RcaJj0q8fYtEIcpSnSbU"),
            ("probus_config", "ip_address", "IP_ADDRESS", "127.0.0.1"),
            ("probus_config", "port", "PORT", "8000"),
            ("probus_config", "workers", "WORKERS", "4"),
            ("probus_config", "valid_obis", "VALID_OBIS", "1.0.94.91.0.255,1.0.94.91.0.253,1.0.94.91.0.256"),
            ("probus_config", "app_version", "APP_VERSION", "0.0.0.0"),
            ('kafka', 'user', 'KAFKA_USER', ''),
            ('kafka', 'password', 'KAFKA_PASSWORD', ''),
            ('kafka', 'cafile', 'KAFKA_CA_CRT', ''),
            ('kafka', 'bootstrap_servers', 'KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092'),
            ('kafka', 'ssl_check_hostname', 'KAFKA_SSL_CHECK_HOSTNAME', 'true'),
            ('kafka', 'topic_meter_sample', 'topic_meter_sample', 'topic-probus-meter-sample'),
            ('kafka', 'topic_meter_action', 'topic_meter_action', 'topic-probus-meter-action'),
            ('kafka', 'topic_partitions', 'KAFKA_TOPIC_PARTITIONS', '1'),
            ('kafka', 'topic_replication_factor', 'KAFKA_TOPIC_REPLICATION_FACTOR', '1'),
            ('kafka', 'topic_retention_ms', 'KAFKA_TOPIC_RETENTION_MS', '15552000000'),
            ('kafka', 'flush_timeout_s', 'KAFKA_FLUSH_TIMEOUT_S', '60.0'),
            ('rabbitmq', 'username', 'username', 'default-rmq-queue'),
            ('rabbitmq', 'password', 'password', 'default-rmq-queue'),
            ('rabbitmq_queue_config', 'queue', 'RABBITMQ_QUEUE', 'default-rmq-queue'),
            ('rabbitmq_queue_config', 'host', 'RABBITMQ_HOST', 'localhost'),
            ('rabbitmq_queue_config', 'retry_attempts', 'RABBITMQ_RETRY_ATTEMPTS', '20'),
    ):
        if sec not in cfg:
            cfg[sec] = {}
        if key not in cfg[sec]:
            cfg[sec][key] = os.environ.get(envkey, default_val)
    return cfg


def parse_command_line():
    """Parse command line."""
    # build command line parser
    arg_parser = argparse.ArgumentParser(
        description='Probus data collector application',
    )
    arg_parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable logging a debug level and above',
    )
    arg_parser.add_argument(
        '--log-file',
        default='probus-data-collector.log',
        help='Log file',
    )
    arg_parser.add_argument(
        "--log-file-retention-days",
        type=int,
        default=180,
        help="Log file retention (days)",
    )
    arg_parser.add_argument(
        '--config-file',
        default='probus-data-collector.conf',
        help='Configuration file',
    )
    args = arg_parser.parse_args()
    return args


def validate_config(config: configparser.ConfigParser) -> None:
    """
    Validates the configuration settings to ensure they meet expected criteria.
    Assumes `config` is a ConfigParser object.
    """
    # Access the "app_config" section from ConfigParser
    if not config.has_section("probus_config"):
        raise ValueError("Missing 'app_config' section in the configuration.")

    app_config = dict(config.items("probus_config"))

    # Validate IP, port, and workers
    ip_address = app_config.get("ip_address", "127.0.0.1")
    try:
        port = int(app_config.get("port", 8000))
    except ValueError:
        raise ValueError(f"Invalid port number: {app_config.get('port')}. Port must be an integer.")

    try:
        workers = int(app_config.get("workers", 1))
    except ValueError:
        raise ValueError(f"Invalid workers value: {app_config.get('workers')}. Workers must be an integer.")

    # Your existing validation logic...
    if not (0 < port < 65536):
        raise ValueError(f"Invalid port number: {port}. Port must be between 1 and 65535.")

    if workers < 1:
        raise ValueError("Workers must be at least 1.")

    if not isinstance(ip_address, str) or not ip_address:
        raise ValueError("Invalid IP address. It should be a non-empty string.")

    # Ensure critical keys are present
    for key in ["valid_username", "valid_password", "valid_api_key", "valid_obis"]:
        if key not in app_config:
            raise ValueError(f"Missing required configuration key: {key}")

    logger.info("Configuration validated successfully.")


def incremental_backoff(retries):
    if retries == 0:
        return 0
    elif retries == 1:
        return 1
    else:
        backoff = [0, 1]
        for _ in range(2, retries + 1):
            backoff.append(backoff[-1] + backoff[-2])
        return backoff[-1]


def retry_with_incremental_backoff(max_retries: int = 5, initial_delay: float = 1.0, max_delay: float = 16.0,
                                   backoff_factor: float = 2.0):
    """
    Retry decorator with incremental backoff.

    :param max_retries: Maximum number of retries before giving up.
    :param initial_delay: Initial delay between retries in seconds.
    :param max_delay: Maximum delay between retries in seconds.
    :param backoff_factor: The factor by which to multiply the delay for each subsequent retry.
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            attempt = 0
            delay = initial_delay
            while attempt < max_retries:
                try:
                    return func(*args, **kwargs)  # Try to run the function
                except Exception as e:
                    attempt += 1
                    if attempt >= max_retries:
                        logger.error(f"Max retries reached. Function failed with error: {e}")
                        raise  # Re-raise the exception after max retries
                    logger.warning(f"Attempt {attempt} failed. Retrying in {delay:.2f} seconds...")
                    time.sleep(delay)
                    delay = min(delay * backoff_factor,
                                max_delay)  # Incremental backoff, ensuring it doesn't exceed max_delay

        return wrapper

    return decorator


def parse_bool(s):
    return s.lower() in ('true', 't', '1', 'y', 'yes')


def retry_on_failure(max_retries=35, base_delay=2):
    def decorator(func: Callable):
        def wrapper(*args, **kwargs):
            attempt = 0
            while attempt < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempt += 1
                    wait_time = base_delay ** attempt  # Exponential backoff
                    logger.error(f"Function {func.__name__} failed (attempt {attempt}/{max_retries}): {e}")
                    logger.info(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
            logger.critical(f"Max retries reached. Function {func.__name__} failed.")
            return False

        return wrapper

    return decorator
