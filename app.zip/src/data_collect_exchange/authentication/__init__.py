#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import os
from hmac import compare_digest

from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBasic, HTTPBasicCredentials, APIKeyHeader
from secrets import compare_digest

# Initialize logger
logger = logging.getLogger(__name__)
# Security definitions
security = HTTPBasic()
apikey_header = APIKeyHeader(name="X-API-Key")

valid_username = os.environ.get('valid_username')
valid_password = os.environ.get('valid_password')
valid_api_key = os.environ.get('valid_api_key')
USERNAME = os.environ.get('USERNAME', 'admin')
PASSWORD = os.environ.get('PASSWORD', 'admin')


def verify_api_key(api_key: str = Depends(apikey_header)) -> str:
    """
    Verify the provided API key by comparing with the stored valid API key.
    """
    if api_key != valid_api_key:
        raise HTTPException(status_code=401, detail="Invalid API Key")
    return api_key


def authenticate(credentials: HTTPBasicCredentials = Depends(security), api_key: str = Depends(apikey_header)):
    if not compare_digest(credentials.username, valid_username) or not compare_digest(credentials.password,
                                                                                      valid_password):
        logger.warning("Invalid username or password")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
            headers={"WWW-Authenticate": "Basic"},
        )

    if not compare_digest(api_key, valid_api_key):
        logger.warning("Invalid API key")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid API key",
        )

    logger.info("Authentication successful")


def verify_credentials(credentials: HTTPBasicCredentials = Depends(security)):
    if credentials.username != USERNAME or compare_digest(credentials.password, PASSWORD):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
