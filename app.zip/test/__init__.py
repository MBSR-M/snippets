# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-
#
# import logging
# import sys
# from typing import Optional
#
# import pika
# from pika import exceptions  # type: ignore[attr-defined]
#
# logger = logging.getLogger("RabbitMQConsumer")
# logger.setLevel(logging.INFO)
# formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
# stream_handler = logging.StreamHandler(sys.stdout)
# stream_handler.setFormatter(formatter)
# logger.addHandler(stream_handler)
#
#
# def consume_messages(host: str, port: int, username: str, password: str, queue_name: str):
#     connection: Optional[pika.BlockingConnection] = None
#     try:
#         connection = pika.BlockingConnection(pika.ConnectionParameters(
#             host=host, port=port, credentials=pika.PlainCredentials(username, password), virtual_host='MDM_H1_v1'
#         ))
#         logger.info(f"USER : {username}, PASSWORD : {password}")
#         logger.info(f"HOST : {host}, PORT : {port}, QUEUE : {queue_name}")
#         channel = connection.channel()
#
#         def callback(ch, method, properties, body):
#             logger.info(f"Received: {body.decode('utf-8')}")
#
#         channel.queue_declare(queue=queue_name, durable=True)
#         channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=False)
#
#         logger.info(f"Listening for messages on queue '{queue_name}'... Press Ctrl+C to exit.")
#         channel.start_consuming()
#
#     except pika.exceptions.AMQPConnectionError as e:
#         logger.error(f"Connection error: {e}")
#     except KeyboardInterrupt:
#         logger.info("Stopped by user.")
#
#
# def main():
#     log_stdout = True
#     consume_messages(
#         host='20.193.245.243',
#         port=5672,
#         username='hes_cyan',
#         password='cyan123',
#         queue_name="my_routing_key"
#     )
#
#
# if __name__ == '__main__':
#     main()
import pika

try:
    credentials = pika.PlainCredentials('hes_cyan', 'cyan123')
    parameters = pika.ConnectionParameters(
        host='20.193.245.243',
        port=5672,
        virtual_host='MDM_H1_v1',
        credentials=credentials
    )
    connection = pika.BlockingConnection(parameters)
    print("✅ Successfully connected to RabbitMQ")
    connection.close()
except Exception as e:
    print(f"❌ Failed to connect: {e}")
