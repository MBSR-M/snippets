#!/usr/bin/env python3
# coding=utf-8

from unittest.mock import patch, MagicMock
import pytest
from fastapi.testclient import TestClient

from data_collect_exchange.main import app


@pytest.fixture
def client():
    client = TestClient(app)
    yield client


@patch("fastapi.testclient.TestClient.get")
@patch("data_collect_exchange.authentication.verify_api_key", return_value=True)
def test_health_check(mock_verify_api_key, mock_get, client):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "status": "healthy",
        "success": True,
        "version": "1.0.0"
    }
    mock_get.return_value = mock_response
    response = client.get("/health", params={"api_key": "mocked-api-key"})
    assert response.status_code == 200
    json_response = response.json()
    assert json_response["status"] == "healthy"
    assert json_response["success"] is True
    assert json_response["version"] == "1.0.0"
