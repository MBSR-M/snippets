#!/usr/bin/env python3
# coding=utf-8

import datetime
import setuptools


def get_version():
    """Retrieve version from _version.py, or generate a timestamp if not found."""
    try:
        with open('_version.py') as file_:
            for line in file_:
                if line.startswith('__version__'):
                    return line.split('=')[1].strip().strip("'")
    except FileNotFoundError:
        pass
    return datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')


setuptools.setup(
    name='probusdatacollector',
    version=get_version(),
    author='CyanConnode System Integration',
    author_email='si@cyanconnode.com',
    description='Probus meter data collector application',
    license='Other/Proprietary License',
    packages=setuptools.find_packages(where='src'),
    package_dir={'': 'src'},
    package_data={'': ['*.json', '*.yml', '*.conf']},
    include_package_data=True,
    install_requires=[
        'kafka-python',
        'pika',
        'python-dateutil',
        'requests',
        'pytz',
        'openpyxl',
        'pandas',
        'XlsxWriter',
        'cryptography',
        'tzlocal',
        'fastapi[all]',
        'tenacity',
        'uvicorn',
        'gunicorn',
        'pydantic[email]',
    ],
    extras_require={
        'test': ['pytest', 'pytest-cov'],
    },
    entry_points={
        'console_scripts': [
            'probus-collect-data=data_collect_exchange.main:main',
        ],
    },
)
