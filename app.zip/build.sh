#!/bin/bash -xe

version=${CI_PIPELINE_ID:-$(date -u +%Y%m%d%H%M%S)}
echo -en '# -*- mode: python; coding: utf-8; -*-\n__version__ = '\'"$version"\''\n' > _version.py
CA_VERSION=$version
export CA_VERSION
ca init '>=8'

ca docker_pull baseimages/rcdcdashrep_ubuntu_2004_amd64

KAFKA_IMAGE=bitnami/kafka:3.7.0
ca docker_pull $KAFKA_IMAGE

chmod +x ./run-with-kafka
chmod +x ./make.sh
chmod +x ./setup.py

ca build --buildenv baseimages/rcdcdashrep_ubuntu_2004_amd64 --cmd "KAFKA_IMAGE=$KAFKA_IMAGE ./run-with-kafka ./make.sh"
ls -l dist/
ca publish dist/probusdatacollector-"${CA_VERSION}"-py3-none-any.whl,metadata
