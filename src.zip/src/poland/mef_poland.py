import calendar
from datetime import datetime

from loguru import logger
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

from src.tariff_processing import TariffProcessing, _get_tariff_json
from utils import mapping_wb_path, currency_code_dict


def get_row_column_range(mef_sheet, plant):
    try:
        column = 'C' if plant == "A471" else 'B'
        sheet_col = mef_sheet[column]

        start_row, end_row = 0, 0
        for cell in sheet_col:
            if cell.value == 'Actuals + forecast':
                start_row = cell.row
            elif cell.value == 'COSTS EUR':
                end_row = cell.row
        return start_row, end_row
    except Exception as e:
        logger.exception(f'Error in get_row_column_range: {e}')


def get_row_column_range_non_volume(mef_sheet, plant, year):
    try:
        column = 'E' if plant == "A471" else 'D'
        column2 = 'D' if plant == "A471" else 'C'
        # print(sheet_col)

        initial_row = 0
        for cell in mef_sheet[column]:
            if cell.value == 'ACTUAL Current Year EUR':
                row = cell.row
                if mef_sheet[f'{column2}{row}'].value == f'FCST{year}':
                    initial_row = row
                    # print(initial_row)
                    break
        start_row, end_row = 0, 0
        for idx in range(initial_row, mef_sheet.max_row + 1):
            cell_value = mef_sheet[f'{column}{idx}'].value
            if cell_value == 'TOTAL':
                start_row = idx
            elif cell_value == 'TOTAL INVOICE':
                end_row = idx
                break

        return start_row, end_row

    except Exception as e:
        logger.exception(f'Error in get_row_column_range_non_volume: {e}')


def get_value_from_formulas(vals, input_sheet_food, input_sheet_hpc):
    try:
        if vals is None:
            return 0

        if len(vals) < 18:
            if 'FOOD' in vals:
                val_split = vals.split('!')
                return input_sheet_food[val_split[-1]].value
            elif 'HPC' in vals:
                val_split = vals.split('!')
                return input_sheet_hpc[val_split[-1]].value

        if 'FOOD' in vals and 'HPC' in vals:
            val_split = vals.split('+')
            food_val = input_sheet_food[val_split[0].split('!')[-1]].value or 0
            hpc_val = input_sheet_hpc[val_split[1].split('!')[-1]].value or 0
            return food_val + hpc_val

        return 0
    except Exception as e:
        logger.exception(f'Error in get_value_from_formulas: {e}')


def get_item_description(value, ws):
    value = ws[value[1:]].value
    if value[0] == '=':
        return get_item_description(value, ws)
    else:
        return value


def get_values_from_input_sheet(start_row, end_row, input_sheet, mef_sheet, plant, mapping_ws,
                                input_received_date, total_calendar_days_in_a_month, input_sheet_food=None,
                                input_sheet_hpc=None):
    out_dict = {}
    calculation_dict = {
        'old_volume': 'compute_val',
        'old_value': 'compute_val * tariff'
    }
    try:
        # start_row, end_row = get_row_column_range(mef_sheet, plant)

        for data in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value = data[4].value if plant == "A471" else data[3].value
            if value is None:
                continue

            if '=' in value:
                value = get_item_description(value, mef_sheet)
                if value is None:
                    continue

            for row in mapping_ws.iter_rows(min_row=mapping_ws.min_row, max_row=mapping_ws.max_row):
                if row[1].value == plant and value == row[3].value:
                    # print(value)
                    calculation_logic = row[11].value
                    calculation_logic_parts = calculation_logic.split("=")
                    logic = calculation_logic_parts[-1].split()
                    # print(logic)
                    calculation_logic_expression = calculation_logic_parts[-1]
                    # print(calculation_logic_expression)

                    driver_1_2_condition = row[10].value
                    driver_1_2_condition = driver_1_2_condition.split('&')
                    # print(driver_1_2_condition)

                    adjustment_rate = row[8].value
                    # print(adjustment_rate, type(adjustment_rate))
                    if type(adjustment_rate) in [int, float]:
                        adjustment_rate += 1
                    # print(adjustment_rate)
                    row_map_val = row[3].row
                    map_value = mapping_ws.cell(row=row_map_val, column=3).value

                    if map_value is None:
                        out_dict[value] = 0
                        continue

                    for row_data in input_sheet.iter_rows(min_row=input_sheet.min_row,
                                                          max_row=input_sheet.max_row):
                        if map_value == row_data[6].value:
                            r = row_data[6].row
                            tariff = input_sheet.cell(row=r, column=9).value
                            compute_val = input_sheet.cell(row=r, column=8).value
                            if compute_val is not None and tariff is not None:
                                if isinstance(compute_val, int) or isinstance(compute_val,
                                                                              float) and compute_val != 0:
                                    for item in logic:
                                        if item in calculation_dict.keys():
                                            calculation_logic_expression = calculation_logic_expression.replace(
                                                item, calculation_dict[item])
                                    for item in driver_1_2_condition:
                                        item = item.split('=')
                                        calculation_logic_expression = calculation_logic_expression.replace(
                                            item[0], item[1]) if item[
                                                                     0] in calculation_logic_expression else calculation_logic_expression
                                    # print(calculation_logic_expression)
                                    computed_value = round(eval(calculation_logic_expression), 7)
                                elif isinstance(compute_val, str) and '=' in compute_val:
                                    compute_val = get_value_from_formulas(compute_val, input_sheet_food,
                                                                          input_sheet_hpc)
                                    for item in logic:
                                        if item in calculation_dict.keys():
                                            calculation_logic_expression = calculation_logic_expression.replace(
                                                item, calculation_dict[item])
                                    for item in driver_1_2_condition:
                                        item = item.split('=')
                                        calculation_logic_expression = calculation_logic_expression.replace(
                                            item[0], item[1]) if item[
                                                                     0] in calculation_logic_expression else calculation_logic_expression
                                    computed_value = round(eval(calculation_logic_expression), 7)
                                else:
                                    computed_value = 0
                            else:
                                computed_value = 0
                            out_dict[value] = computed_value if value not in out_dict.keys() else out_dict[
                                                                                                      value] + computed_value
        return out_dict
    except Exception as e:
        logger.exception(f'Error in get_values_from_input_sheet: {e}')


def get_input_data_column(mef_sheet, month, initial_row=2):
    try:
        def get_column_value(value):
            cell_value = value.strip('=')
            # logger.info(cell_value)
            split_cell = cell_value.split('+')
            # logger.info(split_cell)
            index_value = mef_sheet[split_cell[0]].value
            if isinstance(index_value, str):
                return get_column_value(index_value) + int(split_cell[-1])
            elif isinstance(index_value, int):
                return index_value + int(split_cell[-1])

        for row in mef_sheet.iter_rows(min_row=initial_row, max_row=initial_row):
            for cell in row:
                value = cell.value
                if value is None:
                    continue
                elif isinstance(value, str):
                    if value[0] == '=':
                        value = get_column_value(value)

                if value == month:
                    target_column = cell.column
        return target_column
    except Exception as e:
        logger.exception(f'Error in get_input_data_column: {e}')


def update_mef_sheet(plant, tariff_dict, check_to_update_tariff, mef_sheet, start_row, end_row, column_index,
                     output_dict, target_column, tariff_sheet, input_date):
    try:
        for row in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value_cell = row[column_index]
            if value_cell.value is None:
                continue
            value = mef_sheet[value_cell.value[1:]].value if value_cell.value[0] == '=' else value_cell.value
            if value in output_dict and output_dict[value] != 0:
                mef_sheet.cell(
                    row=value_cell.row, column=target_column, value=output_dict[value])
                mef_sheet.cell(
                    row=value_cell.row, column=target_column).number_format = '0.00'
                mef_sheet.cell(row=value_cell.row, column=target_column).alignment = Alignment(horizontal='right')
        # if check_to_update_tariff: # TODO: add check_to_update_tariff
        try:
            logger.info(f"Updating tariff target in MEF sheet for plant : {plant} ...")
            tariff_processing = TariffProcessing(mef_sheet=mef_sheet, new_tariff=tariff_dict, mapping_wb=mapping_wb_path,
                                                 plant=plant, tariff_sheet=tariff_sheet, input_date=input_date)
            tariff_processing.update_tariffs_in_mef_sheet()
            tariff_processing.set_tariff_sheet()
            tariff_processing.apply_tariff_calculation_method()
        except Exception as exception:
            logger.error(f"Error updating tariff target: {exception}", exc_info=True)
    except Exception as e:
        logger.exception(f'Error in update_mef_sheet: {e}', exc_info=True)


def update_mef_sheet_non_volume(mef_sheet, start_row, end_row, column_index, output_dict, target_column, forex_rate):
    try:
        for row in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value_cell = row[column_index]
            if value_cell.value is None:
                continue
            value = mef_sheet[value_cell.value[1:]].value if value_cell.value[0] == '=' else value_cell.value
            if value in output_dict and output_dict[value] != 0:
                mef_sheet.cell(
                    row=value_cell.row, column=target_column, value=output_dict[value] / forex_rate)
                mef_sheet.cell(
                    row=value_cell.row, column=target_column).number_format = '0.00'
                mef_sheet.cell(row=value_cell.row, column=target_column).alignment = Alignment(horizontal='right')

    except Exception as e:
        logger.exception(f'Error in update_mef_sheet_non_volume: {e}')


def get_forex_rates(date, currency_code, rates_ws):
    quarter = {'Q1': [1, 2, 3], 'Q2': [4, 5, 6], 'Q3': [7, 8, 9], 'Q4': [10, 11, 12]}
    try:
        for k, v in quarter.items():
            if int(date.split('/')[0]) in v:
                key = k
        row_val = key + ' ' + date.split('/')[2]
        col_val = currency_code
        # column
        for c in rates_ws[7]:
            if c.value == row_val:
                req_col = get_column_letter(c.column)
        # row
        for r in rates_ws['C']:
            if r.value == col_val:
                req_row = r.row
        return round(rates_ws[req_col + str(req_row)].value, 7)
    except Exception as e:
        logger.exception(f'Error in get_forex_rates: {e}')


def fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, inputdate, rates_ws, tariff_dict,
                                   check_to_update_tariff, tariff_sheet):
    # cur_dir = os.getcwd()
    # path = os.path.join(cur_dir, 'Country_Inputdays_Mapping_11th June.xlsx')
    path = mapping_wb_path
    logger.info(f'Loading mapping workbook from path: {path}')
    # encode
    with open(path, 'rb') as f:
        mapping_wb = load_workbook(f)
    # mapping_wb = load_workbook(path)
    mapping_ws = mapping_wb['Activity_Description_Mapping']
    logger.info('Mapping workbook loaded successfully')
    try:
        date = datetime.strptime(inputdate, '%m/%d/%Y').day
        month = datetime.strptime(inputdate, '%m/%d/%Y').month
        year = datetime.strptime(inputdate, '%m/%d/%Y').year
        total_calendar_days_in_a_month = calendar.monthrange(year, month)[1]
        input_date = datetime.strptime(inputdate, '%m/%d/%Y')
        # creating a plant_sheet_mapping based on the country
        plant_sheet_mapping = {
            "A464": ("A464_ICF", "A464"),
            "A454": ("A454_A455_ICF", "A454"),
            "A455": ("A454_A455_ICF", "A455"),
            "A456": ("A456_ICF", "A456"),
            "A471": ("A471 Ambient", "A471 Ambient", "A471 FOOD", "A471 HPC")
        }

        sheets = plant_sheet_mapping[plant]
        logger.info(f'Sheets found for plant: {plant} - {sheets}')
        mef_sheet = mef_sheet_wb[sheets[0]]
        input_sheet = input_sheet_wb[sheets[1]]
        input_sheet_food = input_sheet_wb[sheets[2]] if plant == "A471" else None
        input_sheet_hpc = input_sheet_wb[sheets[3]] if plant == "A471" else None
        logger.info(f'Getting get_row_column_range : {plant}')
        start_row, end_row = get_row_column_range(mef_sheet, plant)
        # print(start_row, end_row)
        logger.info(f'Getting get_values_from_input_sheet : {plant}')
        output_dict = get_values_from_input_sheet(start_row, end_row, input_sheet, mef_sheet, plant, mapping_ws,
                                                  date, total_calendar_days_in_a_month, input_sheet_food,
                                                  input_sheet_hpc)
        logger.info(f'Getting get_row_column_range_non_volume : {plant}')
        start_row_nv, end_row_nv = get_row_column_range_non_volume(mef_sheet, plant, year)
        # print(start_row_nv, end_row_nv)
        logger.info(f'Getting get_values_from_input_sheet : {plant}')
        output_dict_non_volume = get_values_from_input_sheet(start_row_nv, end_row_nv, input_sheet, mef_sheet,
                                                             plant, mapping_ws, date,
                                                             total_calendar_days_in_a_month, input_sheet_food,
                                                             input_sheet_hpc)
        logger.info(f'Getting get_input_data_column : {plant}')
        target_column = get_input_data_column(mef_sheet, month)
        # print(target_column)
        column = 'D' if plant == "A471" else 'C'
        mef_sheet[f'{column}1'].value = month

        column_index = 4 if plant == "A471" else 3

        # update_mef_sheet(mef_sheet, start_row, end_row - (2 if plant == "A464" else 1), column_index,
        #                  output_dict, target_column)
        logger.info(f'Updating MEF sheet for plant: {plant}')
        update_mef_sheet(plant, tariff_dict, check_to_update_tariff, mef_sheet, start_row, end_row, column_index,
                         output_dict, target_column, tariff_sheet, input_date)
        currency_code = "PLN"
        forex_rate = get_forex_rates(inputdate, currency_code_dict[currency_code], rates_ws)
        update_mef_sheet_non_volume(mef_sheet, start_row_nv, end_row_nv, column_index, output_dict_non_volume,
                                    target_column, forex_rate)
        logger.info(f'data updated for the plant {plant}')

    except Exception as e:
        logger.exception(f'Error in fill_values_in_required_column: {e}')


def main(mef_sheet_wb, country, items, output_path, rates_ws):
    logger.info(f'Starting data update for country {country}')
    mef_sheet_wb = load_workbook(mef_sheet_wb)
    logger.info(f'Loaded MEF sheet for {country}')
    check_tariff_sheet = 'TARIFF' not in mef_sheet_wb.sheetnames
    logger.info(f'Checking for sheet TARIFF in MEF sheet for {country}')
    if check_tariff_sheet:
        logger.info("Sheet 'TARIFF' not found. Adding new sheet 'TARIFF'.")
        tariff_sheet = mef_sheet_wb.create_sheet('TARIFF')
        logger.info("Sheet 'TARIFF' added successfully.")
    else:
        logger.info("Sheet 'TARIFF' already exists.")
        tariff_sheet = mef_sheet_wb['TARIFF']
    for item in items:
        input_file = item['input_file']
        input_sheet_wb = load_workbook(input_file)
        plant = item['code']  # plant can be picked from the user request
        input_date = item['input_received_date']  # date can be picked from the user request
        tariff_dict, check_to_update_tariff = _get_tariff_json(input_file=input_file,code=plant, country=country)
        fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, input_date, rates_ws, tariff_dict,
                                       check_to_update_tariff, tariff_sheet)

    mef_sheet_wb.save(f'{output_path}\{country}_MEF_sheet.xlsx')
