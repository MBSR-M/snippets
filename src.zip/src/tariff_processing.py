import json
import re
import sys
import warnings
from datetime import datetime

import pandas as pd
from openpyxl.reader.excel import load_workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.workbook import Workbook
from loguru import logger

from src.constants import MAPPER

warnings.filterwarnings("ignore")


def auto_format_cells(func):
    def wrapper(*args, **kwargs):
        worksheet = args[0].worksheet
        tariff_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
        activity_fill = PatternFill(start_color="0000FF", end_color="0000FF", fill_type="solid")
        for col in worksheet.columns:
            max_length = 0
            column = col[0].column_letter
            for cell in col:
                try:
                    if cell.value is not None and len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except Exception as e:
                    logger.error(f"Error while getting max length for column {column}: {e}")
            adjusted_width = (max_length + 2)
            worksheet.column_dimensions[column].width = adjusted_width
        for row in worksheet.iter_rows():
            for cell in row:
                if cell.value is not None:
                    if "Tariff" in str(cell.value):
                        cell.fill = tariff_fill
                    elif "Handling" in str(cell.value) or "Picking" in str(cell.value) or "Storage" in str(cell.value):
                        cell.fill = activity_fill
        return func(*args, **kwargs)

    return wrapper


class TariffProcessing:
    def __init__(self, mef_sheet, new_tariff, mapping_wb, plant, tariff_sheet, input_date):
        logger.info(f"Processing tariffs for {plant}")
        self.tariff_sheet = tariff_sheet
        self.input_date = input_date
        self.plant = plant
        self.mapping_wb = mapping_wb
        self.new_tariff = new_tariff
        self.filtered_tariff_dict = [
            item for item in self.new_tariff if not (item['activity_description'] == 0 and item['tariff'] == 0.0)
        ]
        self.worksheet = mef_sheet
        self.start_row = 0
        self.end_row = 0
        self.is_tariff_empty = self.tariff_sheet.max_row <= 1
        self.current_year = self.input_date.year
        self.current_month = self.input_date.month
        self.header_tariff_query = f"ACTUALS Year-{self.current_year}-{self.plant}"
        self.tariff_column_to_update = {i: f"Tariff {i}" for i in range(1, 13)}

    def set_tariff_sheet(self):
        self.insert_or_update_new_tariff_sheet(is_empty=self.is_tariff_empty)

    def get_mapping_description(self):
        with open(self.mapping_wb, 'rb') as f:
            map_workbook = load_workbook(f)['Activity_Description_Mapping']
        mapping_set = {
            (row[2].value, row[3].value)
            for row in map_workbook.iter_rows(min_row=map_workbook.min_row, max_row=map_workbook.max_row)
            if row[2].value and row[3].value and row[2].value != 'Not Applicable' and row[1].value == self.plant
        }
        return {key: value for key, value in mapping_set}

    def find_start_end_rows(self):
        sheet_col = self.worksheet[str(MAPPER.get(self.plant).get('row'))]
        for cell in sheet_col:
            if cell.value in ('ACTUAL Current Year EUR', f'ACTUALS current year {self.current_year} HUF',
                              f'ACTUALS current year {self.current_year} RON',f'ACTUALS current year {self.current_year} - CZK',f'ACTUAL EUR {self.current_year}') \
                    or (self.plant in ['A981', 'C995'] and cell.value == 'ACTUALS current year 2025 - EUR'):
                self.start_row = cell.row
            elif cell.value == 'TOTAL':
                self.end_row = cell.row

    def find_start_end_rows_for_update(self):
        current_year_str = str(datetime.now().year)
        year_check = self.worksheet[str(MAPPER.get(self.plant).get('year_check'))]
        tariff_cols = [self.worksheet[col] for col in MAPPER.get(self.plant).get('tariff_cols')]
        for year_value in year_check:
            if current_year_str in str(year_value.value):
                row = year_value.row
                if any(tariff_cols[i][row - 1].value in {f'Tariff {i + 1}', f'Tariff-{i + 1}'} for i in range(3)):
                    sr = row + 1
                    break
        else:
            sr = 0
        er = sr + len(self.filtered_tariff_dict)
        si, ei = MAPPER.get(self.plant).get('si'), MAPPER.get(self.plant).get('ei')
        return sr, er, si, ei

    def extract_tariffs(self):
        self.find_start_end_rows()
        tariff_dict_list = []
        asset_col = int(MAPPER.get(self.plant).get('asset_col'))
        for data in self.worksheet.iter_rows(min_row=self.start_row + 1, max_row=self.end_row):
            if data[asset_col].value in (None, 0, '0', 'TOTAL'):
                break
            activity_description = data[asset_col].value
            if isinstance(activity_description, str) and activity_description.startswith('='):
                activity_description = self.get_cell_value(data[asset_col])
            tariff_cols = [data[i].value or 0.0 for i in MAPPER.get(self.plant).get('tariff_cols_index')]
            tariff_dict_list.append({
                'activity_description': activity_description,
                'tariff_1': tariff_cols[0], 'tariff_2': tariff_cols[1], 'tariff_3': tariff_cols[2]
            })
        return tariff_dict_list

    def save_tariffs_to_json(self, output_file):
        tariffs = self.extract_tariffs()
        with open(output_file, 'w') as f:
            json.dump(tariffs, f, indent=4)
        logger.info(f"Tariffs saved to {output_file}")

    def get_cell_value(self, cell):
        if isinstance(cell.value, str) and cell.value.startswith('='):
            referenced_cell = self.worksheet[cell.value[1:]]
            return self.get_cell_value(referenced_cell)
        return cell.value

    def map_tariffs_to_new_tariff(self):
        current_tariffs = self.extract_tariffs()
        new_tariffs = self.filtered_tariff_dict
        self.apply_mapping()
        return self.update_tariffs(current_tariffs, new_tariffs)

    @staticmethod
    def update_tariffs(current_tariffs, new_tariffs):
        for new_tariff in new_tariffs:
            for current in current_tariffs:
                if current['activity_description'] == new_tariff['activity_description']:
                    if new_tariff['tariff'] not in (current['tariff_1'], current['tariff_2'], current['tariff_3']):
                        if current['tariff_1'] == 0:
                            current['tariff_1'] = new_tariff['tariff']
                        elif current['tariff_2'] == 0:
                            current['tariff_2'] = new_tariff['tariff']
                        elif current['tariff_3'] == 0:
                            current['tariff_3'] = new_tariff['tariff']
                        else:
                            current['tariff_1'], current['tariff_2'], current['tariff_3'] = (
                                current['tariff_2'], current['tariff_3'], new_tariff['tariff']
                            )
        return current_tariffs

    def apply_mapping(self):
        mapper = self.get_mapping_description()
        for item in self.filtered_tariff_dict:
            if item['activity_description'] in mapper:
                item['activity_description'] = mapper[item['activity_description']]

    def update_tariffs_in_mef_sheet(self):
        sr, er, si, ei = self.find_start_end_rows_for_update()
        values_to_update = self.map_tariffs_to_new_tariff()
        er = sr + len(values_to_update) - 1
        logger.info(f"Updating tariffs in MEF from {sr} to {er} for columns {si} to {ei}")
        for n, row in enumerate(self.worksheet.iter_rows(sr, er)):
            val = values_to_update[n].get('activity_description')
            for col in range(si, ei + 2):
                try:
                    if val == self.get_cell_value(row[col]):
                        self.worksheet.cell(row=n + sr, column=col + 2, value=values_to_update[n].get('tariff_1'))
                        self.worksheet.cell(row=n + sr, column=col + 3, value=values_to_update[n].get('tariff_2'))
                        self.worksheet.cell(row=n + sr, column=col + 4, value=values_to_update[n].get('tariff_3'))
                except Exception as e:
                    logger.warning(f"Warning updating tariff in MEF sheet: {e}")
                    continue
        return self.worksheet

    def save_sheets(self):
        workbook = Workbook()
        sheet_1 = workbook.active
        sheet_1.title = "Worksheet"
        for row in self.worksheet.iter_rows(values_only=True):
            sheet_1.append(row)
        sheet_2 = workbook.create_sheet(title="Tariff Sheet")
        for row in self.tariff_sheet.iter_rows(values_only=True):
            sheet_2.append(row)
        workbook.save(f"Tariff_Workbook-{self.plant}.xlsx")

    def insert_or_update_new_tariff_sheet(self, is_empty):
        start_row = 0
        logger.info('Inserting new tariff sheet')
        values_to_update = self.map_tariffs_to_new_tariff()
        A1_ROW_VALUES = [x['activity_description'] for x in values_to_update]
        for cell in self.tariff_sheet['A']:
            if cell.value == self.header_tariff_query:
                start_row = cell.row
                break
        if start_row == 0:
            start_row = self.tariff_sheet.max_row + 2
        for i, value in enumerate(A1_ROW_VALUES, start=start_row + 1):
            self.tariff_sheet.cell(row=i, column=1, value=value)
        tariff_headers = [f'Tariff {i}' for i in range(1, 13)]
        for col, header in enumerate(tariff_headers, start=2):
            self.tariff_sheet.cell(row=start_row, column=col, value=header)
        self.tariff_sheet.cell(row=start_row, column=1, value=self.header_tariff_query)
        for i, value in enumerate(values_to_update, start=start_row + 1):
            for col in range(2, 14):
                tariff_key = f'tariff_{col - 1}'
                self.tariff_sheet.cell(row=i, column=col, value=value.get(tariff_key, 0.0))
        self.update_current_month_tariff()

    def update_current_month_tariff(self):
        if not self.tariff_column_to_update.get(self.current_month):
            logger.error(f"No tariff information for month {self.current_month}")
            return
        start_row = None
        for cell in self.tariff_sheet['A']:
            if cell.value == self.header_tariff_query:
                start_row = cell.row
                break
        if start_row is None:
            logger.warning(f"Header '{self.header_tariff_query}' not found in column A")
            start_row = self.tariff_sheet.max_row + 2
        current_month_tariff = self.map_tariffs_to_new_tariff()
        filtered_current_month_tariff = [
            {'activity_description': item['activity_description'], 'tariff': self.get_last_non_zero_tariff(item)}
            for item in current_month_tariff
        ]
        end_row = start_row + len(filtered_current_month_tariff)
        column_letter = get_column_letter(self.current_month + 1)
        column_letter_value = get_column_letter(1)
        for i, value in enumerate(filtered_current_month_tariff, start=start_row):
            if self.tariff_sheet[f'{column_letter_value}{i + 1}'].value == value.get('activity_description'):
                self.tariff_sheet[f'{column_letter}{i + 1}'] = value.get('tariff', 0.0)
        logger.info(f"Updated rows from {start_row} to {end_row} in column {column_letter}")

    @staticmethod
    def get_last_non_zero_tariff(tariff_obj):
        for key in sorted(tariff_obj.keys(), reverse=True):
            if tariff_obj[key] != 0 and not (isinstance(tariff_obj[key], str)):
                return tariff_obj[key]
        return 0

    def apply_tariff_calculation_method(self):
        start_row = None
        for cell in self.tariff_sheet['A']:
            if cell.value == self.header_tariff_query:
                start_row = cell.row
                break
        if start_row is None:
            logger.error(f"Header '{self.header_tariff_query}' not found in column A")
        tariff_column_from = start_row + 1
        tariff_column_to = start_row + len([
            {'activity_description': item['activity_description'], 'tariff': self.get_last_non_zero_tariff(item)}
            for item in self.map_tariffs_to_new_tariff()
        ])
        logger.info(f"Collecting tariff from {tariff_column_from} to {tariff_column_to}")
        tariff_objects_list = []
        for _, tariff_row in enumerate(self.tariff_sheet.iter_rows(tariff_column_from, tariff_column_to)):
            tariff_objects = {self.get_cell_value(tariff_row[0]): {'tariff_1': tariff_row[1], 'tariff_2': tariff_row[2],
                                                                   'tariff_3': tariff_row[3],
                                                                   'tariff_4': tariff_row[4], 'tariff_5': tariff_row[5],
                                                                   'tariff_6': tariff_row[6], 'tariff_7': tariff_row[7],
                                                                   'tariff_8': tariff_row[8], 'tariff_9': tariff_row[9],
                                                                   'tariff_10': tariff_row[10],
                                                                   'tariff_11': tariff_row[11],
                                                                   'tariff_12': tariff_row[12]}}
            tariff_objects_list.append(tariff_objects)
        sr, er, si, ei = self.find_start_end_rows_for_update()
        values_to_update = self.map_tariffs_to_new_tariff()
        er = sr + len(values_to_update) - 1
        logger.info(f"Applying tariff calculation method from {sr} to {er} for columns {si} to {ei}")
        for cnt, row in enumerate(self.worksheet.iter_rows(sr, er)):
            mef_key = self.get_cell_value(row[si])
            reference_cell = tariff_objects_list[cnt].get(mef_key)
            if reference_cell is None:
                logger.warning(f"No tariff information found for MEF {mef_key}")
                continue
            final_object = {mef_key: reference_cell}
            value = self.get_cell_value(row[si])
            logger.info(f"Applying new formula to {value}")
            loop_start_index = MAPPER.get(self.plant).get('loop_start')
            loop_end_index = MAPPER.get(self.plant).get('loop_start') + 12
            loop_offset = MAPPER.get(self.plant).get('loop_start') - 1
            # print(loop_start_index,loop_end_index)
            for i in range(loop_start_index, loop_end_index):
                tariff_key = f'tariff_{i - loop_offset}'
                row[si + i].value = self.revised_formula(row[si + i].value, final_object.get(mef_key).get(tariff_key),
                                                         self.plant)

    @staticmethod
    def revised_formula(x, y, plant):
        old_reference = str(x)
        to_apply = str(y)
        sheet_name = to_apply.split("'")[1]
        cell_reference = to_apply.split(".")[1].strip(">")
        if plant in ['A126', 'A480', 'A481', 'A921', 'A947', 'A719', 'A741', 'C046', 'A981', 'A998', 'A999', 'C995', 'C998',
                     'A762','A766','A778','A852','A861','A876','C261','C265','A341','A381','A383','C341','C343','D500','E034','E055']:
            return re.sub(r'[^*]+(?=\*)', f"='{sheet_name}'!${cell_reference}", old_reference)
        else:
            return re.sub(r'[^/]+(?=/)', f"='{sheet_name}'!${cell_reference}", old_reference)

    @auto_format_cells
    def format_tariff_sheet(self):
        pass


def _get_tariff_json(input_file, code, country, month_name=None):
    plant_sheet_mapping = None
    if country == 'PL':
        plant_sheet_mapping = {
            "A464": ("A464_ICF", "A464"),
            "A454": ("A454_A455_ICF", "A454"),
            "A455": ("A454_A455_ICF", "A455"),
            "A456": ("A456_ICF", "A456"),
            "A471": ("A471 Ambient", "A471 Ambient", "A471 FOOD", "A471 HPC")
        }
    elif country == 'ES':
        plant_sheet_mapping = {
            "A126": ("A126IC", "A126")
        }
    elif country == 'BAL':
        plant_sheet_mapping = {
            "A480": ("A480 Kaunas LT", "A480"),
            "A481": ("A481 Riga LV", "A481")
        }
    elif country == 'HU':
        plant_sheet_mapping = {
            "A921": ("Catone A921_excl_BCS", "Template A921"),
            "A947": ("WAB(old HOPI)", "Template A947")
        }
    elif country == 'RO':
        plant_sheet_mapping = {
            "A719": ("AQ A719VAC EXCL BCS", "Sheet1"),
            "A741": ("AQ A741", "Sheet1"),
            "C046": ("AQ C046VAC", "Sheet1")
        },
    elif country == 'CZSK':
        plant_sheet_mapping = {
            "A981": ("TP A981 FOOD EXCL BCS", "Template TP A981 FOOD"),
            "A998": ("FM A998 FOOD EXCL BCS", "Template A998 HPC"),
            "A999": (" HOPI ICF A999VAC", "Template CZ A999 HPC"),
            "C995": ("TP HPC C995VAC", "Template TP C995 HPC"),
            "C998": ("FM HPC C998VAC", "Template C998 HPC")
        },
    elif country == 'IT':
        plant_sheet_mapping = {
            # ITALY
            "A762": ("A762 LATINA", "Template A762 LATINA"),
            "A766": ("A766 VITULAZIO", "A766"),
            "A778": ("A778 PARMA", month_name),
            "A852": ("A852 CAIVANO", "A852"),
            "A861": ("A861 LODI", "a861"),
            "A876": ("A876 LODI FS", "a876"),
            "C261": ("C261 LODI", "c261"),
            "C265": ("C265_D020 POZZILLI", "C265 day+2")
        },
    elif country == 'FR':
        plant_sheet_mapping = {
            "A341": ("A341", "Template A341"),
            "A381": ("A381", "Template A381"),
            "A383": ("A383", "Template A383"),
            "C341": ("C341", "Template C341"),
            "C343": ("C343", "Template C343")
        },
    elif country == 'NORDIC-SWEDEN':
        plant_sheet_mapping={
            "D300": ("D300", "Ark1"),
            "E022": ("E022", "Ark1"),
            "E022 CHILLED": ("E022 CHILLED", "Ark1"),
            "E041": ("E041", "Template DHL_E041")
        },
    elif country == 'NORDIC-DENMARK':
        plant_sheet_mapping={
            "D200": ("D200", "Ark1"),
            "E019": ("E019", "Ark1"),
            "E029": ("E029", "Ark1")
        },
    elif country == 'NORDIC-FINLAND':
        plant_sheet_mapping={
            "D500": ("D500", "Ark1"),
            "E034": ("E034", "Template DHL_E034"),
            "E055": ("E055", "Ark1")
        }

    if plant_sheet_mapping is not None:
        sheet = plant_sheet_mapping.get(code)[1]
        try:
            data_frame = pd.read_excel(input_file, sheet_name=sheet)
            # if country=='RO':
            #     data_frame = pd.read_excel(input_file, sheet_name=sheet)
            #     data_frame = data_frame[data_frame[data_frame.columns[2]] == code]
            # else:
            #     data_frame = pd.read_excel(input_file, sheet_name=sheet)
            if data_frame.columns[7] == 'Volume':
                data_frame.fillna(0, inplace=True)
                return [{'activity_description': row[data_frame.columns[6]], 'tariff': row[data_frame.columns[8]]} for
                        index, row in data_frame.iterrows()], True
            else:
                return [], False
        except FileNotFoundError:
            logger.error("File not found %s" % input_file)
            sys.exit(1)
        except Exception as e:
            logger.error("Error reading file %s: %s" % (input_file, str(e)))
            sys.exit(1)
    else:
        logger.error("No mapping found for %s in %s" % (code, country))
        sys.exit(1)
