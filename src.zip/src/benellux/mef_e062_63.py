import calendar
import os
from datetime import datetime, timedelta
import warnings
from loguru import logger
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

from utils import mapping_wb_path

def get_row_column_range(mef_sheet):
    try:
        sheet_col = mef_sheet['A']
        start_row, end_row = None, None
        mef_start_value = '2024 Actuals'
        for cell in sheet_col:
            if cell.value == mef_start_value:  # static
                start_row = cell.row
            elif cell.value == 'COSTS EUR':  # static
                end_row = cell.row
                break
        return start_row, end_row
    except Exception as e:
        logger.exception(f'Error in get_row_column_range: {e}')


def get_value_from_formulas(vals):
    try:
        if vals is None:
            return 0
        else:
            return eval(vals.strip('='))

    except Exception as e:
        logger.exception(f'Error in get_value_from_formulas: {e}')



def get_column_value(value, ws):
    cell_value = value.strip('=')
    split_cell = cell_value.split('+')
    index_value = ws[split_cell[0]].value
    if isinstance(index_value, str) and index_value.isdigit():
        index_value = int(index_value)
    if isinstance(index_value, str):
        return get_column_value(index_value, ws) + int(split_cell[-1])
    elif isinstance(index_value, int):
        return index_value + int(split_cell[-1])


def get_input_data_column(mef_ws, month, week):
    """
    Retrieve the column number of the specified week within the given month from the MEF worksheet.

    :param mef_ws: The worksheet object
    :param month: The month to match in the header row
    :param week: The week number to match in the week columns
    :return: The column number corresponding to the specified week
    """
    # Iterate over the second row (header) of the worksheet
    for row in mef_ws.iter_rows(min_row=2, max_row=2):
        for cell in row:
            value = cell.value
            # Skip cells without any value
            if value is None:
                continue
            # Resolve formula cells to their actual values
            elif isinstance(value, str):
                if value[0] == '=':
                    value = get_column_value(value, mef_ws)
            # Check if the cell value matches the specified month
            if value == month:
                acr_column_number = cell.column  # Get the column number for the month

                # Iterate backward to find the week number column within a certain range
                for i in range(1, 7):
                    week_column_number = acr_column_number - i
                    week_column_letter = get_column_letter(week_column_number)
                    week_cell = mef_ws[week_column_letter + '2']
                    week_value = week_cell.value
                    # Resolve formula cells to their actual values
                    if isinstance(week_value, str):
                        if week_value[0] == '=':
                            week_value = get_column_value(week_value, mef_ws)
                    # Return the week column number if it matches the specified week
                    if week_value == week:
                        return week_column_number
    return None  # Return None if no matching column is found


def get_values_from_input_sheet(start_row, end_row, input_sheet, mef_sheet, plant, mapping_ws, week, month, year
                                ):
    out_dict = {}
    input_sheet_start_row=2
    input_sheet_end_row=input_sheet.max_row
    week_column=4
    try:
        # start_row, end_row = get_row_column_range(mef_sheet, plant)

        def get_item_description(value, ws):
            value = ws[value[1:]].value
            if value[0] == '=':
                return get_item_description(value, ws)
            else:
                return value

        for data in mef_sheet.iter_rows(min_row=start_row + 2, max_row=end_row-1):
            value = data[2].value
            if value is None:
                continue

            if value[0] == '=':
                value = get_item_description(value, mef_sheet)

            for row in mapping_ws.iter_rows(min_row=mapping_ws.min_row, max_row=mapping_ws.max_row):
                if row[1].value == plant and value == row[3].value:
                    adjustment_rate = row[9].value
                    if type(adjustment_rate) in [int, float]:
                        adjustment_rate += 1
                    row_map_val = row[3].row
                    map_value = mapping_ws.cell(row=row_map_val, column=3).value

                    if map_value is None:
                        out_dict[value] = 0
                        continue

                    for row_data in input_sheet.iter_rows(min_row=input_sheet_start_row, max_row=input_sheet_end_row):
                        asset_column = 1
                        if map_value == row_data[asset_column].value:  # number will change based on asset description in input sheet
                            r = row_data[2].row
                            tariff = 1  # todo: remove tariff later
                            compute_val = input_sheet.cell(row=r,
                                                           column=week_column).value  # column used is volume column in input sheet
                            if compute_val is not None and tariff is not None:
                                if isinstance(compute_val, int) or isinstance(compute_val,
                                                                              float) and compute_val != 0:
                                    computed_value = round(compute_val, 7)
                                else:
                                    computed_value = 0

                            else:
                                computed_value = 0
                            # print(computed_value)
                            out_dict[value] = computed_value if value not in out_dict.keys() else out_dict[
                                                                                                      value] + computed_value
                            break
        return out_dict
    except Exception as e:
        logger.exception(f'Error in get_values_from_input_sheet: {e}')


def update_mef_sheet(mef_sheet, start_row, end_row, column_index, output_dict, target_column):
    """
    Update the MEF sheet with values from the output dictionary.

    :param mef_sheet: The worksheet to be updated
    :param start_row: The starting row for the update
    :param end_row: The ending row for the update
    :param column_index: The index of the column with the value to be matched
    :param output_dict: Dictionary with keys to be matched and their corresponding values
    :param target_column: The column to be updated with values from the dictionary
    """
    try:
        value_per = mef_sheet.cell(row=start_row - 1, column=target_column).value
        value_per = 1 if value_per is None else value_per
        print('percentage', value_per)
        # Iterate over the specified rows
        for row in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value_cell = row[column_index]  # Cell containing the value to be matched
            # Skip if cell is empty
            if value_cell.value is None:
                continue
            # Retrieve the actual value if it is a formula
            value = mef_sheet[value_cell.value[1:]].value if value_cell.value[0] == '=' else value_cell.value
            # Update the target column if value matches and is non-zero in output_dict
            if value in output_dict and output_dict[value] != 0:
                mef_sheet.cell(row=value_cell.row, column=target_column, value=output_dict[value] * value_per)
                mef_sheet.cell(row=value_cell.row,
                               column=target_column).number_format = '0.00'  # Set number format to two decimal places
                mef_sheet.cell(row=value_cell.row, column=target_column).alignment = Alignment(
                    horizontal='right')  # Align text to the right
    except Exception as e:
        logger.exception(f'Error in update_mef_sheet: {e}')


def fill_values_in_required_column_e062_63(mef_sheet_wb, input_sheet_wb, plant, input_date, week):
    path = mapping_wb_path
    mapping_wb = load_workbook(path)
    mapping_ws = mapping_wb['Activity_Description_Mapping']
    week_num = int(week[-2:])
    try:
        month = datetime.strptime(input_date, '%m/%d/%Y').month
        year = datetime.strptime(input_date, '%m/%d/%Y').year
        # print(date)

        input_date = datetime.strptime(input_date, '%m/%d/%Y')

        # creating a plant_sheet_mapping based on the country
        plant_sheet_mapping = {
            "C600": ("C600_005", "Weekly Overview"),
            "E001": ("E001_355", "Totaal FOOD"),
            "E062": ("E062_671", "E062"),
            "E063": ("E063_679", "E063")
        }

        sheets = plant_sheet_mapping[plant]
        mef_sheet = mef_sheet_wb[sheets[0]]
        input_sheet = input_sheet_wb[sheets[1]]

        start_row, end_row = get_row_column_range(mef_sheet)
        output_dict = get_values_from_input_sheet(start_row, end_row, input_sheet, mef_sheet, plant, mapping_ws, week,
                                                  month, year)
        logger.info(output_dict)

        target_column = get_input_data_column(mef_sheet, month, week_num)

        mef_sheet['B1'].value = month

        column_index = 2  # changes based on plant

        update_mef_sheet(mef_sheet, start_row, end_row, column_index, output_dict, target_column)

    except Exception as e:
        logger.exception(f'Error in fill_values_in_required_column: {e}')