import sys
from datetime import datetime

import pandas as pd
import polars as pl
from loguru import logger
from openpyxl import load_workbook, Workbook

from src.CZSK.mef_czsk import main as mef_main_czsk
from src.CZSK.output_czsk import main as output_main_czsk
from src.baltic.mef_baltic import main as mef_main_baltic
from src.baltic.output_baltic import main as output_main_baltic
from src.france.mef_france import main as mef_main_france
from src.france.output_france import main as output_main_france
from src.italy.mef_italy import main as mef_main_italy
from src.italy.output_italy import main as output_main_italy
from src.nordic.mef_nordic import main as mef_main_nordic
from src.nordic.output_nordic import main as output_main_nordic
from src.poland.mef_poland import main as mef_main_poland
from src.poland.output_poland import main as output_main_poland
from src.romania.mef_romania import main as mef_main_romania
from src.romania.output_romania import main as output_main_romania
from src.spain.mef_spain import main as mef_main_spain
from src.spain.output_spain import main as output_main_spain
from src.hungary.mef_hungary import main as mef_main_hungary
from src.hungary.output_hungary import main as output_main_hungary
from src.benellux.mef_benellux import main as mef_main_benellux
from src.uk.mef_uk import main as mef_main_uk


def upload_all_files(input_file, forex, country, plant, date, output_path):
    logger.info("Processing")
    if not any([input_file, forex, country, plant, date]):
        raise TypeError('Provide required fields')
    rates_wb = load_workbook(forex)
    rates_ws = rates_wb['Forex']
    if country == 'PL':
        pl_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'ES':
        es_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'IT':
        it_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'FR':
        fr_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'BAL':
        bal_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'CZSK':
        czsk_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'NORDIC-SWEDEN':
        nordic_sweden_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'NORDIC-FINLAND':
        nordic_finland_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'NORDIC-DENMARK':
        nordic_denmark_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'RO':
        ro_output_generation(country, date, input_file, output_path, plant, rates_ws)
    elif country == 'HU':
        hu_output_generation(country, date, input_file, output_path, plant, rates_ws)



def upload_all_files_mef(mef_file, country, items, output, forex):
    logger.info("Processing")
    if not any([mef_file, country, items, output]):
        raise TypeError('Provide required fields')
    rates_wb = load_workbook(forex)
    rates_ws = rates_wb['Forex']
    if country == 'PL':
        mef_main_poland(mef_file, country, items, output, rates_ws)
    elif country == 'ES':
        mef_main_spain(mef_file, country, items, output)
    elif country == 'IT':
        mef_main_italy(mef_file, country, items, output)
    elif country == 'FR':
        mef_main_france(mef_file, country, items, output)
    elif country == 'BAL':
        mef_main_baltic(mef_file, country, items, output)
    elif country == 'CZSK':
        mef_main_czsk(mef_file, country, items, output,rates_ws)
    elif country == 'NORDIC-SWEDEN':
        mef_main_nordic(mef_file, country, items, output)
    elif country == 'NORDIC-FINLAND':
        mef_main_nordic(mef_file, country, items, output)
    elif country == 'NORDIC-DENMARK':
        mef_main_nordic(mef_file, country, items, output)
    elif country == 'RO':
        mef_main_romania(mef_file, country, items, output, rates_ws)
    elif country == 'HU':
        mef_main_hungary(mef_file, country, items, output,rates_ws)
    elif country == 'BNL':
        mef_main_benellux(mef_file, country, items, output)
    elif country == 'UK':
        mef_main_uk(mef_file, country, items, output)


def hu_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "A921": ("Catone A921_excl_BCS", "Template A921"),
        "A947": ("WAB(old HOPI)", "Template A947")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pd.read_excel(input_file, sheet_name=sheets[1])
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_hungary(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def ro_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "A719": ("AQ A719VAC EXCL BCS", "Sheet1"),
        "A741": ("AQ A741", "Sheet1"),
        "C046": ("AQ C046VAC", "Sheet1")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pd.read_excel(input_file, sheet_name=sheets[1])
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_romania(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def nordic_sweden_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "D300": ("D300", "Ark1"),
        "E022": ("E022", "Ark1"),
        "E022 CHILLED": ("E022 CHILLED", "Ark1"),
        "E041": ("E041", "Template DHL_E041")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_nordic(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def nordic_finland_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "D500": ("D500", "Ark1"),
        "E034": ("E034", "Template DHL_E034"),
        "E055": ("E055", "Ark1")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_nordic(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def nordic_denmark_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "D200": ("D200", "Ark1"),
        "E019": ("E019", "Ark1"),
        "E029": ("E029", "Ark1")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_nordic(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def czsk_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "A981": ("TP A981 FOOD EXCL BCS", "Template TP A981 FOOD"),
        "A998": ("FM A998 FOOD EXCL BCS", "Template A998 HPC"),
        "A999": (" HOPI ICF A999VAC", "Template CZ A999 HPC"),
        "C995": ("TP HPC C995VAC", "Template TP C995 HPC"),
        "C998": ("FM HPC C998VAC", "Template C998 HPC")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_czsk(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def bal_output_generation(country, date, input_file, output_path, plant, rates_ws):
    temp_input_date = datetime.strptime(date, '%m/%d/%Y')
    month_name = temp_input_date.strftime('%B')

    plant_sheet_mapping = {
        "A480": ("A480 Kaunas LT", "Template A480 LT"),
        "A481": ("A481 Riga LV", "Template A481 LV")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_baltic(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def fr_output_generation(country, date, input_file, output_path, plant, rates_ws):
    month = datetime.strptime(date, '%m/%d/%Y').month
    year = datetime.strptime(date, '%m/%d/%Y').year
    year_last2digit = abs(year) % 100
    input_sheet_name = f'P0{month} {year_last2digit}' if month < 10 else f'P{month} {year_last2digit}'

    plant_sheet_mapping = {
        "A341": ("A341", "A341"),
        "A381": ("A381", input_sheet_name),
        "A383": ("A383", input_sheet_name),
        "C341": ("C341", "C341"),
        "C343": ("C343", "3PL")
    }
    print(plant_sheet_mapping.keys(), plant_sheet_mapping.values())
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_france(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def it_output_generation(country, date, input_file, output_path, plant, rates_ws):
    temp_input_date = datetime.strptime(date, '%m/%d/%Y')
    month_name = temp_input_date.strftime('%B')

    plant_sheet_mapping = {
        "A762": ("A762 LATINA", "Template A762 LATINA"),
        "A766": ("A766 VITULAZIO", "A766"),
        "A778": ("A778 PARMA", month_name),
        "A852": ("A852 CAIVANO", "A852"),
        "A861": ("A861 LODI", "a861"),
        "A876": ("A876 LODI FS", "a876"),
        "C261": ("C261 LODI", "c261"),
        "C265": ("C265_D020 POZZILLI","C265 day+2")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_italy(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def es_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {
        "A126": ("A126IC", "A126")
    }
    input_sheet_wb = load_workbook(input_file)
    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_spain(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')


def pl_output_generation(country, date, input_file, output_path, plant, rates_ws):
    plant_sheet_mapping = {  # added
        "A464": ("A464_ICF", "A464"),
        "A454": ("A454_A455_ICF", "A454"),
        "A455": ("A454_A455_ICF", "A455"),
        "A456": ("A456_ICF", "A456"),
        "A471": ("A471 Ambient", "A471 Ambient", "A471 FOOD", "A471 HPC")
    }
    with open(input_file, 'rb') as f:
        input_sheet_wb = load_workbook(f)

    sheets = plant_sheet_mapping[plant]  # added
    input_sheet_ws = input_sheet_wb[sheets[1]]  # added
    input_sheet_food = input_sheet_wb[sheets[2]] if plant == "A471" else None  # added
    input_sheet_hpc = input_sheet_wb[sheets[3]] if plant == "A471" else None  # added
    df = pl.read_excel(input_file, sheet_name=sheets[1])  # added
    logger.info("creating sheet for output")
    wb = Workbook()
    wb.create_sheet(title='output_sheet')
    wb.create_sheet(title='input_working_days_sheet')
    ws_output = wb['output_sheet']  # renamed ws to ws_output
    wb.remove(wb['Sheet'])
    ws_input_working_days = wb['input_working_days_sheet']  # renamed ws_input to ws_input_working_days
    output_main_poland(date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws,
                       input_sheet_food, input_sheet_hpc)
    wb.save(f'{output_path}\{plant}_output_sheet.xlsx')
