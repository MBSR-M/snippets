import calendar
from datetime import datetime, timedelta

from loguru import logger
from openpyxl import load_workbook
from openpyxl.styles import Alignment

from src.tariff_processing import TariffProcessing, _get_tariff_json
from utils import mapping_wb_path


def get_row_column_range(mef_sheet, plant):
    start_row, end_row = None, None
    try:
        sheet_col = mef_sheet['A']
        for cell in sheet_col:
            if cell.value == 'Actuals + forecast':
                start_row = cell.row
            elif cell.value == 'COSTS EUR' or cell.value == 0:
                end_row = cell.row
                break

        return start_row, end_row
    except Exception as e:
        logger.exception(f'Error in get_row_column_range: {e}')


def get_row_column_range_non_volume(mef_sheet, plant,year):
    try:
        initial_row = 0
        for cell in mef_sheet['C']:
            if cell.value == 'ACTUAL Current Year EUR':
                row = cell.row
                if str(mef_sheet[f'B{row}'].value) in [f'FCST{year}', f'FCST {year}']:
                    initial_row = row
                    # print(initial_row)
                    break
        start_row, end_row = 0, 0
        for idx in range(initial_row, mef_sheet.max_row + 1):
            cell_value = mef_sheet[f'C{idx}'].value
            if cell_value == 'TOTAL':
                start_row = idx
            elif cell_value == 'TOTAL INVOICE':
                end_row = idx
                break

        return start_row, end_row, initial_row

    except Exception as e:
        logger.exception(f'Error in get_row_column_range_non_volume: {e}')


def get_value_from_formulas(vals):
    try:
        if vals is None:
            return 0
        else:
            return eval(vals.strip('='))

    except Exception as e:
        logger.exception(f'Error in get_value_from_formulas: {e}')


def get_values_from_input_sheet(start_row, end_row, input_sheet, mef_sheet, plant, mapping_ws,
                                input_received_date, total_calendar_days_in_a_month, net_working_days,
                                total_working_days, input_sheet_food=None, input_sheet_hpc=None):
    out_dict = {}
    calculation_dict = {
        'old_volume': 'compute_val',
        'old_value': 'compute_val * tariff'
    }
    try:
        # start_row, end_row = get_row_column_range(mef_sheet, plant)

        def get_item_description(value, ws):
            value = ws[value[1:]].value
            if value[0] == '=':
                return get_item_description(value, ws)
            else:
                return value

        for data in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value = data[2].value

            if value is None:
                continue

            elif value[0] == '=':
                value = get_item_description(value, mef_sheet)

            # logger.info(f'value - {value}')
            for row in mapping_ws.iter_rows(min_row=mapping_ws.min_row, max_row=mapping_ws.max_row):
                if row[1].value == plant and value == row[3].value:
                    # logger.info(f'value - {value}')
                    calculation_logic = row[11].value
                    calculation_logic_parts = calculation_logic.split("=")
                    logic = calculation_logic_parts[-1].split()
                    # logger.info(logic)
                    calculation_logic_expression = calculation_logic_parts[-1]
                    # logger.info(calculation_logic_expression)

                    driver_1_2_condition = row[10].value
                    driver_1_2_condition = driver_1_2_condition.split('&')
                    # logger.info(driver_1_2_condition)

                    adjustment_rate = row[8].value
                    # logger.info(adjustment_rate, type(adjustment_rate))
                    if type(adjustment_rate) in [int, float]:
                        adjustment_rate += 1
                    # logger.info(adjustment_rate)
                    row_map_val = row[3].row
                    map_value = mapping_ws.cell(row=row_map_val, column=3).value

                    if map_value is None:
                        out_dict[value] = 0
                        continue
                    # logger.info(f'map_value - {map_value}')
                    for row_data in input_sheet.iter_rows(min_row=input_sheet.min_row,
                                                          max_row=input_sheet.max_row):
                        input_value = row_data[6].value
                        if input_value is None:
                            continue
                        # logger.info(f'input_value - {input_value}')
                        if input_value[0] == '=':
                            input_value = get_item_description(input_value, input_sheet)
                        # logger.info(f'input_value final- {input_value}')
                        if map_value == input_value and row_data[2].value == plant:
                            # logger.info(f'input_value matched- {input_value}')
                            r = row_data[6].row
                            tariff = input_sheet.cell(row=r, column=9).value
                            compute_val = input_sheet.cell(row=r, column=8).value
                            if compute_val is not None and tariff is not None:
                                if isinstance(compute_val, int) or isinstance(compute_val,
                                                                              float) and compute_val != 0:
                                    for item in logic:
                                        if item in calculation_dict.keys():
                                            calculation_logic_expression = calculation_logic_expression.replace(
                                                item, calculation_dict[item])
                                    for item in driver_1_2_condition:
                                        item = item.split('=')
                                        calculation_logic_expression = calculation_logic_expression.replace(
                                            item[0], item[1]) if item[
                                                                     0] in calculation_logic_expression else calculation_logic_expression
                                    # logger.info(calculation_logic_expression)
                                    computed_value = round(eval(calculation_logic_expression), 7)
                                    # computed_value = round((compute_val / net_working_days * total_working_days)*adjustment_rate)
                                elif isinstance(compute_val, str) and '=' in compute_val:
                                    compute_val = get_value_from_formulas(compute_val)
                                    for item in logic:
                                        if item in calculation_dict.keys():
                                            calculation_logic_expression = calculation_logic_expression.replace(
                                                item, calculation_dict[item])
                                    for item in driver_1_2_condition:
                                        item = item.split('=')
                                        calculation_logic_expression = calculation_logic_expression.replace(
                                            item[0], item[1]) if item[
                                                                     0] in calculation_logic_expression else calculation_logic_expression
                                    computed_value = round(eval(calculation_logic_expression), 7)
                                    # computed_value = round((compute_val / net_working_days * total_working_days)*adjustment_rate)
                                else:
                                    computed_value = 0
                            else:
                                computed_value = 0
                            # logger.info(computed_value)
                            out_dict[value] = computed_value if value not in out_dict.keys() else out_dict[
                                                                                                      value] + computed_value
                            break
        return out_dict
    except Exception as e:
        logger.exception(f'Error in get_values_from_input_sheet: {e}')


def get_input_data_column(mef_sheet, month, initial_row=2):
    try:
        def get_column_value(value):
            cell_value = value.strip('=')
            # logger.info(cell_value)
            split_cell = cell_value.split('+')
            # logger.info(split_cell)
            index_value = mef_sheet[split_cell[0]].value
            if isinstance(index_value, str):
                return get_column_value(index_value) + int(split_cell[-1])
            elif isinstance(index_value, int):
                return index_value + int(split_cell[-1])

        for row in mef_sheet.iter_rows(min_row=initial_row, max_row=initial_row):
            for cell in row:
                value = cell.value
                if value is None:
                    continue
                elif isinstance(value, str):
                    if value[0] == '=':
                        value = get_column_value(value)

                if value == month:
                    target_column = cell.column
        return target_column

    except Exception as e:
        logger.exception(f'Error in get_input_data_column: {e}')

def update_mef_sheet(plant, tariff_dict, check_to_update_tariff, mef_sheet, start_row, end_row, column_index,
                     output_dict, target_column, tariff_sheet, input_date):
# def update_mef_sheet(mef_sheet, start_row, end_row, column_index, output_dict, target_column):
    try:
        for row in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value_cell = row[column_index]
            if value_cell.value is None:
                continue
            value = mef_sheet[value_cell.value[1:]].value if value_cell.value[0] == '=' else value_cell.value
            fill = row[target_column - 1].fill
            color_index = fill.start_color.index
            # logger.info(color_index)
            # logger.info(row[target_column].value)
            if value in output_dict and output_dict[value] != 0 and (color_index in ['00000000', '0', 0, 'FF00B050']):
                mef_sheet.cell(
                    row=value_cell.row, column=target_column, value=output_dict[value])
                mef_sheet.cell(
                    row=value_cell.row, column=target_column).number_format = '0.00'
                mef_sheet.cell(row=value_cell.row, column=target_column).alignment = Alignment(
                    horizontal='right')
        try:
            logger.info(f"Updating tariff target in MEF sheet for plant : {plant} ...")
            tariff_processing = TariffProcessing(mef_sheet=mef_sheet, new_tariff=tariff_dict, mapping_wb=mapping_wb_path,
                                                 plant=plant, tariff_sheet=tariff_sheet, input_date=input_date)
            tariff_processing.update_tariffs_in_mef_sheet()
            tariff_processing.set_tariff_sheet()
            tariff_processing.apply_tariff_calculation_method()
        except Exception as exception:
            logger.error(f"Error updating tariff target: {exception}", exc_info=True)
    except Exception as e:
        logger.exception(f'Error in update_mef_sheet: {e}')

def update_mef_sheet_non_volume(mef_sheet, start_row, end_row, column_index, output_dict, target_column):
    try:
        if not output_dict:
            return
        for row in mef_sheet.iter_rows(min_row=start_row + 1, max_row=end_row):
            value_cell = row[column_index]
            if value_cell.value is None:
                continue
            value = mef_sheet[value_cell.value[1:]].value if value_cell.value[0] == '=' else value_cell.value
            fill = row[target_column - 1].fill
            color_index = fill.start_color.index
            # logger.info(color_index)
            # logger.info(row[target_column].value)
            if value in output_dict and output_dict[value] != 0 and (color_index in ['00000000', '0', 0, 'FF00B050']):
                mef_sheet.cell(
                    row=value_cell.row, column=target_column, value=output_dict[value])
                mef_sheet.cell(
                    row=value_cell.row, column=target_column).number_format = '0.00'
                mef_sheet.cell(row=value_cell.row, column=target_column).alignment = Alignment(
                    horizontal='right')
    except Exception as e:
        logger.exception(f'Error in update_mef_sheet_non_volume: {e}')

def fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, input_date, tariff_dict,
                                   check_to_update_tariff, tariff_sheet):
# def fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, input_date):
    logger.info(f'MEF updation of plant {plant}')
    # cur_dir = os.getcwd()
    # path = os.path.join(cur_dir, 'Country_Inputdays_Mapping_11th June.xlsx')
    path = mapping_wb_path
    mapping_wb = load_workbook(path)
    mapping_ws = mapping_wb['Activity_Description_Mapping']
    try:
        date = datetime.strptime(input_date, '%m/%d/%Y').day
        month = datetime.strptime(input_date, '%m/%d/%Y').month
        year = datetime.strptime(input_date, '%m/%d/%Y').year
        total_calendar_days_in_a_month = calendar.monthrange(year, month)[1]
        # logger.info(date)

        input_date = datetime.strptime(input_date, '%m/%d/%Y')

        # creating a plant_sheet_mapping based on the country
        plant_sheet_mapping = {
            "D300": ("D300", "Ark1"),
            "E022": ("E022", "Ark1"),
            "E022 CHILLED": ("E022 CHILLED", "Ark1"),
            "E041": ("E041", "Template DHL_E041"),
            "D200": ("D200", "Ark1"),
            "E019": ("E019", "Ark1"),
            "E029": ("E029", "Ark1"),
            "D500": ("D500", "Ark1"),
            "E034": ("E034", "Template DHL_E034"),
            "E055": ("E055", "Ark1")
        }

        sheets = plant_sheet_mapping[plant]
        mef_sheet = mef_sheet_wb[sheets[0]]
        input_sheet = input_sheet_wb[sheets[1]]
        input_sheet_food = input_sheet_wb[sheets[2]] if plant == "A471" else None
        input_sheet_hpc = input_sheet_wb[sheets[3]] if plant == "A471" else None

        def get_working_days(input_date):
            start_date = input_date.replace(day=1)
            if input_date.month == 12:
                end_date = input_date.replace(year=input_date.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                end_date = input_date.replace(month=input_date.month + 1, day=1) - timedelta(days=1)

            # logger.info(input_date, start_date, end_date)

            net_working_days = 0
            total_working_days = 0

            while start_date <= input_date:
                # Check if the current day is a weekday
                if start_date.weekday() < 5:
                    net_working_days += 1
                start_date += timedelta(days=1)

            start_date = input_date.replace(day=1)
            while start_date <= end_date:
                # Check if the current day is a weekday
                if start_date.weekday() < 5:
                    total_working_days += 1
                start_date += timedelta(days=1)

            return net_working_days, total_working_days

        net_working_days, total_working_days = get_working_days(input_date)
        start_row, end_row = get_row_column_range(mef_sheet, plant)
        # logger.info(start_row, end_row)
        output_dict = get_values_from_input_sheet(start_row, end_row, input_sheet, mef_sheet, plant, mapping_ws,
                                                  date, total_calendar_days_in_a_month, net_working_days,
                                                  total_working_days, input_sheet_food, input_sheet_hpc)
        logger.info(output_dict)
        # logger.info(start_row_nv, end_row_nv)
        target_column = get_input_data_column(mef_sheet, month)
        # logger.info(target_column)

        mef_sheet['B1'].value = month

        column_index = 2
        update_mef_sheet(plant, tariff_dict, check_to_update_tariff, mef_sheet, start_row, end_row, column_index,
                         output_dict, target_column, tariff_sheet, input_date)
        # update_mef_sheet(mef_sheet, start_row, end_row, column_index, output_dict, target_column)

        if plant in ['D200', 'D300', 'E041']:
            start_row_nv, end_row_nv, initial_row = get_row_column_range_non_volume(mef_sheet, plant,year)
            target_column = get_input_data_column(mef_sheet, month, initial_row)
            # logger.info(target_column)
            output_dict_non_volume = get_values_from_input_sheet(start_row_nv, end_row_nv, input_sheet,
                                                                 mef_sheet, plant, mapping_ws, date,
                                                                 total_calendar_days_in_a_month,
                                                                 net_working_days, total_working_days,
                                                                 input_sheet_food, input_sheet_hpc)
            logger.info(output_dict_non_volume)
            update_mef_sheet_non_volume(mef_sheet, start_row_nv, end_row_nv, column_index, output_dict_non_volume, target_column)

        logger.info(f'data updated for the plant {plant}')

    except Exception as e:
        logger.exception(f'Error in fill_values_in_required_column: {e}')


def main(mef_sheet_wb, country, items, output_path):
    logger.info(f'Starting data update for country {country}')
    mef_sheet_wb = load_workbook(mef_sheet_wb)
    logger.info(f'Loaded MEF sheet for {country}')
    check_tariff_sheet = 'TARIFF' not in mef_sheet_wb.sheetnames
    logger.info(f'Checking for sheet TARIFF in MEF sheet for {country}')
    if check_tariff_sheet:
        logger.info("Sheet 'TARIFF' not found. Adding new sheet 'TARIFF'.")
        tariff_sheet = mef_sheet_wb.create_sheet('TARIFF')
        logger.info("Sheet 'TARIFF' added successfully.")
    else:
        logger.info("Sheet 'TARIFF' already exists.")
        tariff_sheet = mef_sheet_wb['TARIFF']
    for item in items:
        input_file = item['input_file']
        input_sheet_wb = load_workbook(input_file)

        plant = item['code']  # plant can be picked from the user request

        input_date = item['input_received_date']  # date can be picked from the user request
        tariff_dict, check_to_update_tariff = _get_tariff_json(input_file=input_file, code=plant, country=country)
        fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, input_date, tariff_dict,
                                       check_to_update_tariff, tariff_sheet)
        # fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, input_date)

    # mef_sheet_wb.save(f'{output_path}\{country}\{country}_MEF_sheet.xlsx')
    mef_sheet_wb.save(f'{output_path}\{country}_MEF_sheet.xlsx')
