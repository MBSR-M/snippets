from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from datetime import datetime



def get_column_value(value, ws):
    cell_value = value.strip('=')
    split_cell = cell_value.split('+')
    index_value = ws[split_cell[0]].value
    if isinstance(index_value, str) and index_value.isdigit():
        index_value = int(index_value)
    if isinstance(index_value, str):
        return get_column_value(index_value, ws) + int(split_cell[-1])
    elif isinstance(index_value, int):
        return index_value + int(split_cell[-1])

def get_input_data_column(mef_ws, month, week):
    for row in mef_ws.iter_rows(min_row=2, max_row=2):
        for cell in row:
            value = cell.value
            if value is None:
                continue
            elif isinstance(value, str):
                if value.startswith('='):
                    value = get_column_value(value, mef_ws)
            if value == month:
                acr_column_number = cell.column

                for i in range(1, 7):
                    week_column_number = acr_column_number - i
                    week_column_letter = get_column_letter(week_column_number)
                    week_cell = mef_ws[week_column_letter + '2']
                    week_value = week_cell.value
                    if isinstance(week_value, str):
                        if week_value.startswith('='):
                            week_value = get_column_value(week_value, mef_ws)
                    if week_value == week:
                        return week_column_number,acr_column_number
    return None

def get_value_from_formula(sheet, formula):
    cell_refs = formula.split('&')
    result = ''
    for ref in cell_refs:
        ref = ref.strip().strip('" ')
        if ref.startswith('='):
            ref = ref[1:]
        if ref:
            result += str(sheet[ref].value)
        elif ref == '':
            result += ' '
    return result

def construct_formula(mef_ws, target_column, month_column, weeks_back):
    target_values = []

    # Iterate backward from the month column in row 3 and identify "3PL Actuals" weeks in row 2
    for i in range(weeks_back):
        col_num = month_column - i - 1
        col_letter = get_column_letter(col_num)
        cell_value_row_3 = mef_ws[f'{col_letter}3'].value
        cell_value_row_2 = mef_ws[f'{col_letter}2'].value

        if cell_value_row_3 == "3PL INPUT" and isinstance(cell_value_row_2, int):
            target_values.append(cell_value_row_2)
        if len(target_values) > 3 and cell_value_row_2 == target_values[0] - 3:
            break

    # Ensure unique target values and reverse to original order
    target_values = list(target_values)[:weeks_back][::-1]
    formula_parts = []
    for i in range(weeks_back):
        col_num = target_column - i - 1
        col_letter = get_column_letter(col_num)
        cell_value = mef_ws[f'{col_letter}2'].value
        if isinstance(cell_value, str) and cell_value.startswith('='):
            cell_value = get_value_from_formula(mef_ws, cell_value)
        if cell_value in target_values:
            formula_parts.append(f'{col_letter}1')
    if not formula_parts:
        return ''  # No matching columns found
    formula = f'=({" + ".join(formula_parts)}) / 4'
    return formula

def get_row_column_range(mef_sheet):
    try:
        sheet_col = mef_sheet['A']
        start_row, end_row = None, None
        mef_start_value = 'Inbound External'
        if mef_sheet.title == 'A150 raw data':
            mef_end_value = 'Inbound Unilever Shop # Pallets'
        else:
            mef_end_value = 'Export admin resource'
        for cell in sheet_col:
            # Check if the cell contains a formula
            if isinstance(cell.value, str) and cell.value.startswith('='):
                cell_value = get_value_from_formula(mef_sheet, cell.value)
            else:
                cell_value = cell.value

            if cell_value == mef_start_value:  # static
                start_row = cell.row
            elif cell_value == mef_end_value:  # static
                end_row = cell.row
        return start_row, end_row
    except Exception as e:
        print(f'Error in get_row_column_range: {e}')

def fill_values_in_required_column_a150_a153(mef_sheet_wb, plant, input_date, week):
    plant_sheet_mapping = {
        "A150": ("A150 raw data", "A150"),
        "A153": ("A153 raw data", "A153")
    }
    sheets = plant_sheet_mapping[plant]
    ws = mef_sheet_wb[sheets[0]]
    # ws = mef_sheet_wb['A150 raw data']
    month = datetime.strptime(input_date, '%m/%d/%Y').month
    week_num = int(week[-2:])
    target_column, month_column = get_input_data_column(ws, month, week_num)
    columns_iteration=12
    if target_column is not None:
        formula = construct_formula(ws, target_column, month_column, columns_iteration)
        print(f'Constructed formula: {formula}')
        start_row, end_row = get_row_column_range(ws)
        extrapolation = ws.cell(row=1, column=target_column).value / 7
        for row in range(start_row, end_row + 1):
            # Adjust the formula for the current row
            new_formula = formula.replace('1', str(row))
            # full_formula = f"=({new_formula} * {extrapolation})"
            full_formula = f"{new_formula} * {extrapolation}"
            ws.cell(row=row, column=month_column, value=new_formula)
            ws.cell(row=row, column=target_column, value=full_formula)

















