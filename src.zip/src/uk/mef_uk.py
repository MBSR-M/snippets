import calendar
import os
from datetime import datetime, timedelta
import warnings
from loguru import logger
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
from src.uk.mef_a150_a153 import fill_values_in_required_column_a150_a153
from src.uk.mef_a150_a153_estimation import fill_values_in_required_column_a150_a153 as fill_values_in_required_column_a150_a153_estimation
from utils import mapping_wb_path


def main(mef_sheet_wb, country, items, output_path):
    # Load the MEF sheet workbook
    mef_sheet_wb = load_workbook(mef_sheet_wb)
    # Iterate through each item in items i.e. plants
    for item in items:
        input_folder = item['input_folder']  # Input folder path
        plant = item['code']  # Plant code
        length = len(item['items'])  # Number of input files
        # Iterate through each weekly input file for the plant
        for i in range(0, length):
            # input_file_name = item['items'][i]['input_file']  # Input file name
            input_file_name = item['items'][i].get('input_file')
            if input_file_name is not None:
                input_file = os.path.join(input_folder, input_file_name)  # Full input file path
                # Load the input workbook with warnings suppressed
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")
                    input_sheet_wb = load_workbook(input_file)
            input_date = item['items'][i]['input_received_date']  # Input received date
            week = item['items'][i]['week']  # Week number
            if plant=='A150' or plant=='A153':
                if input_file_name is None and item['items'][i].get('input_type')=='Estimation':
                    fill_values_in_required_column_a150_a153_estimation(mef_sheet_wb, plant, input_date, week)
                else:
                    fill_values_in_required_column_a150_a153(mef_sheet_wb, input_sheet_wb, plant, input_date, week)
            # else:
                # Update MEF sheet with input data
                # fill_values_in_required_column(mef_sheet_wb, input_sheet_wb, plant, input_date, week)
        logger.info(f'Data updated for the plant {plant}')
    # Save the updated MEF sheet
    output_file = os.path.join(output_path, f'{country}_MEF_sheet.xlsx')
    mef_sheet_wb.save(output_file)
    logger.info(f'Saved updated MEF sheet to {output_file}')