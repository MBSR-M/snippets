from openpyxl import load_workbook
from datetime import datetime
from openpyxl.utils import get_column_letter


def get_column_value(value, ws):
    cell_value = value.strip('=')
    split_cell = cell_value.split('+')
    index_value = ws[split_cell[0]].value
    if isinstance(index_value, str):
        return get_column_value(index_value, ws) + int(split_cell[-1])
    elif isinstance(index_value, int):
        return index_value + int(split_cell[-1])


def avg_spain(mef_sheet_wb, plant, received_date,interval):
    plant_mapping = {'A250': 'A250FOOD',
                     'C506': 'C506HPC'
                     }
    date = datetime.strptime(received_date, '%m/%d/%Y')
    month = int(date.strftime("%m"))
    # wb = openpyxl.load_workbook(r"C:\Users\Gnanadeep.Manchala\Downloads\WAREHOUSING MEF ES 08.2024_MEC v1.xlsx",data_only=True)
    average = int(interval)  # extract this value from flask
    ws = mef_sheet_wb[plant_mapping[plant]]
    ws['B1'].value = month
    # Extracting Accrual column from row 1
    # def get_input_data_column(mef_sheet, month, initial_row=2):
    for row in ws.iter_rows(min_row=2, max_row=2):
        for cell in row:
            value = cell.value
            if value is None:
                continue
            elif isinstance(value, str):
                if value[0] == '=':
                    value = get_column_value(value, ws)

            if value == month:  # extract month value
                acr_column_number = cell.column
                acr_column_name = get_column_letter(cell.column)

    # getting column cell rows
    for k in ws['A']:
        if k.value == 'Actuals':
            start_row = k.row
        if k.value == 'COSTS EUR':
            end_row = k.row
    if average == 2:
        first = get_column_letter(acr_column_number - 1)
        second = get_column_letter(acr_column_number - 2)
    elif average == 3:
        first = get_column_letter(acr_column_number - 1)
        second = get_column_letter(acr_column_number - 2)
        third = get_column_letter(acr_column_number - 3)
    for r in range(start_row + 1, end_row):
        if average == 2:
            ws[acr_column_name + str(r)].value = f'=AVERAGE({first + str(r)}, {second + str(r)})'
        else:
            ws[acr_column_name + str(r)].value = f'=AVERAGE({first + str(r)}, {second + str(r)}, {third + str(r)})'
    # wb.save(r"C:\Users\Gnanadeep.Manchala\Downloads\spain\WAREHOUSING MEF ES 08.2024_MEC v1.xlsx")
