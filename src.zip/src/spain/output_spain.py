import calendar
from datetime import datetime, timedelta

import polars as pl
from loguru import logger
from openpyxl import load_workbook
from openpyxl.styles import Font, Color, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from utils import currency_code_dict,mapping_wb_path


def output_sheet_styles(ws_output):
    try:
        ws_output.sheet_view.showGridLines = False
        ws_output['A1'] = 'Unilever'
        ws_output['A1'].font = Font(bold=True, size=10, name='Segoe UI')
        ws_output['A2'] = 'Project Lotus: Blackline Journals'
        ws_output['A2'].font = Font(bold=True, size=10, name='Segoe UI')
        ws_output['A4'] = 'Journal Summary - Design template'
        ws_output['A4'].font = Font(color=Color(rgb='00FF0000'), size=10, name='Segoe UI')
        for i in range(2, 25):
            if i < 15:
                ws_output.cell(row=6, column=i, value='Source File')
            elif i > 14 and i < 23:
                ws_output.cell(row=6, column=i, value='To be added')
            elif i == 23:
                ws_output.cell(row=6, column=i, value='BL Calculated')
            ws_output.cell(row=6, column=i).font = Font(size=10, name='Segoe UI', italic=True)
        return {'message': 'styles added for sheet'}
    except Exception as e:
        print(f'Error in output_sheet_styles: {e}')


def remove_not_applicable(plant, mapping_ws, input_sheet_ws):
    not_applicable_list = []
    try:
        for i in input_sheet_ws.iter_rows(min_row=2, max_row=input_sheet_ws.max_row):
            input_value = i[6].value
            # print(input_value)
            for j in mapping_ws.iter_rows(min_row=2, max_row=mapping_ws.max_row):
                mapping_plant, mapping_value = j[1].value, j[2].value
                if mapping_value == input_value and mapping_plant == plant:
                    mapping_mef_value = j[3].value
                    # print(mapping_mef_value)
                    if mapping_mef_value.strip() == "Not Applicable":
                        not_applicable_list.append(input_value)

        return not_applicable_list
    except Exception as e:
        print(f'Error in remove_not_applicable: {e}')


def prepare_data_from_input_sheet(df, ws_output, start_row, plant, mapping_ws, input_sheet_ws):
    description_title = input_sheet_ws['G1'].value
    tariff_title = input_sheet_ws['I1'].value

    start_col = 2
    end_col = 14
    row_number = 1

    # col = ['Country','Plant','Plant name','Month/Week','Year','Activity description','Volume','Tarrif','Currency','Cost','number of days','Category','Unit of volume']
    not_applicable_list = remove_not_applicable(plant, mapping_ws, input_sheet_ws)
    # print(not_applicable_list)
    try:
        col = [cell.value for row in
               input_sheet_ws.iter_rows(min_row=row_number, max_row=row_number, min_col=start_col,
                                        max_col=end_col) for cell in row]
        # filtered_df = df.select(col)
        filtered_df = df.filter(
            (pl.col("Plant") == plant) & pl.col("Volume").is_not_null() & (pl.col("Volume") != 0) & (
                    pl.col(tariff_title) != 0) & (
                    pl.col(description_title).is_in(not_applicable_list) == False))
        # print(filtered_df)
        data = filtered_df.to_dicts()
        # Write the header row to the new sheet starting from start_row
        for idx, column_name in enumerate(col, start=2):
            ws_output.cell(row=start_row, column=idx, value=column_name)
            ws_output.column_dimensions[get_column_letter(int(idx))].width = len(column_name) + 2

        for i, row_data in enumerate(data, start=start_row + 1):
            for idx, column_name in enumerate(col, start=2):
                ws_output.cell(row=i, column=idx, value=row_data[column_name])
        # print(data)
        return data
    except Exception as e:
        print(f'Error in prepare_data_from_input_sheet: {e}')


def create_added_columns(ws_output, start_row):
    c = {'15': "Volume Based?", '16': "Group Name", '17': "GL Account", '18': "Cost Centre",
         '19': "Adjustment Rate", '20': "Total working days", '21': "Conversion Rate", '22': "Tariff in EUR",
         '23': "Total Cost"}
    try:
        for k, v in c.items():
            ws_output.cell(row=start_row, column=int(k), value=v)
            ws_output.column_dimensions[get_column_letter(int(k))].width = len(v) + 2
    except Exception as e:
        print(f'Error in create_added_columns: {e}')


############################## to be added ############################
def code_gl_cc_mapping(ws_output, mapping_ws, plant):
    map_dict = {}
    try:
        for k in ws_output.iter_rows(min_row=8, max_row=ws_output.max_row):
            value_out = k[6].value
            for j in mapping_ws.iter_rows(min_row=2, max_row=mapping_ws.max_row):
                value_map = j[2].value
                if value_out == value_map and j[1].value == plant:
                    req_row = j[2].row
                    d = {value_map: [j[14].value, j[12].value, j[13].value]}
                    map_dict.update(d)
                    break
        return map_dict
    except Exception as e:
        print(f'Error in code_gl_cc_mapping: {e}')


def put_data_into_output_from_mapping(ws_output, mapping_ws, plant, input_sheet_ws, input_date, country, rates_ws):
    try:
        map_dict = code_gl_cc_mapping(ws_output, mapping_ws, plant)
        for m in ws_output.iter_rows(max_row=ws_output.max_row, min_row=8):
            val = m[6].value
            if val is None:
                continue
            if val in map_dict.keys():
                for data in input_sheet_ws.iter_rows(min_row=2, max_row=input_sheet_ws.max_row):
                    if val == data[6].value and plant == data[2].value:
                        currency_code = data[9].value
                        # print(currency_code)
                forex_rate = 1 if currency_code.strip() == "EUR" else get_forex_rates(input_date,
                                                                                      currency_code_dict[
                                                                                          currency_code], rates_ws)
                # print(forex_rate)
                ws_output.cell(row=m[6].row, column=16, value=map_dict[val][0])
                ws_output.cell(row=m[6].row, column=17, value=map_dict[val][1])
                ws_output.cell(row=m[6].row, column=18, value=map_dict[val][2])
                ws_output.cell(row=m[6].row, column=21, value=forex_rate)
                ws_output.cell(row=m[6].row, column=22, value=f"=I{m[6].row}/U{m[6].row}")
                ws_output.cell(row=m[6].row, column=22).number_format = '0.0000000'

                for row in mapping_ws.iter_rows(min_row=mapping_ws.min_row, max_row=mapping_ws.max_row):
                    if row[2].value == ws_output.cell(row=m[6].row, column=7).value and row[
                        1].value == ws_output.cell(row=m[6].row, column=3).value:
                        volume_based = 'Y' if row[9].value == 'Volume' and not None else 'N'
                        adjustment_rate = row[8].value if type(row[8].value) in [int, float] else 0

                        ws_output.cell(row=m[6].row, column=15, value=volume_based)
                        ws_output.cell(row=m[6].row, column=19, value=adjustment_rate)
                        ws_output.cell(row=m[6].row, column=19).number_format = '0.00'
        return {'message': 'data uploaded'}
    except Exception as e:
        print(f'Error in put_data_into_output_from_mapping: {e}')


def modify_or_create_table_styles(df, ws_output, start_row, plant, mapping_ws, input_sheet_ws):
    try:
        data = prepare_data_from_input_sheet(df, ws_output, start_row, plant, mapping_ws, input_sheet_ws)
        if 'Table1' in ws_output.tables:
            tab = ws_output.tables['Table1']
            tab.ref = f"B7:W{7 + len(data)}"
            style = TableStyleInfo(name="TableStyleMedium9", showFirstColumn=False,
                                   showLastColumn=False, showRowStripes=False, showColumnStripes=True)
            tab.tableStyleInfo = style
            return {'message': 'table modified'}
        else:
            tab = Table(displayName="Table1", ref=f"B7:W{7 + len(data)}")
            style = TableStyleInfo(name="TableStyleMedium9", showFirstColumn=False,
                                   showLastColumn=False, showRowStripes=False, showColumnStripes=True)
            tab.tableStyleInfo = style
            ws_output.add_table(tab)
            return {'message': 'table created with style'}
    except Exception as e:
        print(f'Error in modify_or_create_table_styles: {e}')


# input mapping sheet

def create_columns(ws_input_working_days):
    col_names = ['months', 'month name', 'start date', 'end date', 'input received', 'days in month',
                 'total working days', 'net working days', 'extrapolation actor', 'multiplication factor']
    try:
        for ind, val in enumerate(col_names, start=1):
            var = ws_input_working_days.cell(row=1, column=ind, value=val)
            ws_input_working_days.column_dimensions[get_column_letter(ind)].width = len(val) + 2
            ws_input_working_days.cell(row=1, column=ind).fill = PatternFill("solid", fgColor="003366FF")
        return {'message': 'Columns Created'}
    except Exception as e:
        print(f'Error in create_columns: {e}')


def fill_data_in_columns(ws_input_working_days, input_date):
    try:
        # print(input_date)
        year = int(input_date.split('/')[2])
        # print(type(year))
        for row_ind, col_ind in enumerate(range(1, 13), start=2):
            ws_input_working_days.cell(row=row_ind, column=1, value=col_ind)
            ws_input_working_days.cell(row=row_ind, column=2, value=calendar.month_name[col_ind][:3])
            _, end_day = calendar.monthrange(year, col_ind)
            start_date = f"{1}/{col_ind}/{year}"
            end_date = f"{end_day}/{col_ind}/{year}"
            ws_input_working_days.cell(row=row_ind, column=3, value=start_date)
            ws_input_working_days.cell(row=row_ind, column=4, value=end_date)
            ws_input_working_days.cell(row=row_ind, column=6, value=end_day)
            ws_input_working_days.cell(row=row_ind, column=7, value=f"=NETWORKDAYS(C{row_ind},D{row_ind})")
            ws_input_working_days.cell(row=row_ind, column=8, value=f"=NETWORKDAYS(C{row_ind},E{row_ind})")
            ws_input_working_days.cell(row=row_ind, column=9, value=f"=H{row_ind}/F{row_ind}")
            ws_input_working_days.cell(row=row_ind, column=10, value=f"=1/I{row_ind}")

            ## special case input received
            row_val = int(input_date.split('/')[0])
            date = input_date.split('/')[1]
            month = input_date.split('/')[0]
            formatted_date = f'{date}/{month}/{year}'
            ws_input_working_days.cell(row=int(row_val) + 1, column=5, value=formatted_date)
        return {'message': 'date  Created in cells'}
    except Exception as e:
        print(f'Error in fill_data_in_columns: {e}')


## driver one and driver two logic
def get_driver1_driver2(mapping_ws, plant, value, volume, tariff, net_working_days, total_working_days,
                        input_received_date, total_calendar_days_in_a_month):
    calculation_dict = {
        'old_volume': 'volume',
        'old_value': 'volume'
    }
    try:
        for row in mapping_ws.iter_rows(min_row=2, max_row=mapping_ws.max_row):
            if row[1].value == plant and value == row[2].value:
                driver_1_2_condition = row[10].value
                driver_1_2_condition = driver_1_2_condition.split('&')
                # print(driver_1_2_condition)

                adjustment_rate = row[8].value
                if type(adjustment_rate) in [int, float]:
                    adjustment_rate += 1

                if len(driver_1_2_condition) == 1:
                    driver1, driver2 = 0, 0
                    return driver1, driver2, 1, 0
                for item in driver_1_2_condition:
                    item = item.split('=')
                    # print(item)
                    if item[1].strip(" ") == "net_working_days":
                        driver1 = net_working_days
                    elif item[1].strip(" ") == "input_received_date":
                        driver1 = input_received_date
                    elif item[1].strip(" ") == "total_working_days":
                        driver2 = total_working_days
                    elif item[1].strip(" ") == "total_calendar_days_in_a_month":
                        driver2 = total_calendar_days_in_a_month
                    else:
                        driver1, driver2 = 0, 0

                calculation_logic = row[11].value
                calculation_logic_parts = calculation_logic.split("=")
                logic = calculation_logic_parts[-1].split()
                calculation_logic_expression = calculation_logic_parts[-1]
                # print(calculation_logic_expression)
                # print(volume)

                for item in logic:
                    if item in calculation_dict.keys():
                        calculation_logic_expression = calculation_logic_expression.replace(item,
                                                                                            calculation_dict[
                                                                                                item])
                for item in driver_1_2_condition:
                    item = item.split('=')
                    calculation_logic_expression = calculation_logic_expression.replace(item[0], item[1]) if \
                        item[0] in calculation_logic_expression else calculation_logic_expression
                computed_value = eval(calculation_logic_expression)

                # print(driver1, driver2, adjustment_rate, computed_value)
                return driver1, driver2, adjustment_rate, computed_value

    except Exception as e:
        print(f'Error in get_driver1_driver2: {e}')


def get_item_description(value, ws):
    value = ws[value[1:]].value
    if value[0] == '=':
        return get_item_description(value, ws)
    else:
        return value


def put_driver_values(mapping_ws, plant, input_sheet_ws, ws_output, date, net_working_days, total_working_days,
                      total_calendar_days_in_a_month):
    # driver1, driver2, adjustment_rate, computed_value = 0, 0, 1, 0
    # print(date, net_working_days, total_working_days, total_calendar_days_in_a_month)
    try:
        not_applicable_list = remove_not_applicable(plant, mapping_ws, input_sheet_ws)
        print(not_applicable_list)
        for data in input_sheet_ws.iter_rows(min_row=2, max_row=input_sheet_ws.max_row):
            value = data[6].value
            if value is None or value in not_applicable_list:
                continue
            if value[0] == '=':
                value = get_item_description(value, input_sheet_ws)

            volume = data[7].value
            tariff = data[8].value
            # print(value, tariff)
            if isinstance(volume, int) or isinstance(volume, float):
                pass
            elif isinstance(volume, str) and '=' in volume:
                if "^" in volume:
                    volume = volume.replace('^', '**')
                    volume = eval(volume.strip('='))
                else:
                    volume = eval(volume.strip('='))

            if isinstance(tariff, int) or isinstance(tariff, float):
                pass
            elif isinstance(tariff, str) and '=' in tariff:
                if "^" in tariff:
                    tariff = tariff.replace('^', '**')
                    tariff = eval(tariff.strip('='))
                else:
                    tariff = eval(tariff.strip('='))

            if volume is None or volume == 0 or tariff is None or tariff == 0:
                continue
            # else:
            #     for row in mapping_ws.iter_rows(min_row=2, max_row=mapping_ws.max_row):
            #         if row[1].value == plant and value == row[2].value:
            #             driver1, driver2, adjustment_rate, computed_value = get_driver1_driver2(mapping_ws, plant, value, volume, tariff, net_working_days, total_working_days, date, total_calendar_days_in_a_month)
            driver1, driver2, adjustment_rate, computed_value = get_driver1_driver2(mapping_ws, plant, value,
                                                                                    volume, tariff,
                                                                                    net_working_days,
                                                                                    total_working_days, date,
                                                                                    total_calendar_days_in_a_month)
            # print(volume)
            for driver in ws_output.iter_rows(max_row=ws_output.max_row, min_row=8):
                # print(driver[6].value, driver[8].value, driver[2].value)
                if driver[6].value == value and round(driver[8].value, 6) == round(tariff, 6) and driver[
                    2].value == plant:
                    # print(driver[6].value)
                    row = driver[6].row
                    break
            # print(row)
            # print(computed_value)
            ws_output.cell(row=row, column=12, value=driver1)
            ws_output.cell(row=row, column=20, value=driver2)
            ws_output.cell(row=row, column=19, value=adjustment_rate)
            ws_output.cell(row=row, column=19).number_format = '0.00'
            ws_output.cell(row=row, column=23, value=f'=V{row}*{computed_value}')
            ws_output.cell(row=row, column=23).number_format = '0.00'

    except Exception as e:
        print(f'Error in put_driver_values: {e}')


def get_forex_rates(date, currency_code, rates_ws):
    quarter = {'Q1': [1, 2, 3], 'Q2': [4, 5, 6], 'Q3': [7, 8, 9], 'Q4': [10, 11, 12]}
    try:
        for k, v in quarter.items():
            if int(date.split('/')[0]) in v:
                key = k
        row_val = key + ' ' + date.split('/')[2]
        col_val = currency_code
        # column
        for c in rates_ws[7]:
            if c.value == row_val:
                req_col = get_column_letter(c.column)
        # row
        for r in rates_ws['C']:
            if r.value == col_val:
                req_row = r.row
        return round(rates_ws[req_col + str(req_row)].value, 7)
    except Exception as e:
        print(f'Error in get_forex_rates: {e}')


def get_working_days(input_date):
    net_working_days, total_working_days = 0, 0
    try:
        input_date = datetime.strptime(input_date, '%m/%d/%Y')
        start_date = input_date.replace(day=1)
        if input_date.month == 12:
            end_date = input_date.replace(year=input_date.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            end_date = input_date.replace(month=input_date.month + 1, day=1) - timedelta(days=1)

        # print(input_date, start_date, end_date)

        while start_date <= input_date:
            # Check if the current day is a weekday
            if start_date.weekday() < 5:
                net_working_days += 1
            start_date += timedelta(days=1)

        start_date = input_date.replace(day=1)
        while start_date <= end_date:
            # Check if the current day is a weekday
            if start_date.weekday() < 5:
                total_working_days += 1
            start_date += timedelta(days=1)

        return net_working_days, total_working_days
    except Exception as e:
        print(f'Error in get_working_days: {e}')


def main(input_date, country, plant, rates_ws, ws_output, ws_input_working_days, df, input_sheet_ws):
    # cur_dir = os.getcwd()
    # path = os.path.join(cur_dir, 'Country_Inputdays_Mapping_11th June.xlsx')
    mapping_wb = load_workbook(mapping_wb_path)
    # Country_Inputdays_Mapping_11th Je.xlsx
    mapping_ws = mapping_wb['Activity_Description_Mapping']

    date = datetime.strptime(input_date, '%m/%d/%Y').day  # added
    month = datetime.strptime(input_date, '%m/%d/%Y').month  # added
    year = datetime.strptime(input_date, '%m/%d/%Y').year  # added
    total_calendar_days_in_a_month = calendar.monthrange(year, month)[1]  # added

    start_row = 7

    net_working_days, total_working_days = get_working_days(input_date)

    # creat input working sheet
    create_columns(ws_input_working_days)
    fill_data_in_columns(ws_input_working_days, input_date)
    ### style the output sheet
    output_sheet_styles(ws_output)
    ### add data from input
    prepare_data_from_input_sheet(df, ws_output, start_row, plant, mapping_ws, input_sheet_ws)
    ### add added columns
    create_added_columns(ws_output, start_row)
    ### add table to sheet
    modify_or_create_table_styles(df, ws_output, start_row, plant, mapping_ws, input_sheet_ws)
    ### put code, GL, CC data in output
    put_data_into_output_from_mapping(ws_output, mapping_ws, plant, input_sheet_ws, input_date, country, rates_ws)
    ### put drives data
    put_driver_values(mapping_ws, plant, input_sheet_ws, ws_output, date, net_working_days, total_working_days,
                      total_calendar_days_in_a_month)
    logger.info(f"output sheet created for the pant: {plant}")
