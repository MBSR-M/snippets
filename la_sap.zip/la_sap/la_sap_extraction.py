import os
import glob
import re
import shutil
from loguru import logger

from la_sap.text_clean import get_df_from_txt


def extract():
    # Define the directory containing the files and the prefix
    directory = r'//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/UFO-General/INTERFACE/S1P/'
    prefix = 'UFO_LogisticsAccrual'  # 'UFO_LogisticsAccrual'

    # Regular expression to match the prefix and timestamp (assuming the timestamp is 8 digits)
    pattern = re.compile(rf'{prefix}.(\d{{8}})')

    # Get the list of files that match the pattern
    file_list = [os.path.normpath(file) for file in glob.glob(os.path.join(directory, f'{prefix}*')) if
                 pattern.match(os.path.basename(file))]
    try:
        file = file_list[-1]
        source = file
        destination_dir = r'//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/SCFS1/3Informatn/15. PROJECT/17.logistics_accruals/SAP_log_accruals/Input_files/'
        destination_file = os.path.join(destination_dir, 'Accruals_SAP_Import.txt')
        # Copy the file and rename it in the process
        shutil.copy(source, destination_file)
        logger.info(f'Copied and renamed {source} to {destination_file}')
        get_df_from_txt(destination_file)
        logger.info("Transformed Excel File")
    except IndexError:
        logger.info("There is no file in S1P input folder")
    except Exception as e:
        logger.exception(f'Error in SAP Import: {e}')
