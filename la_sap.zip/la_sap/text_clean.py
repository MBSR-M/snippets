import os

import pandas as pd
from loguru import logger


def get_df_from_txt(file_path):
    # Check if file exists
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"The file at {file_path} was not found.")

    # Read the file into a list of lines
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
    except Exception as e:
        raise IOError(f"An error occurred while reading the file: {e}")

    # Initialize a list to hold the data
    data = []

    # Define your custom headers
    custom_headers = ['Cost element descr.', 'Cost element name', 'Document Date', 'Period', 'Cost Center',
                      'Cost Element', 'From Period', 'User Name', 'Vbl. value/TranCurr.', 'Vbl. value/Obj. curr',
                      'Val/COArea Crcy', 'Document Header Text', 'Name of offsetting account', 'Offsetting acct no.',
                      'Name', 'Document Number', 'Company Code', 'Document type', 'Functional Area', 'Posting Date',
                      'Ref. document number', 'Transaction Currency', 'Val.in rep.cur.', 'CO area currency',
                      'Purchase order text', 'Purchasing Document', 'Name of offsetting account', 'Fiscal Year',
                      'Dr/Cr indicator', 'Posting row', 'Version', 'Business Transaction', 'Time created',
                      'Object type', 'Object', 'To Period', 'Created on', 'Reversal document', 'Reversed',
                      'Ref.document type', 'Ref. company code', 'Ref. fiscal year', 'Original bus. trans', 'Value date',
                      'Exchange Rate Type', 'Reference procedure', 'Reference org. unit', 'Time of Entry', 'Value Type',
                      'Posting row', 'Item', 'Debit type', 'Ledger', 'Row in op. version', 'CO object name',
                      'Object type', 'FI Posting Item', 'Offsetting account type', 'Object Currency',
                      'Posted unit of meas.', 'Value TranCurr', 'Value in Obj. Crcy', 'Report currency',
                      'Vbl.Val./COCrcy', 'Var.val.in rep.cur.', 'Total quantity', 'Plant', 'Plant', 'Country']

    # # Iterate through lines and skip header detection
    for line in lines:
        stripped_line = line.strip()
        if stripped_line.startswith('+'):  # Ignore separator lines
            continue
        elif stripped_line.startswith('|'):  # Process data lines
            data.append([element.strip() for element in stripped_line.split('|')[1:-1]])

    data = data[21:]
    # Convert to DataFrame using custom headers
    df = pd.DataFrame(data, columns=custom_headers[:len(data[0])])

    # Remove rows that are completely empty
    df.dropna(axis=0, how='all', inplace=True)
    df = df.drop(df[df['Document Date'] == 'Doc. Date'].index)
    output_path = r'\\S2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\SCFS1\3Informatn\15. PROJECT\17.logistics_accruals\SAP_log_accruals\Cleaned_excel_files\cleaned_data.xlsx'
    df.to_excel(output_path, index=False)
    logger.info(f"Data successfully written to {output_path}")
    return df


