from la_sap_extraction import extract
from loguru import logger

if __name__ == '__main__':
    try:
        extract()
        logger.info("Data Extraction Process is completed")
    except Exception as e:
        logger.error({'error': f"got an error {e}", 'error_message': "Data Extraction Process is not completed"})
