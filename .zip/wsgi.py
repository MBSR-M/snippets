from src import create_app
app = create_app()

if __name__ == "__main__":
    app.jinja_env.cache = {}
    # app.run(debug=True, port=888, use_reloader=True)
    app.run(debug=False, port=888, use_reloader=False) # for production
