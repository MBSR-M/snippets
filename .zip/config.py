import configparser
from datetime import datetime
import os

from db_attr import db_attr

FLASK_PAGE_FOLDER = "C:\\py_dev\\proj\\scfs_web\\"
FLASK_PAGE_LOG = f'{FLASK_PAGE_FOLDER}logs\\flask_{os.environ["COMPUTERNAME"]}_{datetime.now().strftime("%Y%m%d")}.log'


def get_constr(dbenv):
    if db_attr.get(dbenv):
        dbattr = db_attr[dbenv]
        return f'mssql+pyodbc:' \
               f'//{dbattr["uid"]}:' \
               f'{dbattr["pwd"]}@' \
               f'{dbattr["server"]}:{dbattr["port"]}/' \
               f'{dbattr["database"]}?driver={dbattr["driver"]}'


class Config:
    VERSION = "4.9.1 - 2024.12.19"
    # setx jenkins_pre_url
    BUILD_USER_LOGIN = 'BuildUser'
    BUILD_USER_PASS = 'admin'
    # every web needs one
    SECRET_KEY = '5791628bb0b13ce0c676dfde280ba245'
    # max file size
    MAX_CONTENT_LENGTH = 2147482548
    # if I'm  not wrong this will make web-browser refresh stored data
    SEND_FILE_MAX_AGE_DEFAULT = 360
    # default template and static folder name
    TEMPLATE_FOLDER = 'templates'
    STATIC_FOLDER = "static"

    dr_config = configparser.ConfigParser()
    dr_config.read('C://py_dev//servers_mapping.ini')

    SQLALCHEMY_DATABASE_URI = get_constr(dr_config['servers']['env'])
    JENKINS_PRE_URL = dr_config['servers']['JENKINS_PRE_URL']
    BOOTSTRAP_BOOTSWATCH_THEME = dr_config['servers']['BOOTSTRAP_BOOTSWATCH_THEME']

    BOOTSTRAP_SERVE_LOCAL = True
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    BOOTSTRAP_BTN_STYLE = 'primary'

    # sql engine option to return results
    ENGINE_OPTIONS = {"echo": True}
    INSTANCE_RELATIVE_CONFIG = False

    # scfs specific config
    S1P = r"//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/UFO-General/INTERFACE/S1P/"
    P1P = r'//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/UFO-General/INTERFACE/P1P/'
