//@todo insert into forms MultipleFileField value for data_url == route
$("#input_file").attr('data-url', $("#data_url").val());

//acctual overide of input with input bar
$("#input_file").fileupload({
    dataType: "json",
    replaceFileInput: false,
    progressInterval: 1,
    add: function (e, data) {

        $("#submit_upload").click(function () {
            data.submit();
            event.preventDefault();
        });
        if (!(/\.(txt|csv|xlsx|xlsb|xlsm)$/i).test(data.files[0].name)) {
            alert("format not allowed");
            return;
        }
        data.context = $('<div class="progress-bar bg-secondary" style="width: 0%; margin-top: 1rem"></div>')
            .text(data.files[0].name)
            .insertAfter("#input_file");
    },
    progress: function (e, data) {
        console.log(data.loaded);
        var progress = parseInt((data.loaded / data.total) * 100, 10);

        if(progress == 100){
              data.context.text("saving to drive");
        }
        data.context.width(progress + "%");
    },
    done: function (e, data) {
        data.context.addClass("done");

        if($('.progress-bar:not(.done)').length == 0) {
            location.reload();
        }
    }
});