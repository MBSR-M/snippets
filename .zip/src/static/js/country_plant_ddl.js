$(document).ready(function () {
    $("#country").on("change", populatePlants);

    const processCheckboxes = $('fieldset [id*="is_active"]')
    processCheckboxes.on("change", ifProcessPlant);

    $('fieldset [id*="country"]').parent().parent().addClass("d-none")
    $('.is_hidden').parent().addClass('d-none')
    $('fieldset fieldset legend label').hide()
});

function populatePlants() {
    const processCheckboxes = $('fieldset [id*="is_active"]')
    processCheckboxes.prop('checked', true);

    const allRows = $('fieldset fieldset')
    allRows.addClass('d-flex flex-row').removeClass("d-none")
    allRows.find('input, select').attr('disabled', false);

    const selectedCountryCode = $('#country').val();
    let countryRows = $('fieldset [id*="country"]').filter(function () {
        return $(this).val() !== selectedCountryCode;
    }).parent().parent();

    countryRows.addClass("d-none").removeClass('d-flex flex-row')
    countryRows.find('input, select').attr('disabled', true);

    $('fieldset [id*="plant_name"]').attr('readonly', true);
}

function ifProcessPlant(eventData) {
    let isChecked = $(this).prop("checked");
    $(this).parent().siblings().find('input, select').attr('disabled', !isChecked);
}



