from flask import Blueprint, render_template
import logging
log = logging.getLogger(__name__)



errors_bp = Blueprint('errors', __name__, static_folder='static', template_folder='templates')


@errors_bp.app_errorhandler(404)
def error_404(error):
    log.info(f'{error}')
    return render_template('errors/error.html', title='404', description=f"{error}")


@errors_bp.app_errorhandler(403)
def error_403(error):
    log.info(f'{error}')
    return render_template('errors/error.html', title='403', description=f"{error}")


@errors_bp.app_errorhandler(500)
def error_500(error):
    log.info(f'{error}')
    return render_template('errors/error.html', title='500', description=f"{error}")
