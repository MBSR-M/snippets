import logging

from flask import Blueprint, render_template, session
from flask_login import current_user

from src.projects.etl_config import hosted_projects

log = logging.getLogger(__name__)

main = Blueprint('main', __name__, static_folder='static', template_folder='template')


@main.route('/')
@main.route('/home')
def home():
    title = ''
    description = ''
    session['breadcrumb'] = None

    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(hosted_projects)
        if current_user.projects_access == 'new_user':
            title = 'welcome'
            description = 'Please note that admins are informed about new users' \
                          'but if time is important for you, drop quick request with ' \
                          'name of you project on MS Teams to Andrzej Ostromecki.'
    else:
        log.info('guest')
        projects = []

    return render_template("index.html", projects=projects, title=title, description=description)
