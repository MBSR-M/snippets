#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from flask_wtf import FlaskForm
from wtforms import HiddenField, MultipleFileField, SubmitField, FileField
from wtforms.fields.choices import SelectField
from wtforms.validators import InputRequired


# manually add new elements of naw var
# home is used in all default redirect to...home
# login, account, register, logout - related to user
#  @todo add admin , admin is for all administrative roles
class NavBar:
    home = {'url': 'main.home', 'name': 'Home'}
    admin = {'url': 'admin.main', 'name': 'Admin'}
    about = {'url': 'about', 'name': 'About'}
    login = {'url': 'users.login', 'name': 'Login'}
    account = {'url': 'users.account', 'name': 'Account'}
    registration = {'url': 'users.registration', 'name': 'Register'}
    logout = {'url': 'users.logout', 'name': 'Logout'}


class DownloadReport(FlaskForm):
    # @todo is this used?
    #  blueprint have url button for downloading reports in gridtable control
    download_latest_report = SubmitField("Download Report")


class RedirectUrlTrigger:
    """Data transfer class
    urls, name and target will be provided in implementation
    """
    url = ""
    name = ""
    target = "_self"


class InputFilesForm(FlaskForm):

    input_file = MultipleFileField("Select input file(s) ", validators=[InputRequired()])
    data_url = HiddenField("data-url")
    submit_upload = SubmitField("Upload")

    def url(self, url):
        self.data_url.data = url

class DownloadBPQFilesForm(FlaskForm):
    select_field = SelectField(
        label='Select report to download',
        choices=[('', 'Select a file type'),
                 ('Resource Volume Report', 'Resource Volume Report'),
                 ('CET Data Pivot Report', 'CET Data Pivot Report'),
                 ('Resource Description Report', 'Resource Description Report'),
                 ],
        validators=[InputRequired()],
        render_kw={"class": "form-control"}
    )
    data_url = HiddenField("data-url")
    submit_download = SubmitField("Download Report")

    def url(self, url):
        self.data_url.data = url


class MaterialToolsForm(FlaskForm):
    input_file = FileField("Upload csv file", validators=[InputRequired(message='csv only')])
    data_url = HiddenField("data-url")
    start_store_process = SubmitField(label="Start Store Procedure", default=False,
                                      render_kw={"class": "btn btn-primary"},
                                      description="When file is uploaded here and submit start "
                                                  "store process, it will save the input files in remote and"
                                                  "starts a background process to run the store procedure.")

    def url(self, url):
        self.data_url.data = url


class SpendAnalysisForm(FlaskForm):
    input_file = FileField("Upload csv file", validators=[InputRequired(message='csv only')])
    data_url = HiddenField("data-url")
    start_store_process = SubmitField(label="Start Store Procedure", default=False,
                                      render_kw={"class": "btn btn-primary"},
                                      description="When file is uploaded here and submit start "
                                                  "store process, it will save the input files in remote and"
                                                  "starts a background process to run the store procedure.")

    def url(self, url):
        self.data_url.data = url



class Input_CMIR_AMS_Files_Form(FlaskForm):
    """input cmir ams files"""
    select_field = SelectField(
        label='Select file to upload',
        choices=[('', 'Select a file type'),
                 ('UOM Conversion', 'UOM Conversion'),
                 ('CMIR AMS POC', 'CMIR AMS POC'),
                 ('Currency Conversion', 'Currency Conversion'),
                 ],
        validators=[InputRequired()],
        render_kw ={"class": "form-control"}
    )
    input_file = MultipleFileField("Select input file", validators=[InputRequired()])
    data_url = HiddenField("data-url")
    submit_upload = SubmitField("Upload to database")

    def url(self, url):
        self.data_url.data = url