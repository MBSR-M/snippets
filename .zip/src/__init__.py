"""Initialize Flask Application.
"""
from datetime import datetime
import logging

from flask import Flask
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_bootstrap import Bootstrap4
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect

from config import Config, FLASK_PAGE_LOG

from src.main.forms import NavBar

b4 = Bootstrap4()
csrf = CSRFProtect()
db = SQLAlchemy()
from src.logs.models import UserActivityLog, DatabaseLogHandler

bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'
log_today = datetime.now().strftime("%Y-%m-%d")


def create_app(config_class=Config):
    app = Flask(__name__)
    cfg = Config()
    app.config.from_object(cfg)

    logger = logging.getLogger(__name__)
    # log_format = logging.Formatter('%(asctime)s|%(name)s|%(funcName)s|user:%(message)s')

    # file_handle = logging.FileHandler(FLASK_PAGE_LOG)
    # file_handle.setFormatter(log_format)
    # logger.addHandler(file_handle)

    db_handler = DatabaseLogHandler()
    # db_handler.setFormatter(log_format)
    # db_handler.setLevel(logging.INFO)
    logger.addHandler(db_handler)

    b4.init_app(app)
    csrf.init_app(app)
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    # config for jinja to drop extra new lines in html - if you review html code source it looks nice this way
    app.jinja_env.trim_blocks = True
    app.jinja_env.lstrip_blocks = True

    # importing blueprints for
    from src.main.routes import main
    from src.admin.routes import admin_bp
    from src.errors.routes import errors_bp
    from src.users.routes import users_bp

    # importing blueprints for global plant list
    from src.projects.gpl_eur.gpl_xls_eur import gpl_etl_eur_bp
    from src.projects.gpl_eur.gpl_xls_ams import gpl_etl_ams_bp
    from src.projects.gpl_eur.gpl_xls_eur import gpl_manage_eur_bp
    from src.projects.gpl_eur.gpl_xls_ams import gpl_manage_ams_bp

    # importing blueprints for logistics accrual
    from src.projects.logistics_accruals.routes import log_accruals_bp
    from src.projects.logistics_accruals.log_accruals import log_accruals_generate_bp

    # importing blueprints for local tax
    from src.projects.local_tax.routes import local_tax_bp
    from src.projects.local_tax.be_bev import be_bev_bp

    # importing blueprints for make
    from src.projects.make_analytics.routes import make_analytics_bp
    from src.projects.make_analytics.make_costing import make_costing_bp
    from src.projects.make_analytics.costing_simulation import costing_simulation_bp

    # importing blueprints for tp_update - cop
    from src.projects.tp_update.routes import tp_update_bp
    from src.projects.tp_update.cop2 import cop2_bp

    # importing blueprints for bpq robot
    from src.projects.bpq_robot_rpm.routes import bpq_robot_rpm_bp
    from src.projects.bpq_robot_rpm.bpq_robot_rpm import bpq_rpm_bp
    from src.projects.bpq_robot_rpm.bpq_downloads import bpq_download
    from src.projects.bpq_robot_rpm.store_procedures import material_tools_store_procedures
    from src.projects.bpq_robot_rpm.gaia import gaia_bp

    # importing blueprint for cmir
    from src.projects.cmir.routes import cmir_bp
    from src.projects.cmir.cmir_poc import cmir_poc_bp

    # importing blueprint for cmir
    from src.projects.cmir_ams.routes import cmir_ams_bp
    from src.projects.cmir_ams.cmir_ams_poc import cmir_ams_poc_bp

    # importing blueprint for pmc_eur
    from src.projects.pmc_eur.routes import pmc_eur_bp
    from src.projects.pmc_eur.pmc_eur import pmc_eur_bpq_bp

    # importing blueprints for tm1
    from src.projects.rubiks_vs_su.routes import rubiks_vs_su_bp
    from src.projects.rubiks_vs_su.tm1 import tm1_bp

    # importing blueprints for innovation_costing
    from src.projects.innovation_costing.routes import innovation_costing_team_bp
    from src.projects.innovation_costing.innovation_costing import innovation_costing_bp

    from src.projects.fet.fet import fet_na_bp
    from src.projects.fet.route import fet_bp

    # importing blueprints for TWC
    from src.projects.twc.routes import twc_bp
    from src.projects.twc.twc import sproc_bp

    # import blueprints for ams_driverless_na_bu_split
    from src.projects.driverless_na_bu_split.routes import driverless_na_bu_split_bp
    from src.projects.driverless_na_bu_split.ams_driverless_na_bu_split import ams_driverless_na_bu_split_bp

    # import blueprints for ams_driverless_na_fcst
    from src.projects.driverless_na_fcst.routes import driverless_na_fcst_bp
    from src.projects.driverless_na_fcst.ams_driverless_na_fcst import ams_driverless_na_fcst_bp

    # import blueprints for ams_driverless_na_fcst
    from src.projects.primary_tracker.routes import primary_tracker_bp
    from src.projects.primary_tracker.eur_primary_tracker_billing import eur_primary_tracker_billing_bp
    from src.projects.primary_tracker.eur_primary_tracker_accrual import eur_primary_tracker_accrual_bp
    from src.projects.primary_tracker.eur_primary_tracker_segmentation import eur_primary_tracker_segmentation_bp

    # importing blueprints for TWC
    from src.projects.twc_ams.routes import twc_ams_bp
    from src.projects.twc_ams.ams_twc_all_marlin_db import ams_twc_all_marlin_db_bp
    from src.projects.twc_ams.ams_twc_captain_a_split import ams_twc_captain_a_split_bp
    from src.projects.twc_ams.ams_twc_marlin_fcst import ams_twc_marlin_fcst_bp
    from src.projects.twc_ams.ams_twc_victory import ams_twc_victory_bp

    # importing blueprints for Depreciation Forecast
    from src.projects.depreciationfc.routes import depreciationfc_bp
    from src.projects.depreciationfc.depreciation import df_bp

    # register blueprints with url
    app.register_blueprint(main)
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(users_bp, url_prefix='/users')

    app.register_blueprint(gpl_etl_eur_bp, url_prefix='/gpl_eur')
    app.register_blueprint(gpl_manage_eur_bp, url_prefix='/gpl_eur')
    app.register_blueprint(gpl_etl_ams_bp, url_prefix='/gpl_ams')
    app.register_blueprint(gpl_manage_ams_bp, url_prefix='/gpl_ams')

    app.register_blueprint(log_accruals_bp, url_prefix='/log_accruals')
    app.register_blueprint(log_accruals_generate_bp, url_prefix='/log_accruals/log_accruals_generate')

    app.register_blueprint(tp_update_bp, url_prefix='/tp_update')
    app.register_blueprint(cop2_bp, url_prefix='/tp_update/cop2')

    app.register_blueprint(bpq_robot_rpm_bp, url_prefix='/bpq_robot_rpm')
    app.register_blueprint(bpq_rpm_bp, url_prefix='/bpq_robot_rpm/bpq_rpm')
    app.register_blueprint(bpq_download, url_prefix='/bpq_robot_rpm/bpq_download')
    app.register_blueprint(material_tools_store_procedures, url_prefix='/bpq_robot_rpm/store_procedures')
    app.register_blueprint(gaia_bp, url_prefix='/bpq_robot_rpm/gaia')

    app.register_blueprint(errors_bp, url_prefix='/errors')

    app.register_blueprint(local_tax_bp, url_prefix='/local_tax')
    app.register_blueprint(be_bev_bp, url_prefix='/local_tax/be_bev')

    app.register_blueprint(make_analytics_bp, url_prefix='/make_analytics')
    app.register_blueprint(make_costing_bp, url_prefix='/make_analytics/make_costing')
    app.register_blueprint(costing_simulation_bp, url_prefix='/make_analytics/costing_simulation')

    app.register_blueprint(cmir_bp, url_prefix='/cmir')
    app.register_blueprint(cmir_poc_bp, url_prefix='/cmir/cmir_poc')

    app.register_blueprint(cmir_ams_bp, url_prefix='/cmirams')
    app.register_blueprint(cmir_ams_poc_bp, url_prefix='/cmirams/cmir_ams_poc')

    app.register_blueprint(pmc_eur_bp, url_prefix='/pmc_eur')
    app.register_blueprint(pmc_eur_bpq_bp, url_prefix='/pmc_eur/pmc_eur_bpq')

    app.register_blueprint(rubiks_vs_su_bp, url_prefix='/rubiks_vs_su')
    app.register_blueprint(tm1_bp, url_prefix='/rubiks_vs_su/tm1')

    app.register_blueprint(innovation_costing_team_bp, url_prefix='/innovation_costing')
    app.register_blueprint(innovation_costing_bp, url_prefix='/innovation_costing/innovation_costing_proj')

    app.register_blueprint(fet_bp, url_prefix='/fet')
    app.register_blueprint(fet_na_bp, url_prefix='/fet/fet_na')

    app.register_blueprint(twc_bp, url_prefix='/twc')
    app.register_blueprint(sproc_bp, url_prefix='/twc/twc_proj')

    app.register_blueprint(driverless_na_bu_split_bp, url_prefix='/driverless_na_bu_split')
    app.register_blueprint(ams_driverless_na_bu_split_bp,
                           url_prefix='/driverless_na_bu_split/ams_driverless_na_bu_split')

    app.register_blueprint(driverless_na_fcst_bp, url_prefix='/driverless_na_fcst')
    app.register_blueprint(ams_driverless_na_fcst_bp, url_prefix='/driverless_na_fcst/ams_driverless_na_fcst')

    app.register_blueprint(primary_tracker_bp, url_prefix='/primary_tracker')
    app.register_blueprint(eur_primary_tracker_segmentation_bp,
                           url_prefix='/primary_tracker/eur_primary_tracker_segmentation')
    app.register_blueprint(eur_primary_tracker_billing_bp, url_prefix='/primary_tracker/eur_primary_tracker_billing')
    app.register_blueprint(eur_primary_tracker_accrual_bp, url_prefix='/primary_tracker/eur_primary_tracker_accrual')

    app.register_blueprint(twc_ams_bp, url_prefix='/twc_ams')
    app.register_blueprint(ams_twc_all_marlin_db_bp, url_prefix='/twc_ams/ams_twc_all_marlin_db')
    app.register_blueprint(ams_twc_captain_a_split_bp, url_prefix='/twc_ams/ams_twc_captain_a_split')
    app.register_blueprint(ams_twc_marlin_fcst_bp, url_prefix='/twc_ams/ams_twc_marlin_fcst')
    app.register_blueprint(ams_twc_victory_bp, url_prefix='/twc_ams/ams_twc_victory')

    app.register_blueprint(depreciationfc_bp, url_prefix='/depreciationfc')
    app.register_blueprint(df_bp, url_prefix='/depreciationfc/depreciationfc_proj')

    # nav bar is global so should be provided on application init
    @app.context_processor
    def nav():
        return dict(nav=NavBar, version=cfg.VERSION)

    return app
