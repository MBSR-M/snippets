import logging

from flask import Blueprint, render_template, request, session, redirect, url_for
from flask_login import current_user, login_required

from config import Config
from src import db

log = logging.getLogger(__name__)

admin_bp = Blueprint('admin', __name__, static_folder='static', template_folder='templates')


@admin_bp.route('/main')
@login_required
def main():
    if not session["is_admin"]:
        return redirect(url_for('main.home'))

    log.info(f'{current_user.email}')
    log.info(f'{request.remote_addr}')
    cfg = Config()

    user_activity = [
        {"url": "users_activity_log", "name": "user activity log"},
        {"url": "users_table", "name": "user table"}
    ]
    session['breadcrumb'] = None
    url = cfg.JENKINS_PRE_URL
    return render_template("admin/admins.html",
                           user_activity=user_activity,
                           cfg=cfg, title='',
                           description='',
                           url=url)


@admin_bp.route('/uplog')
@login_required
def process():
    path = "C:\\py_dev\\proj\\scfs_web\\logs"
    file_object: list
    row_pattern = r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\|([\w\.]+)\|([\w\.]+)\|(.*)"

    from datetime import datetime

    import os
    import re
    files = [f for f in os.listdir(path)]
    for file in files:
        file_object = []

        with open(os.path.join(path, file), 'r') as f:
            row: list = []
            for line in f:

                match = re.match(row_pattern, line, re.DOTALL)

                if match:
                    groups = match.groups()
                    row = [datetime.strptime(groups[0], "%Y-%m-%d %H:%M:%S,%f"), groups[1], groups[2], groups[3]]
                else:
                    row[3] += line

                if match:
                    file_object.append(row)

        upload_file_object(file_object)

    return redirect(url_for('main.home'))


def upload_file_object(file_object: list):
    from src.logs.models import UserActivityLog

    dict_data = [dict(zip(['timestamp', 'module', 'subroutine', 'message'], sublist)) for sublist in file_object]
    user_activity_logs = [UserActivityLog(**data) for data in dict_data]
    db.session.bulk_save_objects(user_activity_logs)
    db.session.commit()
