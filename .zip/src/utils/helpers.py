from datetime import datetime
import functools
from io import BytesIO
import os
from os import path
import zipfile

from flask import session, redirect, url_for

from config import Config as cfg


def convert_bytes(num, format_value=True):
    """This function will convert bytes to MB.... GB... etc or not
        """
    if format_value is True:
        for x in ["bytes", "KB", "MB", "GB", "TB"]:
            if num < 1024.0:
                return "%3.1f %s" % (num, x)
            num /= 1024.0
    else:
        return "%3.1f %s" % (num, "bytes")


def file_size(file_path):
    """
    this function will return the file size
    """
    if os.path.isfile(file_path):
        file_info = os.stat(file_path)
        return convert_bytes(file_info.st_size)


def get_today(format_string="%Y%m%d"):
    """
        get today in your prefered format.
        By default it S1p/P1P format YYYYMMDD
        """
    return datetime.today().strftime(format_string)


def mid(s, offset, amount):
    return s[offset - 1: offset + amount - 1]


def txt_list_printer(full_output_path, list_to_print):
    with open(full_output_path, "w") as f:
        for item in list_to_print:
            f.write("%s\n" % item)


def get_user_download_folder(add_closing_slash=True):
    from winreg import OpenKey, HKEY_CURRENT_USER, QueryValueEx
    win_reg_key = \
        r'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders'

    with OpenKey(HKEY_CURRENT_USER, win_reg_key) as key:
        downloads = \
            QueryValueEx(key, '{374DE290-123F-4565-9164-39C4925E467B}')[0]

    if add_closing_slash:
        downloads = os.path.join(downloads, "")

    return downloads


def create_myio(f_path):
    myio = BytesIO()

    with open(f_path, 'rb') as f:
        data = f.read()

    myio.write(data)
    myio.seek(0)

    return myio


def zip_file(folder, source_file_name, zip_file_name):
    z_file = zipfile.ZipFile(path.join(folder, zip_file_name), 'w')
    z_file.write(path.join(folder, source_file_name))
    z_file.close()


def create_zip(file_absolute_path):
    zipio = BytesIO()

    with zipfile.ZipFile(zipio, 'w') as zf:
        zf.write(file_absolute_path, os.path.basename(file_absolute_path))

    zipio.seek(0)

    return zipio


def project_access(code_name):
    def user_can_access(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if not session:
                return redirect(url_for('main.home'))
            if not code_name in session["projects_access_granted"]:
                return redirect(url_for('main.home'))
            else:
                return func(*args, **kwargs)

        wrapper.__name__ = func.__name__
        return wrapper

    return user_can_access


def if_user_can_access(project_code_name):
    try:
        session["projects_access_granted"]
    except:
        return True

    if project_code_name in session["projects_access_granted"]:
        return True
    return False


def build_jenkins_job(url):
    import urllib.parse
    import requests
    """Post to the specified Jenkins URL.

    `username` is a valid user, and `password` is the user's password or
    (preferably) hex API token.
    """
    # Build the Jenkins crumb issuer URL
    parsed_url = urllib.parse.urlparse(url)
    crumb_issuer_url = urllib.parse.urlunparse((parsed_url.scheme,
                                                parsed_url.netloc,
                                                'crumbIssuer/api/json',
                                                '', '', ''))
    # Use the same session for all requests
    session = requests.session()

    # GET the Jenkins crumb
    try:
        auth = requests.auth.HTTPBasicAuth(cfg.BUILD_USER_LOGIN, cfg.BUILD_USER_PASS)
    except Exception as e:
        print('error with auth BUILD_USER_LOGIN')

    r = session.get(crumb_issuer_url, auth=auth)
    json = r.json()
    crumb = {json['crumbRequestField']: json['crumb']}

    # POST to the specified URL
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    headers.update(crumb)
    session.post(url, headers=headers, auth=auth)
