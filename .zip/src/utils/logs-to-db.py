#
# import src
#
#
#
# def upload_file_object(file_object):
#     from src.logs.models import UserActivityLog
#
#     dict_data = [dict(zip(['timestamp', 'module', 'subroutine', 'message'], sublist)) for sublist in file_object]
#     db.session.bulk_save_objects(UserActivityLog, dict_data)
#     db.session.commit()
#
#
# def process():
#     path = "C:\\py_dev\\proj\\scfs_web\\logs"
#     file_object: list
#     row_pattern = r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\|([\w\.]+)\|([\w\.]+)\|(.*)"
#     from datetime import datetime
#
#     import os
#     import re
#
#     for file in [f for f in os.listdir(path)]:
#         file_object = []
#
#         with open(os.path.join(path, file), 'r') as f:
#             row: list = []
#             for line in f:
#
#                 match = re.match(row_pattern, line, re.DOTALL)
#
#                 if match:
#                     groups = match.groups()
#                     row = [datetime.strptime(groups[0], "%Y-%m-%d %H:%M:%S,%f"), groups[1], groups[2], groups[3]]
#                 else:
#                     row[3] += line
#
#                 if match:
#                     file_object.append(row)
#
#         upload_file_object(file_object)
#
#
# if __name__ == "__main__":
#     process()
#
# # read each file
# # read each row
# # split by pipe
# # map additionals : user, machine
# # upload to db
# # display new userform with pagination, order by desc
# pass
