IF OBJECT_ID('SCFS_WEB.Logs', 'U') IS NOT NULL
    DROP Table SCFS_WEB.FilesLogs;
go



create table SCFS_WEB.FilesLogs
(
    id                  int identity,
    project_folder varchar(800) not null,
    file_name           varchar(200) not null,
    user_name           varchar(200) not null,
    timestamp          varchar(200) not null
)
go

create unique index Logs_id_uindex
    on SCFS_WEB.FilesLogs (id)
go

alter table SCFS_WEB.FilesLogs
    add constraint Logs_pk
        primary key nonclustered (id)
go

