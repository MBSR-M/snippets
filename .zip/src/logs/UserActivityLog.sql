-- auto-generated definition
create table SCFS_WEB.UserActivityLog
(
    id         bigint identity
        constraint UserActivityLog_pk
            primary key,
    date       datetime
        constraint UQ_UserActivityLog_date
            unique,
    module     varchar(max),
    [function] varchar(max),
    message    varchar(max),
    [user]     varchar(max),
    machine    varchar(max)
)
go

