from datetime import datetime
import logging
import socket
from contextlib import contextmanager
from sqlalchemy.orm import sessionmaker
from flask_login import current_user

from src import db

logger = logging.getLogger(__name__)

class FilesLogs(db.Model):
    """Logging file upload process
    file upload person provided in import is retrieved from hire
    """
    __table_args__ = {"schema": "SCFS_WEB"}
    __tablename__ = "FilesLogs"
    id = db.Column(db.Integer, primary_key=True)
    project_folder = db.Column(db.String(200), nullable=False)
    file_name = db.Column(db.String(200), nullable=False)
    user_name = db.Column(db.String(200), nullable=False)
    timestamp = db.Column(db.String(200), nullable=False)


class UserActivityLog(db.Model):
    __tablename__ = 'UserActivityLog'
    __table_args__ = (db.UniqueConstraint('timestamp', name='UQ_UserActivityLog_date'), {"schema": "SCFS_WEB"})

    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, unique=True)
    module = db.Column(db.String(max))
    subroutine = db.Column(db.String(max))
    message = db.Column(db.String(max))
    user_name = db.Column(db.String(max))
    machine = db.Column(db.String(max))



# class DatabaseLogHandler(logging.Handler):
#     def emit(self, record):
#         session = db.session
#         try:
#             timestamp = datetime.fromtimestamp(record.created)
#             if current_user.is_authenticated:
#                 user_name = current_user.email
#             else:
#                 user_name = 'user not logged in'
#
#             machine = socket.gethostname()
#             message = record.msg
#
#             log_entry = UserActivityLog(timestamp=timestamp, module=record.module, subroutine=record.funcName,
#                                         message=message,user_name=user_name,machine=machine)
#             session.add(log_entry)
#             session.commit()
#         except Exception as e:
#             session.rollback()
#             logger.info(f"An error occurred while logging: {str(e)}")
#         finally:
#             session.close()

@contextmanager
def get_session():
    session = sessionmaker(bind=db.engine)()
    try:
        yield session
        session.commit()
    except Exception as e:
        logger.info(f"An error occurred while logging: {str(e)}")
        session.rollback()
        raise
    finally:
        session.close()

class DatabaseLogHandler(logging.Handler):
    def emit(self, record):
        with get_session() as session:
            try:
                timestamp = datetime.fromtimestamp(record.created)
                if current_user.is_authenticated:
                    user_name = current_user.email
                else:
                    user_name = 'user not logged in'

                machine = socket.gethostname()
                message = record.msg

                log_entry = UserActivityLog(
                    timestamp=timestamp,
                    module=record.module,
                    subroutine=record.funcName,
                    message=message,
                    user_name=user_name,
                    machine=machine
                )
                session.add(log_entry)
            except Exception as e:
                logging.getLogger(__name__).info(f"An error occurred while logging: {str(e)}")

