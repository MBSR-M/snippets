import logging

from flask import Blueprint, render_template, session
from flask_login import current_user, login_required

from src.projects.etl_config import local_tax
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

local_tax_bp = Blueprint('local_tax', __name__, static_folder='static', template_folder='templates')


@local_tax_bp.route('/')
@local_tax_bp.route('/main')
@project_access(local_tax_bp.name)
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(local_tax)
        session['breadcrumb'] = None
    else:
        log.info(f'guest')
        projects = []

    return render_template("index.html", projects=projects,
                           title="Local Tax Katowice",
                           description="Local Tax declarations")
