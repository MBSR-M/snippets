import logging

from flask import Blueprint, render_template, session
from flask_login import current_user, login_required

from src.projects.etl_config import twc
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

twc_bp = Blueprint('twc', __name__, static_folder='static', template_folder='templates')


@twc_bp.route('/')
@twc_bp.route('/main')
@project_access(twc_bp.name)
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(twc)
        session['breadcrumb'] = None
    else:
        log.info('guest')
        projects = []

    return render_template("index.html", projects=projects,
                           title="",
                           description="")
