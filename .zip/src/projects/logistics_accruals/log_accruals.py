#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging

from flask import render_template, session, request
from flask_login import login_required, current_user

from src.main.forms import RedirectUrlTrigger
from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import LogAccrualsConfig
from src.projects.files_grid import FilesGrid
from src.projects.logistics_accruals.forms import CountryForm
from src.projects.logistics_accruals.payload import Payload
from src.utils.helpers import project_access, build_jenkins_job

log = logging.getLogger(__name__)

cfg = LogAccrualsConfig()
log_accruals_generate_bp = BlueprintETL(cfg, cfg.BLUEPRINT_NAME, cfg.PROJ_CODE_NAME).blueprint


@log_accruals_generate_bp.route('/etl', methods=['GET', 'POST'])
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    session['breadcrumb'] = [(request.url_root + cfg.parent_project["url"], 'Back'), ('log_accruals', 'log accruals')]
    files_grids = list()
    xls_reports_table = FilesGrid(cfg, cfg.OUTPUTS_FOLDER, cfg.OUTPUTS_FOLDER_EXTENSION)
    xls_reports_table.caption = 'Reports'
    xls_reports_table.download = True
    xls_reports_table.delete = True
    files_grids.append(xls_reports_table) # COMMENTED WHILE TESTING
    mef_file: RedirectUrlTrigger = RedirectUrlTrigger()
    mef_file.url = cfg.mef_file
    mef_file.name = "Jenkins MEF file>"
    mef_file.target = "_blank"
    output_file: RedirectUrlTrigger = RedirectUrlTrigger()
    output_file.url = cfg.output_file
    output_file.name = "Jenkins Output file>"
    output_file.target = "_blank"
    submit_both: RedirectUrlTrigger = RedirectUrlTrigger()
    submit_both.url = cfg.submit_both
    submit_both.name = "Jenkins both files>"
    submit_both.target = "_blank"
    buttons = [mef_file, output_file
        # , submit_both
               ]
    form = CountryForm(form_name='CountryForm')
    if request.method == 'POST':
        buttons_triggers = []
        if request.form.get('submit_both'):
            buttons_triggers.append("output_file")
            buttons_triggers.append("mef_file")
        if request.form.get('submit_output'):
            buttons_triggers.append("output_file")
        if request.form.get('submit_mef'):
            buttons_triggers.append("mef_file")
        urls = []
        for trigger_button in buttons_triggers:
            payload: Payload = Payload(cfg=cfg, forms_data=form, trigger_button=trigger_button)
            payload.process_form_data()
            payload.save_request_json()
            payload.jenkins_url = cfg.get_jenkins_url(trigger_button, current_user.email, payload.request_signal_file)
            urls.append(payload.jenkins_url)
            del payload
        for jenkins_url in urls:
            log.info(f'triggering:\n{jenkins_url}')
            build_jenkins_job(jenkins_url) # COMMENTED WHILE TESTING
    form.process(data={'plants_form': form.entries_data})
    for plant_form, entry_data in zip(form.plants_form.entries, form.entries_data):
        if not entry_data['select_field_enable'] and not entry_data['accept_weekly_data']:
            plant_form.select_field.choices = []
            plant_form.select_field.render_kw = {"class": "is_hidden"}
            plant_form.input_week.render_kw = {"class": "is_hidden"}
        elif entry_data['accept_weekly_data']:
            plant_form.select_field.choices = []
            plant_form.select_field.render_kw = {"class": "is_hidden"}
        elif entry_data['select_field_enable']:
            plant_form.input_file.render_kw = {"class": "is_hidden"}
            plant_form.input_week.render_kw = {"class": "is_hidden"}
    return render_template('etl_view.html',
                           ad_hoc_form=form,
                           buttons=buttons,
                           files_grids=files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="")
