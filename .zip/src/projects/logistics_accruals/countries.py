import json
import os

from src.projects.etl_config import LogAccrualsConfig


class Countries:

    def __init__(self, cfg: LogAccrualsConfig):
        self.cfg: LogAccrualsConfig = cfg
        file_path = os.path.normpath(os.path.join(self.cfg.get_proj_root_fld, "json", "plant.json"))

        with open(file_path, 'r') as f:
            data = f.read()

        self.json_raw = json.loads(data)
        self.get_countries: list = list()
        for row in self.json_raw['countries']:
            self.get_countries.append((row['countryCode'], row['countryName'], row['plantCode']))
