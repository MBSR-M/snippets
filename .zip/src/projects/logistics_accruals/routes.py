# -*- coding: utf-8 -*-

import logging

from flask import render_template, session, Blueprint
from flask_login import login_required, current_user

from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import LogAccrualsConfig, log_accruals
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cfg = LogAccrualsConfig()
log_accruals_bp = Blueprint('log_accruals', __name__, static_folder='static', template_folder='templates')


@log_accruals_bp.route('/', methods=['GET', 'POST'])
@log_accruals_bp.route('/main', methods=['GET', 'POST'])
@project_access(log_accruals_bp.name)
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(log_accruals)
        session['breadcrumb'] = None
    else:
        projects = []
    return render_template("index.html", projects=projects,
                           title='Logistical Accruals EUR', description="")
