#!/usr/bin/env python3
# -*- coding: utf-8 -*-


DROPDOWN_COUNTRIES = [
    {"country": "spain", "plants": ["A250", "C506"]}
]
WEEKLY_UPDATE_COUNTRIES = [
    {"country": "benelux", "plants": ["C600", "E001", "E062", "E063"]},
    {"country": "uk", "plants": ["A150", "A153"]}
]

