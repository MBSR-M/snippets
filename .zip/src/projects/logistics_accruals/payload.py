#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from dataclasses import dataclass
from datetime import datetime
import json
import logging
import os

from flask_login import current_user
from werkzeug.utils import secure_filename

from src.projects.logistics_accruals.constants import DROPDOWN_COUNTRIES, WEEKLY_UPDATE_COUNTRIES
from src.projects.etl_config import LogAccrualsConfig

log = logging.getLogger(__name__)


@dataclass
class Plant:
    country_code: str = ''
    code: str = ''
    input_file: str = ''
    input_received_date: str = ''
    select_field: str = ''
    input_week: str = ''
    input_file_week_1: str = ''
    input_file_week_2: str = ''
    input_file_week_3: str = ''
    input_file_week_4: str = ''
    input_file_week_5: str = ''

    def __hash__(self):
        return hash((self.code, self.input_file, self.input_received_date, self.select_field, self.input_week))

    def __eq__(self, other):
        if isinstance(other, Plant):
            return (self.code, self.input_file, self.input_received_date, self.select_field, self.input_week) == (
                other.code, other.input_file, other.input_received_date, self.select_field, self.input_week)
        return False

    def to_dict(self):
        dropdown_plants = {plant for x in DROPDOWN_COUNTRIES for plant in x['plants']}
        weekly_update_plants = {plant for x in WEEKLY_UPDATE_COUNTRIES for plant in x['plants']}
        base_dict = {
            'code': self.code,
            'input_file': self.input_file,
            'input_received_date': self.input_received_date,
            'select_field': None,
            'input_week': None,
        }
        if self.code in dropdown_plants:
            base_dict['select_field'] = self.select_field
        elif self.code in weekly_update_plants:
            base_dict['input_file_week_1'] = self.input_file_week_1
            base_dict['input_file_week_2'] = self.input_file_week_2
            base_dict['input_file_week_3'] = self.input_file_week_3
            base_dict['input_file_week_4'] = self.input_file_week_4
            base_dict['input_file_week_5'] = self.input_file_week_5
        return base_dict


class Payload:
    def __init__(self, cfg: LogAccrualsConfig, forms_data, trigger_button):

        self.cfg = cfg
        self.form = forms_data
        self.trigger_timestamp: str = datetime.now().strftime('%Y%m%d%H%M%S')
        self.prod_root_folder: str = self.cfg.get_proj_root_fld
        self.trigger_button = trigger_button
        self.forex_rate_file: str = ''
        self.mef_file: str = ''
        self.select_field: str = ''
        self.input_week: str = ''
        self.input_file_week_1: str = ''
        self.input_file_week_2: str = ''
        self.input_file_week_3: str = ''
        self.input_file_week_4: str = ''
        self.input_file_week_5: str = ''
        self.country_code: str = ''
        self.plants: dict[str, Plant] = dict()
        self.files_prefix = current_user.name + "_" + self.trigger_timestamp + "__"
        self.request_signal_file = self.files_prefix + secure_filename('request_submitted.json')
        self.request_signal_name = os.path.join(self.cfg.get_inputs_folder_path, self.request_signal_file)
        self.jenkins_url = ''

    def __hash__(self):
        return hash((
            self.trigger_timestamp, self.prod_root_folder, self.trigger_button, self.forex_rate_file, self.mef_file,
            self.country_code, frozenset(self.plants.items()), self.request_signal_name))

    def __eq__(self, other):
        if isinstance(other, Payload):
            return (
                self.trigger_timestamp, self.prod_root_folder, self.trigger_button, self.forex_rate_file, self.mef_file,
                self.country_code, frozenset(self.plants.items()), self.request_signal_name) == (
                other.trigger_timestamp, other.prod_root_folder, other.trigger_button, other.forex_rate_file,
                other.mef_file, other.country_code, frozenset(other.plants.items()), other.request_signal_name)
        return False

    def to_dict(self):
        return {
            'trigger_timestamp': self.trigger_timestamp,
            'request_signal_name': self.request_signal_name,
            'prod_root_folder': self.prod_root_folder,
            'trigger_button': self.trigger_button,
            'forex_rate_file': self.forex_rate_file,
            'mef_file': self.mef_file,
            'country_code': self.country_code,
            'plants': {k: v.to_dict() for k, v in self.plants.items()},
        }

    def process_form_data(self):
        if self.form.forex_rate_file.data:
            self.forex_rate_file = self.save_file('', '', self.form.forex_rate_file.data, 'forex_rates.xlsx')
        else:
            self.forex_rate_file = "forex_rates.xlsx"
        self.mef_file = self.save_file(self.files_prefix, '_mef_file_', self.form.mef_file.data) # COMMENTED WHILE TESTING
        weekly_update_plants = {plant for x in WEEKLY_UPDATE_COUNTRIES for plant in x['plants']}
        for plant_form in self.form.plants_form.data:
            plant: Plant = Plant()
            plant.code = plant_form['plant_name']
            plant.country_code = plant_form['country_code']
            plant.input_file = self.save_file(self.files_prefix, f'_{plant.country_code}_{plant.code}_',
                                              plant_form['input_file']) # COMMENTED WHILE TESTING
            self.country_code = plant.country_code
            self.plants[plant.code] = plant
            plant.select_field = plant_form['select_field']
            if not plant.code in weekly_update_plants:
                plant.input_week = plant_form['input_week']
            else:
                plant.input_file_week_1 = plant_form['input_file_week_1']
                plant.input_file_week_2 = plant_form['input_file_week_2']
                plant.input_file_week_3 = plant_form['input_file_week_3']
                plant.input_file_week_4 = plant_form['input_file_week_4']
                plant.input_file_week_5 = plant_form['input_file_week_5']
            plant.input_received_date = plant_form["input_received_date"].strftime('%m/%d/%Y')

    def save_file(self, files_prefix, type_prefix, form, file_name=None):
        try:
            file_data = form
            if not file_name:
                file_name = files_prefix + type_prefix + file_data.filename
            file_data_filename = secure_filename(file_name)
            file_data.save(os.path.join(self.cfg.get_inputs_folder_path, file_data_filename))
            return file_data_filename
        except Exception as e:
            log.error(e)

    def save_request_json(self):
        print(json.dumps(self.to_dict(), indent=4))
        if os.path.exists(self.request_signal_name):
            os.remove(self.request_signal_name)

        with open(self.request_signal_name, 'w') as f:
            json.dump(self.to_dict(), f) # COMMENTED WHILE TESTING
