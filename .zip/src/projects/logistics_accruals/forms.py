#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from datetime import datetime

from flask_wtf import FlaskForm
from wtforms import SubmitField, DateField, FileField
from wtforms.fields import SelectField, BooleanField, StringField
from wtforms.fields.form import FormField
from wtforms.fields.list import FieldList
from wtforms.validators import DataRequired, InputRequired, Optional

from src.projects.etl_config import LogAccrualsConfig
from src.projects.logistics_accruals.constants import DROPDOWN_COUNTRIES, WEEKLY_UPDATE_COUNTRIES
from src.projects.logistics_accruals.countries import Countries

registered_countries = Countries(LogAccrualsConfig()).get_countries


class PlantForm(FlaskForm):
    today = datetime.now()
    plant_name = StringField('plant_name', render_kw={"disabled": "disabled"})
    country_code = StringField('country_code', render_kw={"class": "is_hidden"})
    input_received_date = DateField("input_received_date", validators=[InputRequired()],
                                    default=today.date())
    current_week = today.isocalendar()[1]
    weeks = [(str(w), f"Week {w}") for w in range(1, 53)]
    input_week = SelectField(
        label="Select week(s)",
        choices=weeks,
        default=[f"Week-{str(current_week)}"],
        render_kw={"class": "form-control"},
        validators=[InputRequired()]
    )
    input_file = FileField("input_file", validators=[Optional()] )
    select_field = SelectField(
        label="Select Time Series",
        choices=[(2, "2"), (3, "3")],
        default="-1",
        render_kw={"class": "form-control"}
    )
    #select_field_second = SelectField(
        # label='select second time series',
    #     choices=[],
    #     render_kw={"class": "form-control"}
    # )

    #dynamic dropdown
    additional_select_field = []

    is_active = BooleanField('Process plant',render_kw={"class": "is_hidden"})
    select_field_enable = BooleanField(render_kw={"class": "is_hidden"})
    accept_weekly_data = BooleanField(render_kw={"class": "is_hidden"})





class CountryForm(FlaskForm):
    forex_rate_file = FileField(label="Default file is most recent provided forex_rates.xlsx")
    mef_file = FileField("MEF File", validators=[InputRequired()])
    countries_choices = [("0", "Select country")]
    for country_code, country_name, plants in registered_countries:
        countries_choices.append((country_code, country_name))
    country = SelectField(
        label="Select Country",
        choices=countries_choices,
        validators=[DataRequired()],
        id='country'
    )
    # Generate entries data
    entries_data = []
    for country_code, country_name, _plants in registered_countries:
        for plnt in _plants:
            for cntry in DROPDOWN_COUNTRIES:
                if country_name.lower() not in [x['country'] for x in WEEKLY_UPDATE_COUNTRIES]:
                    if country_name.lower() == cntry['country'] and plnt in cntry['plants']:
                        entries_data.append({
                            'plant_name': plnt,
                            'country_code': country_code,
                            'is_active': True,
                            'select_field_enable': True,
                            'accept_weekly_data': False,
                        })
                    else:
                        entries_data.append({
                            'plant_name': plnt,
                            'country_code': country_code,
                            'is_active': True,
                            'select_field_enable': False,
                            'accept_weekly_data': False,
                        })
            for cc in WEEKLY_UPDATE_COUNTRIES:
                if country_name.lower() == cc['country'] and plnt in cc['plants']:
                    entries_data.append({
                        'plant_name': plnt,
                        'country_code': country_code,
                        'is_active': True,
                        'select_field_enable': False,
                        'accept_weekly_data': True,
                    })

    plants_form = FieldList(FormField(PlantForm), label="Select Plants")
    submit_mef = SubmitField("Generate MEF File")
    submit_output = SubmitField("Generate Output File")