import logging

from flask import Blueprint, render_template, session
from flask_login import current_user, login_required

from src.projects.etl_config import rubiks_vs_su
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

rubiks_vs_su_bp = Blueprint('rubiks_vs_su', __name__, static_folder='static', template_folder='templates')


@rubiks_vs_su_bp.route('/')
@rubiks_vs_su_bp.route('/main')
@project_access(rubiks_vs_su_bp.name)
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(rubiks_vs_su)
        session['breadcrumb'] = None
    else:
        log.info('guest')
        projects = []

    return render_template("index.html", projects=projects,
                           title="Rubiks Vs SU",
                           description="Rubiks Vs SU")
