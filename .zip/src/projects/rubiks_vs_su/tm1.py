import logging

from flask import render_template, url_for, session
from flask_login import login_required, current_user

from src.main.forms import RedirectUrlTrigger, InputFilesForm
from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import RubicsVsSUConfig
from src.projects.files_grid import FilesGrid
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cfg = RubicsVsSUConfig()
tm1_bp = BlueprintETL(cfg, cfg.BLUEPRINT_NAME, cfg.PROJ_CODE_NAME).blueprint


@tm1_bp.route('/etl')
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    """
    what will be on sub_page
    no reporing printed so only input and trigger of input and recalculate sproc
    :return:
    """
    session['breadcrumb'] = [('main', 'Back')]
    log.info(f'{current_user.email}')
    # generic user input
    files_grids = []

    inputs_table = FilesGrid(cfg, cfg.INPUTS_FOLDER, cfg.INPUTS_FOLDER_EXTENSION)
    inputs_table.caption = 'Inputs'
    inputs_table.display_file_added_by()
    inputs_table.download = True
    inputs_table.delete = True
    files_grids.append(inputs_table)

    qo_q_sample_folder = FilesGrid(cfg, cfg.Q_O_Q_SAMPLE_FOLDER, cfg.INPUTS_FOLDER_EXTENSION)
    qo_q_sample_folder.caption = 'QoQ-sample'
    qo_q_sample_folder.display_file_added_by()
    qo_q_sample_folder.download = True
    qo_q_sample_folder.delete = True
    files_grids.append(qo_q_sample_folder)

    rubik_vs_su_tool_folder = FilesGrid(cfg, cfg.RUBIK_VS_SU_TOOL_FOLDER, cfg.INPUTS_FOLDER_EXTENSION)
    rubik_vs_su_tool_folder.caption = 'Rubik Vs SU - Tool'
    rubik_vs_su_tool_folder.display_file_added_by()
    rubik_vs_su_tool_folder.download = True
    rubik_vs_su_tool_folder.delete = True
    files_grids.append(rubik_vs_su_tool_folder)

    import_folder = FilesGrid(cfg, cfg.IMPORT_FOLDER, cfg.INPUTS_FOLDER_EXTENSION)
    import_folder.caption = 'Import'
    import_folder.display_file_added_by()
    import_folder.download = True
    import_folder.delete = True
    files_grids.append(import_folder)

    # run upit is default
    run_upit: RedirectUrlTrigger = RedirectUrlTrigger()
    run_upit.url = url_for('.run_upit')
    run_upit.name = "Run UPIT"
    run_upit.target = "_blank"

    file_upload_form = InputFilesForm()
    file_upload_form.url(url_for('.etl_upload'))

    return render_template('etl_view.html',
                           run_upit_link=run_upit,
                           file_upload_form=file_upload_form,
                           files_grids=files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="")
