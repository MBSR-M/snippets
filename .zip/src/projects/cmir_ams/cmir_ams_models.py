#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from sqlalchemy import Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class UOMConversion(Base):
    __tablename__ = 'UOM_Conversion'
    __table_args__ = {"schema":"CMIR_AMS"}

    Key = Column(String(50), primary_key=True)
    BUM = Column(String(50), nullable=False)
    Contract = Column(String(50), nullable=False)
    Multiplier = Column(Float, nullable=False)

    def __repr__(self):
        return f'<UOMConversion(Key={self.Key}, BUM={self.bum}, Contract={self.Contract}, Multiplier={self.Multiplier})>'


class CurrencyConversion(Base):
    __tablename__ = 'Currency_Conversion'
    __table_args__ = {"schema":"CMIR_AMS"}

    Key = Column(String(50), primary_key=True)
    Country = Column(String(50), nullable=False)
    Contract = Column(String(50), nullable=False)
    Z2mat = Column(String(50), nullable=False)
    ExchangeRateType = Column(String(50), nullable=False)
    ValidFrom = Column(String(50), nullable=False)
    ExchRate = Column(Float, nullable=True)
    Comments = Column(String(1), nullable=True)

    def __repr__(self):
        return f'<CurrencyConversion(Key={self.Key}, Country={self.Country}, Contract={self.Contract}, Z2mat={self.Z2mat}, ExchangeRateType={self.ExchangeRateType}, ValidForm={self.ValidForm}, ExchRate={self.ExchRate}, Comments={self.Comments})>'


class CMIR_AMS_POC(Base):
    __tablename__ = 'Point_of_Contact'
    __table_args__ = {"schema":"CMIR_AMS"}
    Region = Column(String(50), primary_key=True)
    Country = Column(String(50), primary_key=True)
    Responsiblefor = Column(String(50), nullable=False)
    Email = Column(String(50), nullable=False)
    Plant = Column(String(50), nullable=True)

    def __repr__(self):
        return f'<CMIR_AMS_POC(Region={self.Region}, Country={self.Country}, Responsiblefor={self.Responsiblefor}, Email={self.Email}, Plant={self.Plant})>'
