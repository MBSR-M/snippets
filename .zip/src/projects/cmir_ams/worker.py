#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging

from contextlib import contextmanager
from sqlalchemy.orm import sessionmaker
import pandas as pd
from src import db
from src.projects.cmir_ams.cmir_ams_models import CurrencyConversion, UOMConversion, CMIR_AMS_POC
import warnings
from sqlalchemy import exc as sa_exc
# Suppress specific SQLAlchemy warnings
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

logger = logging.getLogger(__name__)


@contextmanager
def get_session():
    session = sessionmaker(bind=db.engine)()
    try:
        yield session
        session.commit()
    except Exception as e:
        logger.info(f"An error occurred while logging: {str(e)}")
        session.rollback()
        raise
    finally:
        session.close()


def truncate_table(model):
    with get_session() as session:
        try:
            logger.info(f"Attempting truncating table : {model.__name__}")
            table_name = model.__tablename__
            schema = model.__table_args__['schema']
            truncate_sql = f"TRUNCATE TABLE {schema}.{table_name}"
            session.execute(truncate_sql)
            session.commit()
        except Exception as e:
            logger.error(f"Error truncating table: {str(e)}")
            # session.rollback()
            raise

def insert_uom_conversion_data(dataframe):
    with get_session() as session:
        try:
            logger.info("Inserting UOM conversion data starting")
            uom_conversions = []
            for _, row in dataframe.iterrows():
                uom_conversion = UOMConversion(
                    Key=row['Key'],
                    BUM=row['BUM'],
                    Contract=row['Contract'],
                    Multiplier=row['Multiplier']
                )
                uom_conversions.append(uom_conversion)
            session.add_all(uom_conversions)
            session.commit()
            logger.info("UOM conversion data inserted successfully")
        except Exception as e:
            logger.error(f"Error inserting UOM conversion data: {str(e)}")
            # session.rollback()
            raise

def insert_currency_conversion_data(dataframe):
    with get_session() as session:
        try:
            dataframe['ExchRate'] = dataframe['ExchRate'].fillna(0.0)
            dataframe['Comments'] = dataframe['Comments'].fillna("-")
            logger.info("Inserting currency conversion data starting")
            currency_conversions = []
            for _, row in dataframe.iterrows():
                currency_conversion = CurrencyConversion(
                    Key=row['Key'],
                    Country=row['Country'],
                    Contract=row['Contract'],
                    Z2mat=row['Z2mat'],
                    ExchangeRateType=row['ExchangeRateType'],
                    ValidFrom=row['ValidFrom'],
                    ExchRate=float(row.get('ExchRate', 0.0)),
                    Comments=row['Comments']
                )
                currency_conversions.append(currency_conversion)
            session.add_all(currency_conversions)
            session.commit()
            logger.info("Currency conversion data inserted successfully")
        except Exception as e:
            logger.error(f"Error inserting Currency conversion data: {str(e)}")
            # session.rollback()
            raise

def insert_cmir_ams_poc_data(dataframe):
    with get_session() as session:
        try:
            dataframe = dataframe.where(pd.notnull(dataframe), None)
            dataframe['Plant'] = dataframe['Plant'].fillna('-')
            logger.info("Inserting CMIR_AMS_POC data starting")
            cmir_ams_pos = []
            for _, row in dataframe.iterrows():
                cmir_ams_po = CMIR_AMS_POC(
                    Region=row['Region'],
                    Country=row['Country'],
                    Responsiblefor=row['Responsiblefor'],
                    Email=row.get('Email', None),
                    Plant=row['Plant']
                )
                cmir_ams_pos.append(cmir_ams_po)
            session.add_all(cmir_ams_pos)
            session.commit()
            logger.info("CMIR_AMS_POC data inserted successfully")
        except Exception as e:
            logger.error(f"Error inserting CMIR_AMS_POC data: {str(e)}")
            # session.rollback()
            raise
