# -*- coding: utf-8 -*-
"""
This is module wrapping view and blueprint as blueprint.
Generic solution for user inputs/ report outputs
Behavior is controlled by config
"""
from datetime import datetime
from functools import wraps
from io import BytesIO
import logging
import os
from os import listdir, remove, stat
import zipfile

import pandas as pd
from flask import Blueprint, flash, redirect, send_file, send_from_directory, session, url_for, request
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from src.projects.cmir_ams.cmir_ams_models import UOMConversion, CurrencyConversion, CMIR_AMS_POC
from src.projects.cmir_ams.worker import truncate_table, insert_uom_conversion_data, insert_currency_conversion_data, \
    insert_cmir_ams_poc_data
from src.main.forms import InputFilesForm, Input_CMIR_AMS_Files_Form, DownloadBPQFilesForm
from src.projects.etl_config import ETLConfig
from src.projects.files_grid import FilesGrid
from src.utils.helpers import build_jenkins_job, convert_bytes, create_myio
import warnings
from sqlalchemy import exc as sa_exc
# Suppress specific SQLAlchemy warnings
warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

log = logging.getLogger(__name__)


def project_access(method):
    """
    Decorator for checking if user can access project
    with view /blueprint each call to function needs to be checked individually
    :param method:
    :return:
    """

    @wraps(method)
    def _impl(self, *args, **kwargs):
        if self.project_code_name in session["projects_access_granted"]:
            return method(self, *args, **kwargs)
        else:
            return redirect(url_for('main.home'))

    return _impl


class BlueprintETL:
    """
    Class is view but wrapped around blueprint
    Adding rules to blueprint is way of implementing view
    Functions are what view is, generic function called by blueprint with rule = url
    Functions in most cases are wrapping around config or providing IO operations
    """

    def __init__(self, cfg, static_folder='static',
                 template_folder='templates'):
        self.cfg: ETLConfig = cfg
        self.blueprint = Blueprint(self.cfg.BLUEPRINT_NAME, __name__, static_folder, template_folder)
        self.project_code_name = self.cfg.PROJ_CODE_NAME

        self.blueprint.add_url_rule('/view_sap_import', view_func=self.view_sap_import, methods=['GET'])
        self.blueprint.add_url_rule('/trigger_sap_import', view_func=self.trigger_sap_import, methods=['GET'])
        self.blueprint.add_url_rule('/run_upit', view_func=self.run_upit, methods=['GET'])
        self.blueprint.add_url_rule('/t2l', view_func=self.trigger_t2l, methods=['GET'])
        self.blueprint.add_url_rule('/ods', view_func=self.trigger_ods, methods=['GET'])
        fld_file = '<path:folder_name>/<string:file_name>'
        self.blueprint.add_url_rule(f'/view/{fld_file}', view_func=self.view, methods=['GET', 'POST'])
        self.blueprint.add_url_rule('/etl_upload', view_func=self.etl_upload, methods=['POST'])
        self.blueprint.add_url_rule('/etl_upload_to_database', view_func=self.etl_upload_to_database, methods=['POST'])
        # self.blueprint.add_url_rule('/etl_download_from_database', view_func=self.etl_download_from_database, methods=['GET', 'POST'])
        self.blueprint.add_url_rule(f'/download/{fld_file}', view_func=self.download, methods=['GET', 'POST'])
        self.blueprint.add_url_rule(f'/zip_download/{fld_file}', view_func=self.zip_download, methods=['GET', 'POST'])
        self.blueprint.add_url_rule(f'/delete/{fld_file}', view_func=self.delete, methods=['GET', 'POST'])
        self.blueprint.add_url_rule('/delete_all/<path:folder_name>/<string:file_endswith>',
                                    view_func=self.delete_all, methods=['GET', 'POST'], )
        self.blueprint.add_url_rule(f'/edit/{fld_file}', view_func=self.edit, methods=['GET', 'POST'])

    @login_required
    @project_access
    def view_sap_import(self):
        """
        redirect to jenkins VIEW tab for sap imports (e.g. automated jobs with upit)
        :return: redirect
        """

        return redirect(self.cfg.get_sap_import_view_url)

    @login_required
    @project_access
    def trigger_sap_import(self):
        """
        Two operations
        1) posting request to jenkins api - to trigger job,
            token is in config,
            current user is for logging who triggered job. It is in first line of jenkins log.
        2) redirect to jenkins view page with 'this' job. Redirect opens new tab.
        :return: post, redirect
        """

        url = self.cfg.get_sap_import_trigger_url.format(current_user.email)
        log.info(url)
        build_jenkins_job(url)
        return redirect(self.cfg.get_sap_import_view_url)

    @login_required
    @project_access
    def run_upit(self):
        """
            Two operations
            1) user trigger user-privided inputs
            2) redirect to jenkins upload log
        :return:
        """

        url = self.cfg.get_import_trigger_url.format(current_user.email)
        log.info(url)
        build_jenkins_job(url)
        return redirect(self.cfg.get_import_view_url)

    @login_required
    @project_access
    def trigger_t2l(self):
        """
        trigger , if implemented in config job for t2l sproc
        redirect to view
        :return:
        """

        url = self.cfg.get_t2l_trigger_url.format(current_user.email)
        log.info(url)
        build_jenkins_job(url)
        return redirect(self.cfg.get_t2l_view_url)

    @login_required
    @project_access
    def trigger_ods(self):
        """
        trigger, if implemented in config, job for calculating ODS
        redirect to view
        :return:
        """

        url = self.cfg.get_ods_trigger_url.format(current_user.email)
        log.info(url)
        build_jenkins_job(url)
        return redirect(self.cfg.get_ods_view_url)

    @login_required
    @project_access
    def view(self, folder_name, file_name):
        """
        not implemented , intended for downloading
        :param folder_name:
        :param file_name:
        :return:
        """
        log.info(f'{current_user.email}-{folder_name}/{file_name}')
        io_object = create_myio(self.cfg.get_file_path(folder_name, file_name))
        return send_file(io_object, attachment_filename=file_name,
                         as_attachment=True)

    @login_required
    @project_access
    def edit(self, folder_name, file_name):
        """
        not implemented, intended for editing row/file
        :param folder_name:
        :param file_name:
        :return:
        """
        log.info(f'{current_user.email}-{folder_name}/{file_name}')
        io_object = create_myio(self.cfg.get_file_path(folder_name, file_name))
        return send_file(io_object, attachment_filename=file_name,
                         as_attachment=True)

    @login_required
    @project_access
    def etl_upload(self):
        import time
        file_upload_form = InputFilesForm()
        file_upload_form.url = url_for('.etl_upload')

        if file_upload_form.validate_on_submit() and file_upload_form.input_file.data:
            for file in file_upload_form.input_file.data:
                log.info(f'{current_user.email}-{file.filename}')
                secure_file_name = secure_filename(file.filename)
                timer_start = time.perf_counter()
                secure_file_path = os.path.join(self.cfg.get_inputs_folder_path, secure_file_name)
                file.save(secure_file_path, buffer_size=10485760)
                timer_stop = time.perf_counter()
                timer_save_time = timer_stop - timer_start
                csv_input_table = FilesGrid(self.cfg, self.cfg.INPUTS_FOLDER, self.cfg.INPUTS_FOLDER_EXTENSION)
                file_size = stat(secure_file_path).st_size
                log.info(
                    f'{file.filename.split(".")[0]}:size{convert_bytes(file_size)}:time{timer_save_time:0.4f}:speed{file_size / timer_save_time / 1024 / 1024:0.2f}MB/s')
                csv_input_table.logger.update_file_log(secure_file_name)
            flash(f'File(s) successfully uploaded.', 'success')
            return '{"files": []}'
        return '{"files": []}'

    @login_required
    @project_access
    def etl_upload_to_database(self):
        import time
        file_upload_form = Input_CMIR_AMS_Files_Form()
        file_upload_form.url = url_for('.etl_upload_to_database')
        file_type = file_upload_form.select_field.data
        if file_upload_form.validate_on_submit() and file_upload_form.input_file.data:
            for file in file_upload_form.input_file.data:
                log.info(f'{current_user.email}-{file.filename}')
                secure_file_name = secure_filename(file.filename)
                timer_start = time.perf_counter()
                secure_file_path = os.path.join(self.cfg.get_inputs_folder_path, secure_file_name)
                file.save(secure_file_path, buffer_size=10485760)
                timer_stop = time.perf_counter()
                timer_save_time = timer_stop - timer_start
                csv_input_table = FilesGrid(self.cfg, self.cfg.INPUTS_FOLDER, self.cfg.INPUTS_FOLDER_EXTENSION)
                file_size = stat(secure_file_path).st_size
                log.info(
                    f'{file.filename.split(".")[0]}:size{convert_bytes(file_size)}:time{timer_save_time:0.4f}:speed{file_size / timer_save_time / 1024 / 1024:0.2f}MB/s')
                csv_input_table.logger.update_file_log(secure_file_name)
                dataframe = pd.read_csv(secure_file_path) if file.filename.endswith(".csv") else pd.read_excel(
                    secure_file_path)
                if file_type == "UOM Conversion":
                    truncate_table(UOMConversion)
                    insert_uom_conversion_data(dataframe)
                    flash("Inserting UOM conversion data completed")
                elif file_type == "Currency Conversion":
                    truncate_table(CurrencyConversion)
                    insert_currency_conversion_data(dataframe)
                    flash("Inserting Currency conversion data completed")
                elif file_type == "CMIR AMS POC":
                    truncate_table(CMIR_AMS_POC)
                    insert_cmir_ams_poc_data(dataframe)
                    flash("Inserting CMIR AMS POC data completed")
            flash(f'File(s) successfully uploaded.', 'success')
            return '{"files": []}'
        return '{"files": []}'

    # @login_required
    # @project_access
    # def etl_download_from_database(self):
    #     file_download_form = DownloadBPQFilesForm()
    #     file_download_form.url = url_for('.etl_download_from_database')
    #     print("Request form submit_download data:", file_download_form.submit_download.data)
    #     print("Request form select_field data:", file_download_form.select_field.data)
    #     file_type = file_download_form.select_field.data
    #     log.info(f'{current_user.email}-{file_type} to download')
    #     if file_type == "Resource Volume Report":
    #         pass
    #     elif file_type == "CET Data Pivot Report":
    #         pass
    #     elif file_type == "Resource Description Report":
    #         pass
    #     flash(f'File(s) successfully downloaded.', 'success')
    #     return '{"files": []}'



    @login_required
    @project_access
    def download(self, folder_name, file_name):
        log.info(f'{current_user.email}-{folder_name}/{file_name}')
        path = self.cfg.get_file_path(folder_name, "")
        return send_from_directory(path, file_name, as_attachment=True)

    @login_required
    @project_access
    def zip_download(self, folder_name, file_name):
        log.info(f'{current_user.email}-{folder_name}/{file_name}')
        zipio = BytesIO()
        path = self.cfg.get_file_path(folder_name, file_name)
        with zipfile.ZipFile(zipio, mode="w",
                             compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(path, os.path.basename(path))
        zipio.seek(0)

        dt = datetime.now().strftime("%Y%m%d%H%M%S")
        file_name_zip = f'{dt}_{self.cfg.PROJECT_TITLE}.zip'

        return send_file(zipio, download_name=file_name_zip, as_attachment=True)

    @login_required
    @project_access
    def delete(self, folder_name, file_name):
        # @todo consider to move file instead of deleteing
        """
        Del and redirect
        :param folder_name:
        :param file_name:
        :return: refresh
        """
        log.info(f'{current_user.email}-{folder_name}/{file_name}')
        try:
            remove(self.cfg.get_file_path(folder_name, file_name))
            flash(f'File {file_name} has been deleted!', 'warning')
        except:
            return redirect(url_for('.etl'))

        return redirect(url_for('.etl'))

    @login_required
    @project_access
    def delete_all(self, folder_name, file_endswith):
        """
        implementation of delete all file in folder / in files_grid
        :param folder_name: project folder holding files for del
        :param file_endswith: only files that user see /decide to del.
        It is possible the other files will be in folder then extension should be excluded from view/option for del all
        :return:
        """

        try:
            files_names_list = ''
            fld_path = self.cfg.get_file_path(folder_name, '')

            for fname in listdir(fld_path):
                # loop files in folder, split ext
                file_ext = fname.split('.')[-1]
                if file_ext in file_endswith:
                    log.info(f'{current_user.email}-{folder_name}/{fname}')
                    # concatenate files names for messaging
                    files_names_list += fname + ', '
                    # delete file
                    file_path_to_del = self.cfg.get_file_path(folder_name,
                                                              fname)
                    os.remove(file_path_to_del)
            flash(f'File(s) {files_names_list[:-2]} has been deleted!',
                  'warning')
            return redirect(url_for('.etl'))
        except:
            return redirect(url_for('.etl'))
