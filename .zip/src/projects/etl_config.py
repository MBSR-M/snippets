from os import path

from config import Config as cfg
from src.projects.gpl_manage.models import GPLEUR, GPLAMS

JENKINS_PRE_URL = cfg.JENKINS_PRE_URL
PROJECTS_FOLDER = r'//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/SCFS1/3Informatn/15. PROJECT'

hosted_projects = [
    {'code_name': 'gpl_eur', 'url': 'gpl_eur/main', 'name': 'GPL Europe'},
    {'code_name': 'gpl_ams', 'url': 'gpl_ams/main', 'name': 'GPL Americas'},
    {'code_name': 'log_accruals', 'url': 'log_accruals/main', 'name': 'Logistics Accruals EUR'},
    {'code_name': 'local_tax', 'url': 'local_tax/main', 'name': 'Local Tax Katowice'},
    {'code_name': 'tp_update', 'url': 'tp_update/main', 'name': 'TP Update'},
    {'code_name': 'bpq_robot_rpm', 'url': 'bpq_robot_rpm/main', 'name': 'Source'},
    {'code_name': 'make_analytics', 'url': 'make_analytics/main', 'name': 'Make Analytics'},
    {'code_name': 'cmir', 'url': 'cmir/main', 'name': 'CMIR'},
    {'code_name': 'cmir_ams', 'url': 'cmirams/main', 'name': 'CMIR AMS'},
    {'code_name': 'pmc_eur', 'url': 'pmc_eur/main', 'name': 'PMC EUR'},
    {'code_name': 'rubiks_vs_su', 'url': 'rubiks_vs_su/main', 'name': 'Rubiks Vs SU'},
    {'code_name': 'innovation_costing', 'url': 'innovation_costing/main', 'name': 'Innovation Costing'},
    {'code_name': 'fet', 'url': 'fet/main', 'name': 'FET'},
    {'code_name': 'twc', 'url': 'twc/main', 'name': 'TWC'},
    {'code_name': 'driverless_na_fcst', 'url': 'driverless_na_fcst/main', 'name': 'DRIVERLESS NA FCST'},
    {'code_name': 'driverless_na_bu_split', 'url': 'driverless_na_bu_split/main', 'name': 'DRIVERLESS NA BU SPLIT'},
    {'code_name': 'primary_tracker', 'url': 'primary_tracker/main', 'name': 'PRIMARY TRACKER'},
    {'code_name': 'twc_ams', 'url': 'twc_ams/main', 'name': 'TWC AMS'},
    {'code_name': 'depreciationfc', 'url': 'depreciationfc/main', 'name': 'DepreciationFC'}
]

gpl_eur = {
    'code_name': 'gpl_eur',
    'url': 'gpl_eur/main',
    'name': 'GPL Europe',
    'sub_pages': {
        'gpl_eur': {'blueprint_name': 'gpl_eur', 'url': 'etl', 'name': 'Get Excel'},
        'gpl_manage': {'blueprint_name': 'gpl_eur', 'url': 'gpl_add', 'name': 'Manage plants'},
        'gpl': {'blueprint_name': 'gpl_eur', 'url': 'gpl_all', 'name': 'Overview'},
    }}

gpl_ams = {
    'code_name': 'gpl_ams',
    'url': 'gpl_ams/main',
    'name': 'GPL Americas',
    'sub_pages': {
        'gpl_ams': {'blueprint_name': 'gpl_ams', 'url': 'etl', 'name': 'Get Excel'},
        'gpl_manage': {'blueprint_name': 'gpl_ams', 'url': 'gpl_add', 'name': 'Manage plants'},
        'gpl': {'blueprint_name': 'gpl_ams', 'url': 'gpl_all', 'name': 'Overview'},
    }}

log_accruals = {
    'code_name': 'log_accruals',
    'url': 'log_accruals/main',
    'name': 'Logistics Accruals EUR',
    'sub_pages': {
        'log_accruals_generate': {'blueprint_name': 'log_accruals_generate', 'url': 'log_accruals_generate/etl',
                                  'name': 'Generate reports'},
    }}

tp_update = {
    'code_name': 'tp_update',
    'url': 'tp_update/main',
    'name': 'TP Update',
    'sub_pages': {
        'cop2': {'blueprint_name': 'cop2', 'url': 'cop2/etl', 'name': 'Kopernik 2'},
    }
}

local_tax = {
    'code_name': 'local_tax',
    'url': 'local_tax/main',
    'name': 'Local Tax Katowice',
    'sub_pages': {
        'be_bev': {'blueprint_name': 'be_bev', 'url': 'be_bev/etl', 'name': 'BE Beverages'},
    }
}

bpq_robot_rpm = {'code_name': 'bpq_robot_rpm',
                 'url': 'bpq_robot_rpm/main',
                 'name': 'Source',
                 'sub_pages': {
                     'bpq_rpm': {'blueprint_name': 'bpq_rpm', 'url': 'bpq_rpm/etl', 'name': 'BPQ Robot RPM'},
                     'bpq_download': {'blueprint_name': 'bpq_download', 'url': 'bpq_download/etl', 'name': 'BPQ Downloads'},
                     'store_procedures': {'blueprint_name': 'store_procedures', 'url': 'store_procedures/etl', 'name': 'Materials Tools'},
                     'gaia': {'blueprint_name': 'gaia', 'url': 'gaia/etl', 'name': 'Decision Tree - Gaia'},
                 }}

make_analytics = {
    'code_name': 'make_analytics',
    'url': 'make_analytics/main',
    'name': 'Make Analytics',
    'sub_pages': {
        'make_costing': {'blueprint_name': 'make_costing', 'url': 'make_costing/etl', 'name': 'Make Costing'},
        'costing_simulation': {'blueprint_name': 'costing_simulation', 'url': 'costing_simulation/etl',
                               'name': 'Costing Simulation'},
    }
}

cmir = {
    'code_name': 'cmir',
    'url': 'cmir/main',
    'name': 'CMIR',
    'sub_pages': {
        'cmir_poc': {'blueprint_name': 'cmir_poc', 'url': 'cmir_poc/etl', 'name': 'CMIR Point of Contact'}
    }
}

cmir_ams = {
    'code_name': 'cmir_ams',
    'url': 'cmir_ams/main',
    'name': 'CMIR AMS',
    'sub_pages': {
        'cmir_ams_poc': {'blueprint_name': 'cmir_ams_poc', 'url': 'cmir_ams_poc/etl', 'name': 'CMIR AMS'}
    }
}

pmc_eur = {
    'code_name': 'pmc_eur',
    'url': 'pmc_eur/main',
    'name': 'PMC EUR',
    'sub_pages': {
        'pmc_eur_bpq': {'blueprint_name': 'pmc_eur_bpq', 'url': 'pmc_eur_bpq/etl', 'name': 'PMC EUR BPQ'},
    }
}

rubiks_vs_su = {
    'code_name': 'rubiks_vs_su',
    'url': 'rubiks_vs_su/main',
    'name': 'Rubiks Vs SU',
    'sub_pages': {
        'tm1': {'blueprint_name': 'tm1', 'url': 'tm1/etl', 'name': 'TM1'},
    }
}

innovation_costing = {
    'code_name': 'innovation_costing',
    'url': 'innovation_costing/main',
    'name': 'Innovation Costing',
    'sub_pages': {
        'innovation_costing_proj': {'blueprint_name': 'innovation_costing_proj', 'url': 'innovation_costing_proj/etl',
                                    'name': 'Innovation Costing'},
    }
}

fet = {
    'code_name': 'fet',
    'url': 'fet/main',
    'name': 'FET',
    'sub_pages': {
        'fet_na': {'blueprint_name': 'fet_na', 'url': 'fet_na/etl', 'name': 'FET NA'},
    }}

twc = {
    'code_name': 'twc',
    'url': 'twc/main',
    'name': 'TWC',
    'sub_pages': {
        'twc_proj': {'blueprint_name': 'twc_proj', 'url': 'twc_proj/etl', 'name': 'TWC'}
    }}

driverless_na_fcst = {'code_name': 'driverless_na_fcst',
                      'url': 'driverless_na_fcst/main',
                      'name': 'DRIVERLESS NA FCST',
                      'sub_pages': {
                          'ams_driverless_na_fcst': {'blueprint_name': 'ams_driverless_na_fcst',
                                                     'url': 'ams_driverless_na_fcst/etl',
                                                     'name': 'AMS.DRIVERLESS NA.FCST.'}
                      }
                      }

driverless_na_bu_split = {'code_name': 'driverless_na_bu_split',
                          'url': 'driverless_na_bu_split/main',
                          'name': 'DRIVERLESS NA BU SPLIT',
                          'sub_pages': {
                              'ams_driverless_na_bu_split': {'blueprint_name': 'ams_driverless_na_bu_split',
                                                             'url': 'ams_driverless_na_bu_split/etl',
                                                             'name': 'AMS.DRIVERLESS NA.BU SPLIT.'}
                          }
                          }

primary_tracker = {'code_name': 'primary_tracker',
                   'url': 'primary_tracker/main',
                   'name': 'PRIMARY TRACKER',
                   'sub_pages': {
                       'eur_primary_tracker_billing': {'blueprint_name': 'eur_primary_tracker_billing',
                                                       'url': 'eur_primary_tracker_billing/etl',
                                                       'name': 'EUR.PRIMARY TRACKER.BILLING.'},
                       'eur_primary_tracker_accrual': {'blueprint_name': 'eur_primary_tracker_accrual',
                                                       'url': 'eur_primary_tracker_accrual/etl',
                                                       'name': 'EUR.PRIMARY TRACKER.ACCRUAL.'},
                       'eur_primary_tracker_segmentation': {'blueprint_name': 'eur_primary_tracker_segmentation',
                                                            'url': 'eur_primary_tracker_segmentation/etl',
                                                            'name': 'EUR.PRIMARY TRACKER.SEGMENTATION.'}
                   }
                   }
twc_ams = {'code_name': 'twc_ams',
           'url': 'twc_ams/main',
           'name': 'TWC AMS',
           'sub_pages': {
               'ams_twc_all_marlin_db': {'blueprint_name': 'ams_twc_all_marlin_db',
                                         'url': 'ams_twc_all_marlin_db/etl',
                                         'name': 'AMS.TWC .ALL MARLIN DB.'},
               'ams_twc_marlin_fcst': {'blueprint_name': 'ams_twc_marlin_fcst',
                                       'url': 'ams_twc_marlin_fcst/etl',
                                       'name': 'AMS.TWC.MARLIN FCST.'},
               'ams_twc_victory': {'blueprint_name': 'ams_twc_victory',
                                   'url': 'ams_twc_victory/etl',
                                   'name': 'AMS.TWC.VICTORY.'},
               'ams_twc_captain_a_split': {'blueprint_name': 'ams_twc_captain_a_split',
                                           'url': 'ams_twc_captain_a_split/etl',
                                           'name': 'AMS.TWC.CAPTAIN A SPLIT.'}
           }
           }

depreciationfc = {
    'code_name': 'depreciationfc',
    'url': 'depreciationfc/main',
    'name': 'DepreciationFC',
    'sub_pages': {
        'depreciationfc_proj': {'blueprint_name': 'depreciationfc_proj', 'url': 'depreciationfc_proj/etl',
                                'name': 'DepreciationFC'}
    }}


class ETLConfig:
    def __init__(self):
        self.parent_project = {}
        self.gpl = None
        self.PROJ_CODE_NAME = ''
        self.BLUEPRINT_NAME = ''
        self.ETL_URL = ''
        self.PROJECT_TITLE = ''
        self.SPEND_ANALYTICS = ''
        self.COP_SNAP_SHOT = ''
        self.MASTER_FOLDER = r'\\S2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\SCFS1\3Informatn\15. PROJECT'
        self.DEPARTMENT_ROOT_FOLDER = ''
        self.PROJECT_FOLDER = ''
        self.INPUTS_FOLDER = 'inputs'
        self.INPUTS_FOLDER_EXTENSION = ['txt', 'csv', 'xls', 'xlsx', 'xlsm', 'xlsb']
        self.OUTPUTS_FOLDER = 'outputs'
        self.OUTPUTS_FOLDER_EXTENSION = ['csv', 'xls', 'xlsx', 'xlsm', 'html', 'txt']
        self.LOGS_FOLDER = 'logs'
        self.SAP_FILE_FOLDER = 'sapfile'
        self.SAP_FILE_FOLDER_EXTENSION = ['xlsx', 'xlsm']
        self.SAP_TEXT_FILE_FOLDER = r'sapfile/saptxt'
        self.SAP_TEXT_FILE_FOLDER_EXTENSION = ['csv']

        self.JENKINS_PRE_URL = f'{JENKINS_PRE_URL}:8080'
        self.JENKINS_PROJ = ""

        self.SAP_IMPORT_JOB = ''  # view for sap import job
        self.SAP_IMPORT_TRIGGER = ''  # trigger for sap import job

        self.IMPORT_JOB = ''  # view upit import csv
        self.IMPORT_TRIGGER = ''  # trigger upit import csv
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''

        self.get_proj_root_fld = ''
        self.get_inputs_folder_path = ''
        self.get_outputs_folder_path = ''
        self.get_cop_snap_shot_folder_path = ''
        self.get_spend_analysis_folder_path = ''
        self.get_logs_folder_path = ''
        self.get_sap_import_view_url = ''
        self.get_sap_import_trigger_url = ''
        self.get_import_view_url = ''
        self.get_import_trigger_url = ''
        self.get_e2t_view_url = ''
        self.get_e2t_trigger_url = ''
        self.get_t2l_view_url = ''
        self.get_t2l_trigger_url = ''
        self.get_ods_view_url = ''
        self.get_ods_trigger_url = ''

        self.get_proj_folder_name = ''

    def get_file_path(self, folder_name, file_name):
        """
        param folder_name: code name for implemented folder like 'inputs', 'outputs', 'logs'
        param file_name: file name with extension
        return: absolute, normalize path tu file
        """
        return path.normpath(path.join(self.get_proj_root_fld, folder_name, file_name))

    def get_folder_path(self, folder_name):
        return path.normpath(path.join(self.get_proj_root_fld, folder_name))

    def populate_getters(self):
        # logs path as key this is not full path but only project related
        self.get_proj_folder_name = path.normpath(path.join(
            self.DEPARTMENT_ROOT_FOLDER,
            self.PROJECT_FOLDER,
            self.INPUTS_FOLDER))

        # joining paths for sharedrive
        self.get_proj_root_fld = path.normpath(path.join(self.MASTER_FOLDER,
                                                         self.DEPARTMENT_ROOT_FOLDER,
                                                         self.PROJECT_FOLDER))
        self.get_inputs_folder_path = path.normpath(path.join(self.get_proj_root_fld, self.INPUTS_FOLDER))
        self.get_outputs_folder_path = path.normpath(path.join(self.get_proj_root_fld, self.OUTPUTS_FOLDER))
        self.get_cop_snap_shot_folder_path = path.normpath(path.join(self.get_proj_root_fld, self.COP_SNAP_SHOT))
        self.get_spend_analysis_folder_path = path.normpath(path.join(self.get_proj_root_fld, self.SPEND_ANALYTICS))
        self.get_logs_folder_path = path.normpath(path.join(self.get_proj_root_fld, self.LOGS_FOLDER))

        # jenkins etl
        self.get_sap_import_view_url = self.JENKINS_PRE_URL + self.JENKINS_PROJ + self.SAP_IMPORT_JOB
        self.get_sap_import_trigger_url = self.JENKINS_PRE_URL + self.JENKINS_PROJ + self.SAP_IMPORT_TRIGGER

        self.get_import_view_url = self.JENKINS_PRE_URL + self.JENKINS_PROJ + self.IMPORT_JOB
        self.get_import_trigger_url = self.get_import_view_url + self.IMPORT_TRIGGER

        self.get_e2t_view_url = self.JENKINS_PRE_URL + self.JENKINS_PROJ + self.E2T_JOB
        self.get_e2t_trigger_url = self.get_e2t_view_url + self.E2T_TRIGGER

        self.get_t2l_view_url = self.JENKINS_PRE_URL + self.JENKINS_PROJ + self.T2L_JOB
        self.get_t2l_trigger_url = self.get_t2l_view_url + self.T2L_TRIGGER

        self.get_ods_view_url = self.JENKINS_PRE_URL + self.JENKINS_PROJ + self.ODS_JOB
        self.get_ods_trigger_url = self.get_ods_view_url + self.ODS_TRIGGER


class GPLEURConfig(ETLConfig):

    def __init__(self):
        super(GPLEURConfig, self).__init__()

        self.parent_project = gpl_eur
        self.gpl = GPLEUR
        self.this_project = "gpl_eur"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'12.GlobalPlantList'  # add sub folder here if needed
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/Global_Plant_List"

        self.IMPORT_JOB = '/job/gpl%20eur'
        self.IMPORT_TRIGGER = '/build?token=gpl_eur&cause={}'
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''

        self.populate_getters()


class GPLAMSConfig(ETLConfig):

    def __init__(self):
        super(GPLAMSConfig, self).__init__()

        self.parent_project = gpl_ams
        self.this_project = "gpl_ams"
        self.gpl = GPLAMS

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'12.GlobalPlantList'  # add sub folder here if needed
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Americas/job/Global_Plant_List"

        self.IMPORT_JOB = '/job/gpl_ams'
        self.IMPORT_TRIGGER = '/build?token=gpl_ams&cause={}'
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''

        self.populate_getters()


class LogAccrualsConfig(ETLConfig):

    def __init__(self):
        super(LogAccrualsConfig, self).__init__()

        self.parent_project = log_accruals
        self.gpl = GPLEUR
        self.this_project = "log_accruals_generate"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = "17.logistics_accruals"  # add sub folder here if needed
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/logistics_accruals"
        self.SAP_IMPORT_JOB = ''
        self.IMPORT_JOB = ''
        self.IMPORT_TRIGGER = ''
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''
        self.populate_getters()

        self.submit_both = self.JENKINS_PRE_URL + self.JENKINS_PROJ
        self.output_file = self.JENKINS_PRE_URL + self.JENKINS_PROJ + "/job/one_job"
        self.mef_file = self.JENKINS_PRE_URL + self.JENKINS_PROJ + "/job/one_job"

    def get_jenkins_url(self, report_name, email, signal):
        job_name = ''

        if report_name == 'output_file':
            job_name = "/job/one_job"
        if report_name == 'mef_file':
            job_name = "/job/one_job"

        self.get_import_trigger_url = (self.JENKINS_PRE_URL +
                                       self.JENKINS_PROJ +
                                       job_name +
                                       f"/buildWithParameters?token=logistics_accruals_eur&cause={email}" +
                                       f"&request_signal_name={signal}"
                                       )
        return self.get_import_trigger_url


class MakeAnalytics_Trace_Automation_Config(ETLConfig):
    def __init__(self):
        super(MakeAnalytics_Trace_Automation_Config, self).__init__()
        self.parent_project = make_analytics
        self.this_project = "trace_automation"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'8.MAKE_ANALYTICS_EUR'  # add sub folder here if needed
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/MAKE_ANALYTICS"

        self.SAP_IMPORT_JOB = f"/job/make_analytics.{self.this_project}_sap_inputs"

        self.IMPORT_JOB = f'/job/make_analytics.{self.this_project}_user_inputs'
        self.IMPORT_TRIGGER = '/build?token=trace_automation_ondemend&cause={}'
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''

        self.populate_getters()


class MakeAnalytics_Make_Costing_Config(ETLConfig):
    # 6100-1 db config proces id
    def __init__(self):
        super(MakeAnalytics_Make_Costing_Config, self).__init__()

        self.parent_project = make_analytics
        self.this_project = "make_costing"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'8.MAKE_ANALYTICS_EUR'  # add sub folder here if needed
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/MAKE_ANALYTICS"

        self.SAP_IMPORT_JOB = f"/job/make_analytics.{self.this_project}_sap_inputs"
        self.SAP_IMPORT_TRIGGER = "/build?token=make_costing_sap_inputs&cause={}"

        self.IMPORT_JOB = f'/job/make_analytics.{self.this_project}_user_inputs'
        self.IMPORT_TRIGGER = '/build?token=make_costing_ondemend&cause={}'
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''

        self.populate_getters()


class MakeAnalytics_Costing_Simulation_Config(ETLConfig):

    def __init__(self):
        super(MakeAnalytics_Costing_Simulation_Config, self).__init__()

        self.parent_project = make_analytics
        self.this_project = "costing_simulation"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'8.MAKE_ANALYTICS_EUR'  # add sub folder here if needed
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/MAKE_ANALYTICS"

        self.SAP_IMPORT_JOB = ''
        self.IMPORT_JOB = '/job/make_analytics.cost_simulation_csv_inputs'
        self.IMPORT_TRIGGER = "/build?token=cost_simulation_userinputs&cause={}"
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = ''
        self.ODS_TRIGGER = ''

        self.populate_getters()


class LocalTaxBeBevConfig(ETLConfig):
    def __init__(self):
        super(LocalTaxBeBevConfig, self).__init__()

        self.parent_project = local_tax
        self.this_project = "be_bev"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'7.LOCAL_TAX_EUR\declarations'
        self.PROJECT_FOLDER = 'BE_Beverage_tax'

        self.JENKINS_PROJ = "/job/Europe/job/LocalTax_EUR/"

        self.IMPORT_JOB = '/job/LocalTax.BeBev_CSV'
        self.IMPORT_TRIGGER = "/build?token=locl_tax_csv_ondemend&cause={}"
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = '/job/LocalTax.BEBev_SPROC'
        self.T2L_TRIGGER = "/build?token=locltax2ods&cause={}"
        self.ODS_JOB = '/job/LocalTax.BEBev_REPORT'
        self.ODS_TRIGGER = "/build?token=localtax_bebev_report&cause={}"

        self.populate_getters()


class COP2Config(ETLConfig):
    def __init__(self):
        super(COP2Config, self).__init__()
        self.parent_project = tp_update
        self.this_project = "cop2"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'6.FCST'
        self.PROJECT_FOLDER = 'fcst2'

        self.JENKINS_PROJ = "/job/Europe/job/Copernius_Tytan"

        self.SAP_IMPORT_JOB = '/job/FCST%202.0%20prod'
        self.IMPORT_JOB = '/job/fcst%202.0%20restcsv'
        self.IMPORT_TRIGGER = "/build?token=fcst2&cause={}"
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ""
        self.ODS_JOB = '/job/fcst%202.0%20ods'
        self.ODS_TRIGGER = "/build?token=fcst2ods&cause={}"

        self.populate_getters()

class MaterialToolsConfig(ETLConfig):
    def __init__(self):
        super(MaterialToolsConfig, self).__init__()

        self.parent_project = bpq_robot_rpm
        self.this_project = "store_procedures"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'4.BPQ_Robot'
        self.PROJECT_FOLDER = 'BPQ Downloads'
        self.OUTPUTS_FOLDER = 'downloaded reports'
        self.SPEND_ANALYTICS = 'spend_analysis'
        self.COP_SNAP_SHOT = 'cop_snapshots'
        self.LOGS_FOLDER = 'file_log'
        self.populate_getters()

class BPQDownloadsConfig(ETLConfig):
    def __init__(self):
        super(BPQDownloadsConfig, self).__init__()

        self.parent_project = bpq_robot_rpm
        self.this_project = "bpq_download"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'4.BPQ_Robot'
        self.PROJECT_FOLDER = 'BPQ Downloads'
        self.OUTPUTS_FOLDER = 'downloaded reports'
        self.LOGS_FOLDER = 'file_log'
        self.populate_getters()


class BPQRobotRPMConfig(ETLConfig):
    def __init__(self):
        super(BPQRobotRPMConfig, self).__init__()

        self.parent_project = bpq_robot_rpm
        self.this_project = "bpq_rpm"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'4.BPQ_Robot'
        self.PROJECT_FOLDER = 'Source_RPM/source_rpm'

        self.INPUTS_FOLDER = 'input'
        self.OUTPUTS_FOLDER = 'output'
        self.SAP_FILE_FOLDER = 'sapfile'
        self.SAP_TEXT_FILE_FOLDER = r'sapfile/saptxt'
        self.LOGS_FOLDER = 'file_log'

        self.JENKINS_PROJ = "/job/Europe/job/BPQ"

        self.SAP_IMPORT_JOB = '/job/bpq_robot_rpm'
        self.IMPORT_JOB = '/job/bpq_robot_rpm'
        self.IMPORT_TRIGGER = "/build?token=ubrrcsv&cause={}"
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = '/job/bpq_robot_rpm/'
        self.ODS_TRIGGER = "/build?token=ubrrcsv&cause={}"

        self.populate_getters()


class DecisionTreeGaiaConfig(ETLConfig):
    def __init__(self):
        super(DecisionTreeGaiaConfig, self).__init__()

        self.parent_project = bpq_robot_rpm
        self.this_project = "gaia"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'4.BPQ_Robot'
        self.PROJECT_FOLDER = 'DecisionTree_Gaia'

        self.INPUTS_FOLDER = 'inputs'
        self.OUTPUTS_FOLDER = 'outputs'
        self.LOGS_FOLDER = 'file_log'

        self.JENKINS_PROJ = "/job/Europe/job/Source"

        self.SAP_IMPORT_JOB = '/job/gaia_flask_inputs'
        self.IMPORT_JOB = '/job/gaia_flask_inputs'
        self.IMPORT_TRIGGER = "/build?token=gaia&cause={}"
        self.E2T_JOB = ''
        self.E2T_TRIGGER = ''
        self.T2L_JOB = ''
        self.T2L_TRIGGER = ''
        self.ODS_JOB = '/job/gaia_flask_inputs/'
        self.ODS_TRIGGER = "/build?token=gaia&cause={}"

        self.populate_getters()


class CMIRAMSPointOfContact(ETLConfig):
    def __init__(self):
        super(CMIRAMSPointOfContact, self).__init__()

        self.parent_project = cmir_ams
        self.this_project = "cmir_ams_poc"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'5. MI_EUR'
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/Costing_Missing_Input_MI"

        self.IMPORT_JOB = f'/job/{self.this_project}'
        self.IMPORT_TRIGGER = "/build?token=cmir_ams_poc&cause={}"
        self.populate_getters()


class CMIRPointOfContact(ETLConfig):
    def __init__(self):
        super(CMIRPointOfContact, self).__init__()

        self.parent_project = cmir
        self.this_project = "cmir_poc"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'5. MI_EUR'
        self.PROJECT_FOLDER = self.this_project

        self.JENKINS_PROJ = "/job/Europe/job/Costing_Missing_Input_MI"

        self.IMPORT_JOB = f'/job/{self.this_project}'
        self.IMPORT_TRIGGER = "/build?token=cmir_poc&cause={}"
        self.populate_getters()


class PMC_EUR_Config(ETLConfig):
    def __init__(self):
        super(PMC_EUR_Config, self).__init__()

        self.parent_project = pmc_eur
        self.this_project = "pmc_eur_bpq"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'11.PMC_EUR'
        self.PROJECT_FOLDER = 'BPQ_PMC_EUR'

        self.LOGS_FOLDER = 'file_log'

        self.JENKINS_PROJ = '/job/Europe/job/PMC'

        self.IMPORT_JOB = '/job/pmc_eur_userinput'
        self.IMPORT_TRIGGER = "/build?token=pmc_eur_input&cause={}"

        self.populate_getters()


class RubicsVsSUConfig(ETLConfig):
    def __init__(self):
        super(RubicsVsSUConfig, self).__init__()
        self.parent_project = rubiks_vs_su
        self.this_project = "tm1"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\UFO-General'
        self.DEPARTMENT_ROOT_FOLDER = r'SCFS_PP'
        self.PROJECT_FOLDER = 'TM1'

        self.IMPORT_FOLDER = 'import'
        self.INPUTS_FOLDER = 'input'
        self.Q_O_Q_SAMPLE_FOLDER = r'QoQ-sample'
        self.RUBIK_VS_SU_TOOL_FOLDER = r'Rubik Vs SU - Tool'

        self.JENKINS_PROJ = "/job/Europe/job/TM1"
        self.IMPORT_JOB = '/job/tm1'
        self.IMPORT_TRIGGER = "/build?token=flask_token_tm1&cause={}"

        self.populate_getters()


class InnovationCostingConfig(ETLConfig):
    def __init__(self):
        super(InnovationCostingConfig, self).__init__()

        self.parent_project = innovation_costing
        self.this_project = "innovation_costing_proj"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'1. Innovation Costing'
        self.PROJECT_FOLDER = 'Innovation Costing'

        self.JENKINS_PROJ = "/job/Europe/job/InnovationCosting"

        self.IMPORT_JOB = '/job/InnovationCosting_csv'
        self.IMPORT_TRIGGER = "/build?token=InnovationCosting_csv&cause={}"

        self.populate_getters()


class FETNAConfig(ETLConfig):
    def __init__(self):
        super(FETNAConfig, self).__init__()

        self.parent_project = fet
        self.this_project = "fet_na"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'18.FET_NA'
        self.PROJECT_FOLDER = 'FETNA'

        self.JENKINS_PROJ = "/job/Europe/job/FET_NA"

        self.IMPORT_JOB = '/job/Flask_FET_NA'
        self.IMPORT_TRIGGER = "/build?token=FET_NA&cause={}"

        self.populate_getters()


class TWCConfig(ETLConfig):
    def __init__(self):
        super(TWCConfig, self).__init__()
        self.parent_project = twc
        self.this_project = "twc_proj"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.DEPARTMENT_ROOT_FOLDER = r'21.TWC'
        self.PROJECT_FOLDER = self.this_project

        self.LOGS_FOLDER = 'file_log'

        self.JENKINS_PROJ = "/job/Europe/job/TWC"

        # self.IMPORT_JOB = 'job/TWC_Flask_USCC/'
        # self.IMPORT_TRIGGER = '/build?token=twc_uscc_sproc&cause={}'
        # self.E2T_JOB = ''
        # self.E2T_TRIGGER = ''
        self.T2L_JOB = '/job/TWC_Flask_USCC'
        self.T2L_TRIGGER = '/build?token=twc_uscc_sproc&cause={}'
        self.ODS_JOB = '/job/TWC_Flask_Stock'
        self.ODS_TRIGGER = '/build?token=twc_stock_import&cause={}'

        self.populate_getters()


class AmsDriverlessNAFcst(ETLConfig):
    def __init__(self):
        super(AmsDriverlessNAFcst, self).__init__()

        self.parent_project = driverless_na_fcst
        self.this_project = "ams_driverless_na_fcst"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\UFO-General\Driverless AMS'
        self.DEPARTMENT_ROOT_FOLDER = 'NA'
        self.PROJECT_FOLDER = 'FCST'

        self.JENKINS_PROJ = "/job/Americas/job/Driverless"

        self.SAP_IMPORT_JOB = '/job/Driverless%20NA/job/PREV/job/13.%20Driverless%20NA%20-%20FCST'
        self.IMPORT_JOB = '/job/Driverless%20NA/job/PREV/job/13.%20Driverless%20NA%20-%20FCST'
        self.IMPORT_TRIGGER = '/build?token=ams_driverless_na_fcst&cause={}'

        self.populate_getters()


class AmsDriverlessNaBuSplit(ETLConfig):
    def __init__(self):
        super(AmsDriverlessNaBuSplit, self).__init__()

        self.parent_project = driverless_na_bu_split
        self.this_project = "ams_driverless_na_bu_split"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\UFO-General\Driverless AMS'
        self.DEPARTMENT_ROOT_FOLDER = 'NA'
        self.PROJECT_FOLDER = 'BU Split'

        self.JENKINS_PROJ = "/job/Americas/job/Driverless"

        self.SAP_IMPORT_JOB = '/job/Driverless%20NA/job/PREV/job/15.%20Driverless%20NA%20-%20Split%20by%20BU'
        self.IMPORT_JOB = '/job/Driverless%20NA/job/PREV/job/15.%20Driverless%20NA%20-%20Split%20by%20BU'
        self.IMPORT_TRIGGER = "/build?token=ams_driverless_na_bu_split&cause={}"

        self.populate_getters()


class EurPrimaryTrackerBilling(ETLConfig):
    def __init__(self):
        super(EurPrimaryTrackerBilling, self).__init__()

        self.parent_project = primary_tracker
        self.this_project = "eur_primary_tracker_billing"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'EU_Primary_Tracker'

        self.JENKINS_PROJ = "/job/Europe/job/Primary%20Tracker"

        self.SAP_IMPORT_JOB = '/job/PrimaryTracker_Billing'
        self.IMPORT_JOB = '/job/PrimaryTracker_Billing'
        self.IMPORT_TRIGGER = "/build?token=eur_primary_tracker_billing&cause={}"

        self.populate_getters()


class EurPrimaryTrackerAccrual(ETLConfig):
    def __init__(self):
        super(EurPrimaryTrackerAccrual, self).__init__()

        self.parent_project = primary_tracker
        self.this_project = "eur_primary_tracker_accrual"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'EU_Primary_Tracker'

        self.JENKINS_PROJ = "/job/Europe/job/Primary%20Tracker"

        self.SAP_IMPORT_JOB = '/job/PrimaryTracker_Accrual'
        self.IMPORT_JOB = '/job/PrimaryTracker_Accrual'
        self.IMPORT_TRIGGER = "/build?token=eur_primary_tracker_accrual&cause={}"

        self.populate_getters()


class EurPrimaryTrackerSegmentation(ETLConfig):
    def __init__(self):
        super(EurPrimaryTrackerSegmentation, self).__init__()

        self.parent_project = primary_tracker
        self.this_project = "eur_primary_tracker_segmentation"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'EU_Primary_Tracker'

        self.JENKINS_PROJ = "/job/Europe/job/Primary%20Tracker"

        self.SAP_IMPORT_JOB = '/job/PrimaryTracker_Segmentation'
        self.IMPORT_JOB = '/job/PrimaryTracker_Segmentation'
        self.IMPORT_TRIGGER = "/build?token=eur_primary_tracker_segmentation&cause={}"

        self.populate_getters()


class AmsTwcAllMarlinDb(ETLConfig):
    def __init__(self):
        super(AmsTwcAllMarlinDb, self).__init__()

        self.parent_project = twc_ams
        self.this_project = "ams_twc_all_marlin_db"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'AMS_TWC'

        self.JENKINS_PROJ = "/job/Americas/job/TWC"

        self.SAP_IMPORT_JOB = '/job/C-37%20ALL_MARLIN_DB'
        self.IMPORT_JOB = '/job/C-37%20ALL_MARLIN_DB'
        self.IMPORT_TRIGGER = "/build?token=ams_twc_all_marlin_db&cause={}"

        self.populate_getters()


class AmsTwcMarlinFcst(ETLConfig):
    def __init__(self):
        super(AmsTwcMarlinFcst, self).__init__()

        self.parent_project = twc_ams
        self.this_project = "ams_twc_marlin_fcst"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'AMS_TWC'

        self.JENKINS_PROJ = "/job/Americas/job/TWC"

        self.SAP_IMPORT_JOB = '/job/C-38%20MARLIN%20FCST'
        self.IMPORT_JOB = '/job/C-38%20MARLIN%20FCST'
        self.IMPORT_TRIGGER = "/build?token=ams_twc_marlin_fcst&cause={}"

        self.populate_getters()


class AmsTwcVictory(ETLConfig):
    def __init__(self):
        super(AmsTwcVictory, self).__init__()

        self.parent_project = twc_ams
        self.this_project = "ams_twc_victory"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'AMS_TWC'

        self.JENKINS_PROJ = "/job/Americas/job/TWC"

        self.SAP_IMPORT_JOB = '/job/C-37%20Victory%20Files'
        self.IMPORT_JOB = '/job/C-37%20Victory%20Files'
        self.IMPORT_TRIGGER = "/build?token=ams_twc_victory&cause={}"

        self.populate_getters()


class AmsTwcCaptainASplit(ETLConfig):
    def __init__(self):
        super(AmsTwcCaptainASplit, self).__init__()

        self.parent_project = twc_ams
        self.this_project = "ams_twc_captain_a_split"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]
        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'AMS_TWC'

        self.JENKINS_PROJ = "/job/Americas/job/TWC"

        self.SAP_IMPORT_JOB = '/job/C-37%20CAPTAIN%20AMERICA'
        self.IMPORT_JOB = '/job/C-37%20CAPTAIN%20AMERICA'
        self.IMPORT_TRIGGER = "/build?token=ams_twc_captain_a_split&cause={}"

        self.populate_getters()


class DepreciationConfig(ETLConfig):
    def __init__(self):
        super(DepreciationConfig, self).__init__()
        self.parent_project = depreciationfc
        self.this_project = "depreciationfc_proj"

        self.PROJ_CODE_NAME = self.parent_project["code_name"]
        self.BLUEPRINT_NAME = self.parent_project["sub_pages"][self.this_project]["blueprint_name"]
        self.ETL_URL = self.parent_project["sub_pages"][self.this_project]["url"]
        self.PROJECT_TITLE = self.parent_project["sub_pages"][self.this_project]["name"]

        self.INPUTS_FOLDER = ''
        self.MASTER_FOLDER = r'\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd'
        self.DEPARTMENT_ROOT_FOLDER = 'UFO-General'
        self.PROJECT_FOLDER = 'Depreciation_FC'
        self.LOGS_FOLDER = 'file_log'

        self.JENKINS_PROJ = "/job/Europe/job/DepForecast"

        self.T2L_JOB = '/job/Depreciation_SPROC'
        self.T2L_TRIGGER = "/build?token=depreciation_excel&cause={}"

        self.populate_getters()
