from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField
from wtforms.validators import InputRequired


class GPLPlantForm(FlaskForm):
    """global plant list """

    Plant_Code = StringField("Plant Code", [InputRequired()])
    Company_Code = StringField("Company Code")
    Plant_Description = StringField("Plant Description")
    Plant_City = StringField("Plant City")
    Country = StringField("Country")
    MCO = StringField("MCO")
    SPTC_Code = StringField("SPTC Code")
    Currency = StringField("Currency")
    Type_Plant = StringField("Type Plant")
    OTIF_Plant_Type = StringField("OTIF Plant Type")
    Specific_Plant_Type = StringField("Specific Plant Type")
    Category = StringField("Category")
    Market = StringField("Market")
    Contact_Person = StringField("Contact Person")
    adm_plant_active = BooleanField('adm_plant_active')
    adm_last_change = StringField("adm_last_change")
    adm_modified_by = StringField("adm_modified_by")

    submit = SubmitField("Submit")


class GPLPlantForm_AMS(FlaskForm):
    """global plant list ams"""

    RegionGnr = StringField("Region Gnr")
    Plant_Code = StringField("Plant Code", [InputRequired()])
    Company_Code = StringField("Company Code")
    Plant_Type = StringField("Plant Type", [InputRequired()])
    Region = StringField("Region")
    Country = StringField("Country")
    Currency = StringField("Currency")
    Plant_Description = StringField("Plant Description", [InputRequired()])
    Plant_City = StringField("Plant City")
    Contact_Person = StringField("Contact Person")
    adm_plant_active = BooleanField('adm_plant_active')
    adm_last_change = StringField("adm_last_change")
    adm_modified_by = StringField("adm_modified_by")

    submit = SubmitField("Submit")
