# -*- coding: utf-8 -*-
"""
This is module wrapping view and blueprint as blueprint.
Generic solution for user inputs/ report outputs
Behavior is controled by config
"""
from datetime import datetime
from functools import wraps
import logging

from flask import Blueprint, redirect, session, render_template, request, url_for, flash
from flask_login import login_required, current_user

from src import db
from src.projects.etl_config import ETLConfig
from src.projects.gpl_manage.forms import GPLPlantForm
from src.projects.gpl_manage.models import GPLEUR
from src.utils.helpers import if_user_can_access

log = logging.getLogger(__name__)


def project_access(method):
    """
    Decorator for checking if user can access project
    with view /blueprint each call to function needs to be checked individually
    :param method:
    :return:
    """

    @wraps(method)
    def _impl(self, *args, **kwargs):
        if not self.project_code_name in session["projects_access_granted"]:
            return redirect(url_for('main.home'))
        else:
            return method(self, *args, **kwargs)

    return _impl


class BlueprintGPLEUR:
    """
    Class is view but wrapped around blueprint
    Adding rules to blueprint is way of implementing view
    Functions are what view is, generic function called by blueprint with rule = url
    Functions in most cases are wrapping arround config or providing IO operations
    """

    def __init__(self, bp_name, cfg):
        self.cfg: ETLConfig = cfg
        self.gpl = self.cfg.gpl
        self.blueprint = Blueprint(bp_name, __name__, static_folder='static', template_folder='templates')
        self.project_code_name = self.cfg.PROJ_CODE_NAME
        self.blueprint.add_url_rule('/gpl_add', view_func=self.gpl_add, methods=['GET', 'POST'])
        self.blueprint.add_url_rule('/gpl_all', view_func=self.gpl_all, methods=['GET', 'POST'])
        self.blueprint.add_url_rule('/gpl_edit/<int:id>', view_func=self.gpl_edit, methods=['GET', 'POST'])
        self.blueprint.add_url_rule('/gpl_delete/<int:id>', view_func=self.gpl_delete, methods=['GET', 'POST'])

    @login_required
    @project_access
    def gpl_all(self):
        session['breadcrumb'] = [(request.url_root + self.cfg.parent_project["url"], 'Back')]
        if current_user.is_authenticated:
            plants = self.gpl.query.order_by(self.gpl.id).all()
            return render_template('gpl_manage/gpl_all.html',
                                   plants=plants,
                                   viev_url=f'{self.blueprint.name}.gpl_view',
                                   edit_url=f'{self.blueprint.name}.gpl_edit',
                                   delete_url=f'{self.blueprint.name}.gpl_delete',
                                   title="All Plants",
                                   description="")

    @login_required
    @project_access
    def gpl_add(self):
        if self.cfg.PROJ_CODE_NAME not in session["projects_access_granted"]:
            return redirect(url_for('main.home'))
        session['breadcrumb'] = [(request.url_root + self.cfg.parent_project["url"], 'Back'),
                                 ('gpl_all', 'GPL all plants')]
        form = GPLPlantForm()
        if form.validate_on_submit():

            check_uniq = self.gpl.query.filter_by(Plant_Code=str.lower(form.Plant_Code.data)).first()
            if check_uniq:
                flash(f'Plant {str.upper(form.Plant_Code.data)} already exists', category='error')
            else:
                add_gpl = self.gpl(
                    Plant_Code=form.Plant_Code.data,
                    Company_Code=form.Company_Code.data,
                    Plant_Description=form.Plant_Description.data,
                    Plant_City=form.Plant_City.data,
                    Country=form.Country.data,
                    MCO=form.MCO.data,
                    SPTC_Code=form.SPTC_Code.data,
                    Currency=form.Currency.data,
                    Type_Plant=form.Type_Plant.data,
                    OTIF_Plant_Type=form.OTIF_Plant_Type.data,
                    Specific_Plant_Type=form.Specific_Plant_Type.data,
                    Category=form.Category.data,
                    Market=form.Market.data,
                    Contact_Person=form.Contact_Person.data,
                    adm_plant_active=1,
                    adm_last_change=datetime.utcnow(),
                    adm_modified_by=current_user.email
                )
                flash(f'Plant added!')
                db.session.add(add_gpl)
                db.session.commit()
            return redirect(url_for(f'{self.blueprint.name}.gpl_all'))

        return render_template('gpl_manage/gpl_add.html',
                               form=form,
                               title="Add new plant", description="")

    @login_required
    @project_access
    def gpl_edit(self, id):
        if not if_user_can_access(self.cfg.PROJ_CODE_NAME):
            return redirect(url_for('main.home'))

        if not current_user.is_authenticated:
            return redirect(url_for(f'{self.cfg.PROJ_CODE_NAME}.gpl_all'))
        session['breadcrumb'] = []
        plant:GPLEUR = self.gpl.query.filter_by(id=id).first()

        form = GPLPlantForm()
        if request.method == 'GET':
            form.Plant_Code.data = str(plant.Plant_Code)
            form.Company_Code.data = str(plant.Company_Code)
            form.Plant_Description.data = str(plant.Plant_Description)
            form.Plant_City.data = str(plant.Plant_City)
            form.Country.data = str(plant.Country)
            form.MCO.data = str(plant.MCO)
            form.SPTC_Code.data = str(plant.SPTC_Code)
            form.Currency.data = str(plant.Currency)
            form.Type_Plant.data = str(plant.Type_Plant)
            form.OTIF_Plant_Type.data = str(plant.OTIF_Plant_Type)
            form.Specific_Plant_Type.data = str(plant.Specific_Plant_Type)
            form.Category.data = str(plant.Category)
            form.Market.data = str(plant.Market)
            form.Contact_Person.data = str(plant.Contact_Person)
            form.adm_plant_active.data = str(plant.adm_plant_active)
            form.adm_last_change.render_kw = {'readonly': True}
            form.adm_last_change.data = str(plant.adm_last_change)
            form.adm_modified_by.render_kw = {'readonly': True}
            form.adm_modified_by.data = current_user.email

        if form.validate_on_submit():
            plant.Plant_Code = form.Plant_Code.data
            plant.Company_Code = form.Company_Code.data
            plant.Plant_Description = form.Plant_Description.data
            plant.Plant_City = form.Plant_City.data
            plant.Country = form.Country.data
            plant.MCO = form.MCO.data
            plant.SPTC_Code = form.SPTC_Code.data
            plant.Currency = form.Currency.data
            plant.Plant_Type = form.Type_Plant.data
            plant.OTIF_Plant_Type = form.OTIF_Plant_Type.data
            plant.Specific_Plant_Type = form.Specific_Plant_Type.data
            plant.Category = form.Category.data
            plant.Market = form.Market.data
            plant.Contact_Person = form.Contact_Person.data
            plant.adm_plant_active = form.adm_plant_active.data
            plant.adm_last_change = datetime.utcnow()
            plant.adm_modified_by = current_user.email

            db.session.commit()
            return redirect(url_for(f'{self.blueprint.name}.gpl_all'))

        return render_template('gpl_manage/gpl_edit.html',
                               form=form,
                               title=f"Update {str(plant.Plant_Code)}",
                               description=f"")

    @login_required
    @project_access
    def gpl_delete(self, id):
        if not if_user_can_access(self.cfg.PROJ_CODE_NAME):
            return redirect(url_for('main.home'))

        plant_to_delete = self.gpl.query.filter_by(id=id).first()
        db.session.delete(plant_to_delete)
        db.session.commit()
        return redirect(url_for(f'{self.blueprint.name}.gpl_all'))
