from src import db


class GPLEUR(db.Model):
    __tablename__ = 'GlobalPlantsList_EUR'

    id = db.Column(db.Integer, primary_key=True)
    Region = db.Column(db.String(250), default='USCC')
    Plant_Code = db.Column(db.String(250), unique=True)
    Company_Code = db.Column(db.String(250))
    Plant_Description = db.Column(db.String(250))
    Plant_City = db.Column(db.String(250))
    Country = db.Column(db.String(250))
    MCO = db.Column(db.String(250))
    SPTC_Code = db.Column(db.String(250))
    Currency = db.Column(db.String(250))
    Type_Plant = db.Column(db.String(250))
    OTIF_Plant_Type = db.Column(db.String(250))
    Specific_Plant_Type = db.Column(db.String(250))
    Category = db.Column(db.String(250))
    Market = db.Column(db.String(250))
    Contact_Person = db.Column(db.String(250))
    adm_plant_active = db.Column(db.Integer)
    adm_last_change = db.Column(db.DateTime)
    adm_modified_by = db.Column(db.String(250))

    def __repr__(self):
        return f" Region : {self.Region}, Plant_Code : {self.Plant_Code}, Company_Code : {self.Company_Code}," \
               f" Plant_Description : {self.Plant_Description}, Plant_City : {self.Plant_City}," \
               f" Country : {self.Country}, MCO : {self.MCO}, SPTC_Code : {self.SPTC_Code}, Currency : {self.Currency}," \
               f" Type_Plant : {self.Type_Plant}, OTIF_Plant_Type : {self.OTIF_Plant_Type}," \
               f" Specific_Plant_Type : {self.Specific_Plant_Type}, Category : {self.Category}," \
               f" Market : {self.Market}, Contact_Person : {self.Contact_Person}," \
               f" adm_plant_active : {self.adm_plant_active}," \
               f" adm_last_change : {self.adm_last_change}," \
               f" adm_modified_by : {self.adm_modified_by} "


class GPLAMS(db.Model):
    __tablename__ = 'GlobalPlantsList_AMS'

    id = db.Column(db.Integer, primary_key=True)
    RegionGnr = db.Column(db.String(250))
    Plant_Code = db.Column(db.String(250), unique=True)
    Company_Code = db.Column(db.String(250))
    Plant_Type = db.Column(db.String(250))
    Region = db.Column(db.String(250))
    Country = db.Column(db.String(250))
    Currency = db.Column(db.String(250))
    Plant_Description = db.Column(db.String(250))
    Plant_City = db.Column(db.String(250))
    Contact_Person = db.Column(db.String(250))
    adm_plant_active = db.Column(db.Integer)
    adm_last_change = db.Column(db.DateTime)
    adm_modified_by = db.Column(db.String(250))

    # def __repr__(self):
    #     return f"RegionGnr : {self.RegionGnr}, Plant_Code : {self.Plant_Code}, Company_Code : {self.Company_Code}," \
    #            f"Plant_Type : {self.Plant_Type},Region : {self.Region},Country : {self.Country}," \
    #            f"Currency : {self.Currency},Plant_Description : {self.Plant_Description}," \
    #            f"Plant_City : {self.Plant_City},Contact_Person : {self.Contact_Person}," \
    #            f" adm_plant_active : {self.adm_plant_active}," \
    #            f" adm_last_change : {self.adm_last_change}," \
    #            f" adm_modified_by : {self.adm_modified_by} "
