import logging

from flask import render_template, url_for, session
from flask_login import login_required, current_user

from src.main.forms import RedirectUrlTrigger
from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import DepreciationConfig
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cfg = DepreciationConfig()
df_bp = BlueprintETL(cfg, cfg.BLUEPRINT_NAME, cfg.PROJ_CODE_NAME).blueprint


@df_bp.route('/etl')
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    """
    what will be on sub_page
    no reporting printed so only input and trigger of input and recalculate sproc
    :return:
    """
    session['breadcrumb'] = [('main', 'Back')]
    log.info(f'{current_user.email}')


    run_sproc_t2l: RedirectUrlTrigger = RedirectUrlTrigger()
    run_sproc_t2l.url = url_for('.trigger_t2l')
    run_sproc_t2l.name = "Generate_Excel"
    run_sproc_t2l.target = "_blank"

    return render_template('etl_view.html',
                           run_stored_procedure_t2l=run_sproc_t2l,
                           title=cfg.PROJECT_TITLE,
                           description="")
