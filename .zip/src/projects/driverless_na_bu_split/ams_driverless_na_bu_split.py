import logging

from flask import render_template, url_for, session, request
from flask_login import login_required, current_user

from src.main.forms import RedirectUrlTrigger, InputFilesForm
from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import AmsDriverlessNaBuSplit
from src.projects.files_grid import FilesGrid
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cfg = AmsDriverlessNaBuSplit()
ams_driverless_na_bu_split_bp = BlueprintETL(cfg).blueprint


@ams_driverless_na_bu_split_bp.route('/etl', methods=['GET'])
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    session['breadcrumb'] = [(request.url_root + cfg.parent_project["url"], 'Back')]
    log.info(f'{current_user.email}')
    files_grids = list()

    csv_input_table = FilesGrid(cfg, cfg.INPUTS_FOLDER, cfg.INPUTS_FOLDER_EXTENSION)
    csv_input_table.caption = 'Inputs'
    csv_input_table.display_file_added_by()
    csv_input_table.download = True
    csv_input_table.delete = True
    files_grids.append(csv_input_table)

    view_jenkins: RedirectUrlTrigger = RedirectUrlTrigger()
    view_jenkins.url = url_for('.view_sap_import')
    view_jenkins.name = "View SAP files import"
    view_jenkins.target = "_blank"

    # run upit is default
    run_upit: RedirectUrlTrigger = RedirectUrlTrigger()
    run_upit.url = url_for('.run_upit')
    run_upit.name = "Run UPIT"
    run_upit.target = "_blank"

    file_upload_form = InputFilesForm()
    file_upload_form.url(url_for('.etl_upload'))

    return render_template('etl_view.html',
                           view_jenkins_link=view_jenkins,
                           run_upit_link=run_upit,
                           file_upload_form=file_upload_form,
                           files_grids=files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="")