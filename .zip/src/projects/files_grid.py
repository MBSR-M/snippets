from datetime import datetime
import logging
import os
from os import path, stat

import pytz

from src.projects.etl_config import ETLConfig
from src.projects.files_logs import FileLogger
from src.utils.helpers import convert_bytes


class FilesGrid:
    """
    Class handle populateing with info file table
    data are displayed by templates/macros.html/ function render_files_grid
    """

    def __init__(self, etl_config_object: ETLConfig, folder_name, endswith):
        """Init for config
        :param etl_config_object:
        :param folder_name:
        :param endswith:
        """
        self.cfg: ETLConfig = etl_config_object
        self.cfg_type = folder_name
        self.root_fld = path.normpath(path.join(self.cfg.get_proj_root_fld, self.cfg_type))
        self.logger = FileLogger(self.cfg.get_proj_folder_name)
        self.logger.get_folder_logs()
        self.endswith = endswith
        self.files_list, self.files_list_error = self._get_folder_content()
        self.files_list_detailed = self._scan_files_for_detials()
        self.files_detailed_table = self._populate_fields_with_file_info()
        self.titles = [
            ('id', 'Id'),
            ('file_name', 'File name'),
            ('folder_name', 'folder_name'),
            ('modified', 'Modified'),
            ('size', 'Size'),
            ('file_added_by', 'File added by')
        ]
        self._caption = ''
        # id, folder name, and file_added_by is not defaults needed data
        # for file_added_by there is appended function display_file_added_by
        self.titles_display_names = ['file_name', 'size', 'modified']
        # default buttons that can be used in grid table
        self.view = None
        self.view_url = '.view'
        self.delete = None
        self.delete_url = '.delete'
        self.delete_all_url = '.delete_all'
        self.edit = None
        self.edit_url = '.edit'
        self.download = None
        self.download_url = '.download'
        self.zip_download = None
        self.zip_download_url = '.zip_download'

    @property
    def caption(self) -> str:
        return self._caption

    @caption.setter
    def caption(self, text):
        self._caption = text

        if self.files_list_error:
            self._caption += ' >>>> ERROR: ' + self.files_list_error
            return

        if len(self.files_list) == 0:
            self._caption += ' (No files in the folder)'
            return

    def display_file_added_by(self):
        """
        if needed we can add column with Who added file
        """
        self.titles_display_names.append('file_added_by')

    def _get_folder_content(self):
        try:
            os.chdir(self.root_fld)
            files = filter(os.path.isfile, os.listdir(self.root_fld))
            files = [os.path.join(self.root_fld, f) for f in files]  # add path to each file
            files.sort(key=os.path.getmtime, reverse=True)
            files = [os.path.basename(f) for f in files]
        except Exception as e:
            logging.error({e})
            msg = str(e)
            return [], msg

        file_in_fld = [f for f in files if f.lower().split('.')[-1] in self.endswith]

        return file_in_fld, None

    def get_files_details(self, f):
        """
        Get files info like name,  modification time or size
        :param f:
        :return:
        """
        f_full_path = path.normpath(path.join(self.root_fld, f))
        f_info = stat(f_full_path)
        return [f, f_info.st_mtime, f_info.st_size]

    def _scan_files_for_detials(self):
        """
        get list of files with details
        :return:
        """
        files_info = []
        for f in self.files_list:
            f_info = self.get_files_details(f)
            if len(f_info) > 0:
                files_info.append(f_info)
        return files_info

    def _populate_fields_with_file_info(self):
        """
        Populate dict with files details that can be display on page
        :return:
        """
        info_fields = []

        for index, row in enumerate(self.files_list_detailed):
            file_name = row[0]
            tz = pytz.timezone('Europe/Warsaw')
            modification_date = datetime.fromtimestamp(row[1], tz=tz).strftime("%Y-%m-%d %H:%M:%S")
            file_size = convert_bytes(row[2])
            item = {
                'id': index,
                'file_name': file_name,
                'folder_name': self.cfg_type,
                'modified': modification_date,
                'size': file_size,
                'file_added_by': '',
            }

            file_added_by = self.logger.files_added_by.get(file_name)
            if file_added_by:
                item['file_added_by'] = file_added_by

            info_fields.append(item)

        return info_fields
