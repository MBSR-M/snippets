import logging

from flask import Blueprint, render_template, session
from flask_login import current_user, login_required

from src.projects.etl_config import bpq_robot_rpm
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

bpq_robot_rpm_bp = Blueprint('bpq_robot_rpm', __name__, static_folder='static', template_folder='templates')


@bpq_robot_rpm_bp.route('/')
@bpq_robot_rpm_bp.route('/main')
@project_access(bpq_robot_rpm_bp.name)
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(bpq_robot_rpm)
        session['breadcrumb'] = None
    else:
        log.info('guest')
        projects = []
    return render_template("index.html", projects=projects, title=bpq_robot_rpm["name"], description="")


