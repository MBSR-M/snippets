#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging

from flask import render_template, session, request
from flask_login import login_required, current_user

from src.main.forms import DownloadBPQFilesForm
from src.projects.blueprint_etl import BlueprintETL
from src.projects.bpq_robot_rpm.bpd_download_process import BPQDownloadRequest
from src.projects.etl_config import BPQDownloadsConfig
from src.projects.files_grid import FilesGrid
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cfg = BPQDownloadsConfig()
bpq_download = BlueprintETL(cfg).blueprint


@bpq_download.route('/etl', methods=['GET', 'POST'])
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    session['breadcrumb'] = [(request.url_root + cfg.parent_project["url"], 'Back')]
    log.info(f'{current_user.email}')
    files_grids = list()

    reports_table = FilesGrid(cfg, cfg.OUTPUTS_FOLDER, cfg.INPUTS_FOLDER_EXTENSION)
    reports_table.caption = 'BPQ Downloaded Reports'
    reports_table.download = True
    reports_table.delete = True
    files_grids.append(reports_table)

    file_download_form = DownloadBPQFilesForm()

    if request.method == 'POST' and file_download_form.validate_on_submit():
        if request.form.get('submit_download'):
            download_request : BPQDownloadRequest = BPQDownloadRequest(configuration=cfg, request_form=file_download_form)
            download_request.download_report_upload_to_project_directory()
    return render_template('etl_view.html',
                           file_download_form=file_download_form,
                           files_grids=files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="BPQ Downloaded Reports")
