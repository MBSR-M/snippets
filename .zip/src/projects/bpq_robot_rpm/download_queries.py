#!/usr/bin/env python3
# -*- coding: utf-8 -*-


SAMPLE = ""

ResourceVolumeQuery = """
SELECT
    [resource],
    '' as plnt_mrdr,
    Country_affiliation,
    [category],
    '' as vg4,
    '' as vg5,
    ISNULL(Sum(quantity_q1), 0) as quantity_q1,
    ISNULL(Sum(quantity_q2), 0) as quantity_q2,
    ISNULL(Sum(quantity_q3), 0) as quantity_q3,
    ISNULL(Sum(quantity_q4), 0) as quantity_q4,
    '' as Mtype,
    '' as new_vg4,
    '' as new_vg5,
    '' as new_category
FROM
    [bpq_source_copernicus].[copernicus_ods]
WHERE
    included_in_costing_run = 1 AND
    su_excl_bip = 0 AND
    exclusion_list = 0 AND
    bucket = 'Source' AND
    material_status IN ('60', '70', '80') AND
    volume_type = (SELECT cfg_value FROM [eur_bpq_source].BPQ_SOURCE_RPM_T_config WHERE cfg_key = 'volume_type')
GROUP BY
    [resource], [category], Country_affiliation
ORDER BY
    [resource]
"""


CETDataPivotQuery = """
with CET_data as(
select CoCd as [C.Code] , plnt as [Plant] , Mrdr as [Material],'' as [Mat. Typ], '' as [Mat. Grp]
					, '' as [Iss. Plant], '' as [Rep. Cntry], '' as [Category], '' as [Market], '' as [Sector]
					, '' as [SPF], '' as [Form], '' as [Sub-form], '' as [OH Key],[price_term_desc] as [Inco.]
					, M001_Q2 = ([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q2_price
					, M002_Q2 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q2_price)*freight_uplifts
					, M003_Q2 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q2_price)*Total_M003_uplift
					, M004_Q2 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q2_price)*Total_M004_uplift
					, M005_Q2 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q2_price)*Total_M005_uplift
					, M001_Q3 = ([final_NQ_M001_price]/[final_NQ_total_price])* new_fc_q3_price
					, M002_Q3 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q3_price)*freight_uplifts
					, M003_Q3 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q3_price)*Total_M003_uplift
					, M004_Q3 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q3_price)*Total_M004_uplift
					, M005_Q3 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q3_price)*Total_M005_uplift
					, M001_Q4 = ([final_NQ_M001_price]/[final_NQ_total_price])* new_fc_q4_price
					, M002_Q4 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q4_price)*freight_uplifts
					, M003_Q4 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q4_price)*Total_M003_uplift
					, M004_Q4 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q4_price)*Total_M004_uplift
					, M005_Q4 = (([final_NQ_M001_price]/[final_NQ_total_price])*new_fc_q4_price)*Total_M005_uplift
					,original_curr_code as Curr,per as [Price Unit],bun as [UoM]
 from [eur_bpq_source].[BPQ_SOURCE_RPM_ODS]
),
PivotedData AS (
    SELECT [C.Code],Plant,Material, [Inco.], Curr, [Price Unit],UoM,
        'M001' AS Price_Type, M001_Q2 AS Value,Concat('01.04.',YEAR(GETDATE())) AS Valid_from
    FROM CET_data
    UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M002', M002_Q2, Concat('01.04.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT  [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M003', M003_Q2, Concat('01.04.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT  [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M004', M004_Q2, Concat('01.04.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M005', M005_Q2, Concat('01.04.',YEAR(GETDATE()))
    FROM CET_data
	UNION ALL
	SELECT [C.Code],Plant,Material, [Inco.], Curr, [Price Unit],UoM,
        'M001', M001_Q3, Concat('01.07.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M002', M002_Q3, Concat('01.07.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT  [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M003', M003_Q3, Concat('01.07.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT  [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M004', M004_Q3, Concat('01.07.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M005', M005_Q3, Concat('01.07.',YEAR(GETDATE()))
    FROM CET_data
	UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M001', M001_Q4, Concat('01.10.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT  [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M002', M002_Q4, Concat('01.10.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT  [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M003', M003_Q4, Concat('01.10.',YEAR(GETDATE()))
    FROM CET_data
    UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M004', M004_Q4, Concat('01.10.',YEAR(GETDATE()))
    FROM CET_data
	 UNION ALL
    SELECT [C.Code],Plant,Material, '' as [Inco.], Curr, [Price Unit],UoM,
        'M005', M005_Q4, Concat('01.10.',YEAR(GETDATE()))
    FROM CET_data
)
SELECT [C.Code] AS [C.Code],Price_Type,Valid_from,Plant,Material,'' AS Mat_Typ,'' AS Mat_Grp,'' AS Iss_Plant,'' AS Rep_Cntry,'' AS Category
,'' AS Market,'' AS Sector,'' AS SPF,'' AS Form,'' AS Sub_form,'' AS OH_Key,[Inco.],ROUND(Value, 2) AS Value,Curr,[Price Unit],UoM
FROM PivotedData
where Uom  in ('PC')
--where Uom  in ('EA')
--where Uom NOt in ('EA','PC')

"""


ResourceDescriptionQuery = """
with CTE_ODSHistory AS
(
select *, ROW_NUMBER() OVER(PARTITION BY [Resource] order by [Year]*4+[Quarter]) as rn from [eur_bpq_source].[BPQ_SOURCE_RPM_ODS_History]
)
select distinct cop.resource, cop.plnt as plnt_code, cop.mrdr as gli_code, COALESCE(bpq.mrdr_desc,bpqh.mrdr_desc,'') as Description, COALESCE(bpq.network_new_way,bpqh.network_new_way,'') as Network, COALESCE(bpq.pt,bpqh.pt,'') as PT,
			COALESCE(bpq.pt,bpqh.pt,'') as new_PT_description, '' as Purchase_class,COALESCE(bpq.purchase_comm_desc,bpqh.purchase_comm_desc,'') as Purchase_commodity, '' as Material_class,
			COALESCE(bpq.mrdr_use_comm_desc,bpqh.mrdr_use_comm_desc,'') as Material_commodity
from [bpq_source_copernicus].[copernicus_ods] cop
left join [eur_bpq_source].[BPQ_SOURCE_RPM_ODS] bpq on cop.resource = bpq.resource
left join CTE_ODSHistory bpqh on cop.resource = bpqh.resource and rn =1
order by resource
"""
