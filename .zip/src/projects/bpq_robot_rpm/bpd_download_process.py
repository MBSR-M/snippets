#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import os
import warnings
from contextlib import contextmanager
from datetime import datetime

import pandas as pd
from flask import flash
from flask_login import current_user
from sqlalchemy import exc as sa_exc, text
from sqlalchemy.orm import sessionmaker
from werkzeug.utils import secure_filename

from src import db
from src.projects.bpq_robot_rpm.download_queries import ResourceVolumeQuery, CETDataPivotQuery, \
    ResourceDescriptionQuery
from src.projects.etl_config import BPQDownloadsConfig, MaterialToolsConfig

warnings.filterwarnings("ignore", category=sa_exc.SAWarning)

logger = logging.getLogger(__name__)

@contextmanager
def get_session():
    session = sessionmaker(bind=db.engine)()
    try:
        yield session
        session.commit()
    except Exception as e:
        logger.exception("An error occurred while logging")
        session.rollback()
        raise
    finally:
        session.close()


class BPQDownloadRequest:
    def __init__(self, configuration: BPQDownloadsConfig, request_form):
        self.cfg = configuration
        self.request_form = request_form
        self.query = None

    def download_report_upload_to_project_directory(self):
        report_type = self.request_form.select_field.data
        report_map = {
            'Resource Volume Report': ResourceVolumeQuery,
            'CET Data Pivot Report': CETDataPivotQuery,
            'Resource Description Report': ResourceDescriptionQuery
        }

        self.query = report_map.get(report_type, None)
        if self.query is not None:
            logger.info(f'Data download request received for: {report_type}')
            self.upload_data_to_project_directory()
        else:
            logger.warning(f'Unknown data download request received for: {report_type}')


    def get_data_from_database(self):
        with get_session() as session:
            try:
                data = session.execute(text(self.query)).fetchall()
                return data
            except Exception as e:
                logger.error(f"Error retrieving data: {str(e)}")
                raise


    def upload_data_to_project_directory(self):
        data = pd.DataFrame(self.get_data_from_database())
        if data.empty:
            flash(f'No data found for the selected report, {self.request_form.select_field.data}', 'danger')
        self.save_file(file_name=self.request_form.select_field.data, file_data=data)


    def save_file(self, file_name, file_data):
        try:
            file_name =f"{file_name.replace(' ', '_').upper()}_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
            file_data_filename = secure_filename(file_name)
            file_data.to_csv(os.path.join(self.cfg.get_outputs_folder_path, file_data_filename), index=False)
            flash(f'Report saved successfully, {file_name}', 'success')
            return file_data_filename
        except Exception as e:
            print(e)
            flash(f'An error occurred while downloading report, {file_name}', 'danger')
            logger.error(f'Report not saved, file_name: {file_name}, report : {self.request_form.select_field.data}')


class MaterialToolsDownloadRequest:
    def __init__(self, configuration: MaterialToolsConfig, request_form,
                 current_process, file_name = None, folder = None, file_path = None):
        self.cfg = configuration
        self.request_form = request_form
        self.current_process = current_process
        self.file_name = file_name
        self.folder = folder
        self.file_path = file_path

    def call_stored_procedure(self):
        result = False
        try:
            self.folder = self.cfg.get_cop_snap_shot_folder_path if self.current_process == 'cop_snap_shot' else self.cfg.get_spend_analysis_folder_path
            file = self.request_form.input_file.data
            self.file_name =f"{current_user.name.upper()}_INPUT_{self.current_process.upper()}_{secure_filename(file.filename).replace(' ', '_').replace('-', '_').replace('.', '_').upper()}_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
            self.file_path = os.path.join(self.folder, self.file_name)
            file.save(self.file_path)
            is_file_saved = True
            logger.info(f"File {self.file_name} saved successfully.")
            flash(f'File {self.file_name} saved successfully.', 'success')
        except Exception as e:
            logger.error(f"Error saving file: {str(e)}")
            flash(f'Error saving file: {str(e)}', 'danger')
            return
        if is_file_saved:
            if self.current_process == 'cop_snap_shot_process':
                logger.info(f"Starting stored procedure for COP SnapShot, using file: {self.file_path}")
                result = self.execute_stored_procedure('EUR_BPQ_SOurce.Update_Cop_SnapShot', self.file_path)
            elif self.current_process == 'spend_analytics':
                logger.info(f"Starting stored procedure for Spend Analysis, using file: {self.file_path}")
                result = self.execute_stored_procedure('EUR_BPQ_SOurce.Spend_Analysis', self.file_path)
            if result:
                logger.info(f"Stored procedure executed successfully for {self.current_process}.")
                flash(f'Stored procedure executed successfully for {self.current_process}.', 'success')
            else:
                logger.error(f"Error executing stored procedure for {self.current_process}.")
                flash(f'Error executing stored procedure for {self.current_process}.', 'danger')
            if self.current_process == 'spend_analytics':
                try:
                    data_Moulds, data_UPlift, data_Cylinders = self.get_data_from_database()
                    logger.info(f"Data retrieved for {self.current_process}.")
                    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                    base_filename = f"{current_user.name.upper()}_OUTPUT_{self.current_process.upper()}"
                    out_put_file_name_data_Moulds = f"{base_filename}_{secure_filename('eur_bpq_source.Moulds').replace(' ', '_').replace('-', '_').replace('.', '_').upper()}_{timestamp}.csv"
                    out_put_file_name_data_UPlift = f"{base_filename}_{secure_filename('eur_bpq_source.UPlift').replace(' ', '_').replace('-', '_').replace('.', '_').upper()}_{timestamp}.csv"
                    out_put_file_name_data_Cylinders = f"{base_filename}_{secure_filename('eur_bpq_source.Cylinders').replace(' ', '_').replace('-', '_').replace('.', '_').upper()}_{timestamp}.csv"
                    pd.DataFrame(data_Moulds).to_csv(os.path.join(self.folder, out_put_file_name_data_Moulds), index=False)
                    pd.DataFrame(data_UPlift).to_csv(os.path.join(self.folder, out_put_file_name_data_UPlift), index=False)
                    pd.DataFrame(data_Cylinders).to_csv(os.path.join(self.folder, out_put_file_name_data_Cylinders), index=False)
                    logger.info("Data saved successfully.")
                except Exception as e:
                    logger.error(f"Error processing data for {self.current_process}: {str(e)}")
        else:
            logger.error(f"Error in file saving for {self.file_name}.")
            flash(f'Error in file saving for {self.file_name}.', 'danger')
            return

    @staticmethod
    def execute_stored_procedure(param, file_name):
        with get_session() as session:
            try:
                session.execute(text(f"EXEC {param} '{file_name}'"))
                session.commit()
                logger.info(f"Stored procedure {param} executed successfully.")
                flash(f'Stored procedure {param} executed successfully.', 'success')
                return True
            except Exception as e:
                logger.error(f"Error executing stored procedure {param}: {str(e)}", exc_info=True)
                flash(f'Error executing stored procedure {param}: {str(e)}', 'danger')
                return False

    @staticmethod
    def get_data_from_database():
        with get_session() as session:
            try:
                queries = {
                    'Moulds': 'SELECT * FROM [eur_bpq_source].[Moulds];',
                    'Cylinders': 'SELECT * FROM [eur_bpq_source].[Cylinders];',
                    'UPlift': 'SELECT * FROM [eur_bpq_source].[UPlift];'
                }
                data = {}
                for key, query in queries.items():
                    logger.info(f"Executing query for {key}")
                    data[key] = session.execute(text(query)).fetchall()
                return data['Moulds'], data['UPlift'], data['Cylinders']
            except Exception as e:
                logger.error(f"Error retrieving data: {str(e)}")
                return None, None, None
