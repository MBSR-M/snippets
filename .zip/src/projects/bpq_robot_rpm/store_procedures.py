#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging

from flask import render_template, session, request
from flask_login import login_required, current_user

from src.main.forms import MaterialToolsForm, SpendAnalysisForm
from src.projects.blueprint_etl import BlueprintETL
from src.projects.bpq_robot_rpm.bpd_download_process import MaterialToolsDownloadRequest
from src.projects.etl_config import MaterialToolsConfig
from src.projects.files_grid import FilesGrid
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cfg = MaterialToolsConfig()
material_tools_store_procedures = BlueprintETL(cfg).blueprint


@material_tools_store_procedures.route('/etl', methods=['GET', 'POST'])
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    session['breadcrumb'] = [(request.url_root + cfg.parent_project["url"], 'Back')]
    log.info(f'{current_user.email}')
    files_grids = list()

    cop_snap_shot_request_form = MaterialToolsForm()
    spend_analytics_request_form = SpendAnalysisForm()

    spend_analysis = FilesGrid(cfg, cfg.SPEND_ANALYTICS, cfg.INPUTS_FOLDER_EXTENSION)
    spend_analysis.caption = 'Spend Analysis'
    spend_analysis.download = True
    spend_analysis.delete = True
    files_grids.append(spend_analysis)

    cop_snap_shot = FilesGrid(cfg, cfg.COP_SNAP_SHOT, cfg.INPUTS_FOLDER_EXTENSION)
    cop_snap_shot.caption = 'COP SNAP SHOT'
    cop_snap_shot.download = True
    cop_snap_shot.delete = True
    files_grids.append(cop_snap_shot)

    if request.method == 'POST' and cop_snap_shot_request_form.validate_on_submit():
        if request.form.get('start_store_process'):
            download_request : MaterialToolsDownloadRequest = MaterialToolsDownloadRequest(configuration=cfg, request_form=cop_snap_shot_request_form, current_process='cop_snap_shot')
            download_request.call_stored_procedure()
    elif request.method == 'POST' and spend_analytics_request_form.validate_on_submit():
        if request.form.get('start_store_process'):
            download_request : MaterialToolsDownloadRequest = MaterialToolsDownloadRequest(configuration=cfg, request_form=spend_analytics_request_form, current_process='spend_analytics')
            download_request.call_stored_procedure()
    return render_template('etl_view.html',
                           material_tools_form=cop_snap_shot_request_form,
                           spend_analytics_form=spend_analytics_request_form,
                           files_grids=files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="Store Procedures")
