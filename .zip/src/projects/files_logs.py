from datetime import datetime

from flask_login import current_user

from src.logs.models import FilesLogs
from src import db


class FileLogger:
    """
    In/out info about who uploaded file (by project folder, name)
    """
    def __init__(self, get_proj_folder_name):
        self.get_proj_folder_name = get_proj_folder_name
        self.files_added_by = dict()
        self.log_object: FilesLogs = FilesLogs.query.filter_by(project_folder=get_proj_folder_name).all()

    def get_folder_logs(self):
        for l in self.log_object:
            self.files_added_by[l.file_name] = l.user_name

    def update_file_log(self, file_name):
        log: FilesLogs = FilesLogs.query.filter_by(project_folder=self.get_proj_folder_name, file_name=file_name).first()
        if not log:
            log = FilesLogs(project_folder=self.get_proj_folder_name, file_name=file_name)
        log.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log.user_name = current_user.name

        db.session.add(log)
        db.session.commit()
  
        self.get_folder_logs()

    def get_file_log(self, file_name):
        return self.files_added_by[file_name]
