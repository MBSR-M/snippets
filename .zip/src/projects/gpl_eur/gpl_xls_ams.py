# -*- coding: utf-8 -*-

import logging

from flask import render_template, url_for, session, request
from flask_login import login_required, current_user

from src.projects.gpl_manage.blueprint_gpl_ams import BlueprintGPLAMS
from src.main.forms import RedirectUrlTrigger
from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import GPLAMSConfig, gpl_ams
from src.projects.files_grid import FilesGrid
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')
cfg = GPLAMSConfig()
gpl_etl_ams_bp = BlueprintETL(cfg).blueprint
gpl_manage_ams_bp = BlueprintGPLAMS('gpl_etl_ams_bp', cfg).blueprint


@gpl_etl_ams_bp.route('/main', methods=['GET', 'POST'])
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(gpl_ams)
        session['breadcrumb'] = None
    else:
        projects = []
    return render_template("index.html", projects=projects,
                           title='Global Plants List', description="")


@gpl_etl_ams_bp.route('/etl')
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    """
    what will be on sub_page
    upit run
    view jenkins sap jobs
    two triggers recalculate sproc
    set of outputs
        report

    :return:
    """
    session['breadcrumb'] = [(request.url_root + cfg.parent_project["url"],'Back'), ('gpl_all', 'GPL all plants')]
    log.info(f'{current_user.email}')
    # generic user input
    bebev_files_grids = list()

    xls_reports_table = FilesGrid(cfg, cfg.OUTPUTS_FOLDER, cfg.OUTPUTS_FOLDER_EXTENSION)
    xls_reports_table.caption = 'Reports'
    xls_reports_table.download = True
    xls_reports_table.delete = False
    bebev_files_grids.append(xls_reports_table)

    run_upit: RedirectUrlTrigger = RedirectUrlTrigger()
    run_upit.url = url_for('.run_upit')
    run_upit.name = "Generate new GPL file"
    run_upit.target = "_blank"

    return render_template('etl_view.html',
                           run_upit_link=run_upit,
                           files_grids=bebev_files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="")
