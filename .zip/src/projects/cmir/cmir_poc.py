from flask import render_template, url_for, session, request
from flask_login import login_required

from src.main.forms import RedirectUrlTrigger, InputFilesForm
from src.projects.blueprint_etl import BlueprintETL
from src.projects.etl_config import CMIRPointOfContact
from src.projects.files_grid import FilesGrid
from src.utils.helpers import project_access

cfg = CMIRPointOfContact()
cmir_poc_bp = BlueprintETL(cfg).blueprint


@cmir_poc_bp.route('/etl', methods=['GET'])
@project_access(cfg.PROJ_CODE_NAME)
@login_required
def etl():
    """
      what will be on sub_page
       trigger of input and recalculate sproc
       3 sets of outputs
          report
          sap regular
          sap zip
      :return:
      """
    session['breadcrumb'] = [(request.url_root + cfg.parent_project["url"], 'Back')]
    # generic user input
    files_grids = list()

    csv_input_table = FilesGrid(cfg, cfg.INPUTS_FOLDER, ['csv', 'xlsx'])
    csv_input_table.caption = 'Inputs'
    csv_input_table.display_file_added_by()
    csv_input_table.download = True
    csv_input_table.delete = True
    files_grids.append(csv_input_table)

    run_upit: RedirectUrlTrigger = RedirectUrlTrigger()
    run_upit.url = url_for('.run_upit')
    run_upit.name = "Import Point of Contact"
    run_upit.target = "_blank"

    file_upload_form = InputFilesForm()
    file_upload_form.url(url_for('.etl_upload'))

    return render_template('etl_view.html',
                           run_upit_link=run_upit,
                           file_upload_form=file_upload_form,
                           files_grids=files_grids,
                           title=cfg.PROJECT_TITLE,
                           description="")
