import logging

from flask import Blueprint, render_template, session
from flask_login import current_user, login_required

from src.projects.etl_config import cmir
from src.utils.helpers import project_access

log = logging.getLogger(__name__)

cmir_bp = Blueprint('cmir', __name__, static_folder='static', template_folder='templates')


@cmir_bp.route('/')
@cmir_bp.route('/main')
@project_access(cmir_bp.name)
@login_required
def main():
    if current_user.is_authenticated:

        projects = current_user.projects_access_granted(cmir)
        session['breadcrumb'] = None
    else:
        log.info(f'guest')
        projects = []

    return render_template("index.html", projects=projects,
                           title="",
                           description="")
