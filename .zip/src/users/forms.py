from flask_login import current_user
from flask_wtf import FlaskForm
from wtforms import TextAreaField, PasswordField, StringField, SubmitField, BooleanField
from wtforms.fields.choices import SelectMultipleField, SelectField
from wtforms.validators import DataRequired, Email, EqualTo, Length, InputRequired, ValidationError

from src.users.models import Users


class ContactForm(FlaskForm):
    """Contact form."""
    name = StringField('Name', [DataRequired()])
    email = StringField('Email', [Email(message=('Not a valid email address.')), DataRequired()])
    body = TextAreaField('Message', [DataRequired(), Length(min=4, message=('Your message is too short.'))])
    submit = SubmitField('Submit')


class Login(FlaskForm):
    """ login form"""

    email = StringField("Email", [Email(message="Not a valid email address."), DataRequired()])
    password = PasswordField('Password', [InputRequired()])
    remember = BooleanField('Remeber me')
    submit = SubmitField("Login")


class RegistrationForm(FlaskForm):
    name = StringField("Name", [DataRequired(), Length(min=3, max=30)])
    email = StringField("Email", [Email(message="Not a valid email address."), DataRequired()])
    password = PasswordField('New Password', [InputRequired(), EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Repeat Password')
    submit = SubmitField("Submit")

    def validate_name(self, username):
        user = Users.query.filter_by(name=username.data).first()
        if user:
            raise ValidationError('User name taken. Please chose different one.')

    def validate_email(self, useremail):
        email = Users.query.filter_by(email=useremail.data).first()
        if email:
            raise ValidationError('Email exists in database.')


class UpdateAccountForm(FlaskForm):
    name = StringField("Name", [DataRequired(), Length(min=3, max=30)])
    email = StringField("Email", [Email(message="Not a valid email address."), DataRequired()])

    submit = SubmitField("Update")

    def validate_name(self, username):
        if current_user.name != username.data:
            user = Users.query.filter_by(name=username.data).first()
            if user:
                raise ValidationError('User name taken. Please chose different one.')
        else:
            return True

    def validate_email(self, useremail):
        if current_user.email != useremail.data:
            email = Users.query.filter_by(email=useremail.data).first()
            if email:
                raise ValidationError('Email exists in database.')
        else:
            return True


class RequestPasswordResetForm(FlaskForm):
    email = StringField("Email", [Email(message="Not a valid email address."), DataRequired()])
    submit = SubmitField("Submit")

    def validate_email(self, useremail):
        email = Users.query.filter_by(email=useremail.data).first()
        if not email:
            raise ValidationError("Email don't exist. Please provide correct email or consider creating new account")


class NewPassword(FlaskForm):
    password = PasswordField('New Password', [InputRequired(), EqualTo('confirm', message='Passwords must match')])
    confirm = PasswordField('Repeat Password')
    submit = SubmitField("Submit")


class UserForm(FlaskForm):
    id = StringField('ID')
    email = StringField('Email')
    projects_access = SelectMultipleField('Projects Access')
    role = SelectField('role', choices=[(0, 'user'), (1, 'admin')])
    account_status = BooleanField(default=True)

    submit = SubmitField("Submit")
