# intro

In Flask, we don't have generic email functionality to reset password or confirm new user account. Workaround is, done by
Power flows set up on account of one of developers.

# Quick start

There are to Power Flows implemented 1) flask_new_user 2) Flask_password_request

## General

Power Flow (PF) have Trigger that monitors folder for new files. On user activity, json file is created, that PF picks up
and pars. Parsed file hods needed data to generate email and send it back to user.

## Flask New User

Admin routings are not implemented yet, user handling is done in db table
New user email is send to Admin for info only but this is unlikely for now as admin is leading new users through registration. BUT in the future.

```json
{
  "approval_route": "http://127.0.0.1:5000/admin/new_user/37/Andrzej Ostromecki/andrzej.ostromecki@unilever.com",
  "id": "37",
  "name": "Andrzej Ostromecki",
  "email": "andrzej.ostromecki@unilever.com",
  "admins_to_sendemail": "andrzej.ostromecki@unilever.com",
  "message": "This is automated message from Flask Web via Power Automate. \n There is new user regiesterd in flask page.id: 37\nname: Andrzej_Ostromecki\nemail: andrzej.ostromecki@unilever.com\n"
}
```

## Flask Password Request

link to reset pass with reset code is send to user.
after successful reset file is deleted.

```json
{
  "email": "andrzej.ostromecki@unilever.com",
  "route": "http://gnlgspw200022:999/users/password_reset/152456/37",
  "reset_code": "152456"
}
```