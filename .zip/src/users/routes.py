import json
import logging
import os
from random import random

import flask
from flask import flash, Blueprint, render_template, request, session, redirect, url_for
from flask_login import login_user, logout_user, current_user, login_required
from sqlalchemy import desc


from src import db, bcrypt
from src.admin.routes import admin_bp
from src.logs.models import UserActivityLog
from src.main.forms import NavBar
from src.users.forms import RegistrationForm, Login, UpdateAccountForm, RequestPasswordResetForm, NewPassword, UserForm
from src.users.models import Users, Projects

log = logging.getLogger(__name__)

nav = NavBar
users_bp = Blueprint('users', __name__, static_folder='static', template_folder='template')


@users_bp.route('/registration', methods=('GET', 'POST'))
def registration():
    """
    If is_authenticated == logged in then redirect
    provide valid inputs for new account
    :return: registration form or redirect to log in.
    """
    if current_user.is_authenticated:

        return redirect(url_for('main.home'))

    form = RegistrationForm()

    if form.validate_on_submit():
        request.form.get('password')
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = Users(name=form.name.data,
                     email=str.lower(form.email.data),
                     password=hashed_password,
                     projects_access='new_user',
                     role='user'
                     )
        db.session.add(user)
        db.session.commit()
        log.info(f'new registration: {form.email.data}')
        flash(f'Your account has been created! Wait for approval from admin.', 'success')

        # Let initialize Flow by dumping json in project folder
        # short: folder is monitored by MS Automate for new file, Json is consumed by flow for details and @ is send
        # @todo this is trigger for letting admins know if there is a new user
        trigger_new_user(str(user.id))

        return redirect(url_for('users.login'))

    return render_template("registration.html",
                           form=form,
                           title="Registration ",
                           description="Provide information for registration of your account")


def trigger_new_user(uid):
    """dumping json fiel with new user details"""
    user = Users.query.filter_by(id=uid).first()
    dump_new_user_file_to_admins('new_user', user)


def dump_new_user_file_to_admins(folder_name, user):
    """
    Printing json file with details for email notification.
    We don't have technicall means for sending emails from flask/brb
    Solution is to user power flow. Trigger is monittoring folder for new files. Flow pars json and act respectively.
    :param folder_name: project
    :param user: user object (id, email, name etc)
    """
    pass_url = f'{flask.request.host_url}admin/{folder_name}/{user.id}/{user.name}/{user.email}'
    FLASK_PAGE_FOLDER = r"//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/SCFS1/3Informatn/15. PROJECT/10.FlaskWeb/"
    request_file = os.path.normpath(os.path.join(FLASK_PAGE_FOLDER, 'new_user', str(user.id) + '.json'))

    admins = Users.query.filter_by(role='admin')
    admins_emails = [a.email for a in admins]

    payload = dict()
    payload['approval_route'] = pass_url
    payload['id'] = str(user.id)
    payload['name'] = user.name
    payload['email'] = user.email
    payload['admins_to_sendemail'] = 'andrzej.ostromecki@unilever.com'  # admins_emails
    payload['message'] = f"This is automated message from Flask Web via Power Automate. \n" \
                         f" There is new user regiesterd in flask page." \
                         f"id: {user.id}\n" \
                         f"name: {user.name.replace(' ', '_')}\n" \
                         f"email: {user.email}\n"

    if os.path.exists(request_file):
        os.remove(request_file)

    with open(request_file, 'w') as f:
        json.dump(payload, f)


@users_bp.route('/test_registration/<string:uid>', methods=('GET', 'POST'))
def test_registration(uid):
    """test with
        flask:0000/users/test_registration/123
    """
    trigger_new_user(uid)
    return "ok"


@users_bp.route('/login', methods=('GET', 'POST'))
def login():
    if current_user.is_authenticated:

        return redirect(url_for('main.home'))
    form = Login()

    if form.validate_on_submit():
        user = Users.query.filter_by(email=str.lower(form.email.data)).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            # @todo we have logged user, we can add it to
            log.info(f'logging:{form.email.data}')
            login_user(user, remember=form.remember.data)
            next_page = 'main.home' if request.args.get('next') is None else request.args.get('next')[1:]

            return redirect(url_for(next_page))
        else:
            flash(f'Login unsuccessful! Please check your inputs.', 'danger')

    return render_template("login.html",
                           form=form,
                           title="Login",
                           description="Provide information to login")


@users_bp.route('/logout', methods=('GET', 'POST'))
def logout():
    if current_user.is_authenticated:

        logout_user()
    return redirect(url_for('main.home'))


@users_bp.route('/account', methods=['POST', 'GET'])
def account():
    # @todo - add password change option for account not only name and email
    """
    account update account details - user, password

    :return:
    """
    if not current_user.is_authenticated:
        log.info(f'guest')
        return redirect(url_for('main.home'))

    form = UpdateAccountForm()

    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.email = form.email.data

        db.session.commit()
        log.info(f'update name:{form.name.data}, update email {current_user.email}')
        flash(f'Your account has been updated!', 'success')
        return redirect(url_for('users.account'))

    elif request.method == 'GET':

        form.name.data = current_user.name
        form.email.data = current_user.email

    return render_template('account.html',
                           form=form,
                           title="Your account",
                           description="")


@users_bp.route('/request_pass_reset', methods=['POST', 'GET'])
def request_pass_reset():
    """
    We dont have generic email account to hardcode pop3/smtp so we're goint to use power automate (flow)
    :return:
    """

    form = RequestPasswordResetForm()

    if form.validate_on_submit():
        user = Users.query.filter_by(email=str.lower(form.email.data)).first()
        reset_code = str(random())[2:8]
        user_id = str(user.id)
        pass_reset_url = f'{flask.request.host_url}users/password_reset/{reset_code}/{user.id}'
        dump_request_file(pass_reset_url, reset_code, user_id, user.email)
        log.info(f'reset{user.email}')
        return redirect(url_for('users.wait_for_reset'))

    return render_template("reset.html",
                           form=form,
                           title="Reset password",
                           description="Provide email that you use during registration")


def dump_request_file(pass_reset_url, reset_code, user_id, user_email):
    """
    Password reset json dump to be picked up by power flow
    :param pass_reset_url:
    :param reset_code:
    :param user_id:
    :param user_email:
    """
    FLASK_RESET_FOLDER = r"//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/SCFS1/3Informatn/15. PROJECT/10.FlaskWeb/"
    request_file = os.path.normpath(
        os.path.join(FLASK_RESET_FOLDER, 'messages', f'{user_id}.json')
    )
    payload = dict()
    payload['email'] = user_email
    payload['route'] = pass_reset_url
    payload['reset_code'] = reset_code

    if os.path.exists(request_file):
        os.remove(request_file)

    with open(request_file, 'w') as f:
        json.dump(payload, f)


@users_bp.route('/wait_for_reset')
def wait_for_reset():
    log.info(f'guest')
    return render_template("wait_for_reset.html")


@users_bp.route('/password_reset/<string:reset_code>/<string:uid>', methods=['GET', 'POST'])
def password_reset(reset_code, uid):
    """
    Actual pass reset function
    :param reset_code: way of checking if request for rest is valid
    :param uid: user id in db
    :return: redirect to proper page
    """
    # get user from db
    user = Users.query.filter_by(id=uid).first()
    log.info(f'reset{user.email}')
    # get json dump with name: id  + .json
    FLASK_RESET_FOLDER = r"//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/SCFS1/3Informatn/15. PROJECT/10.FlaskWeb/"
    request_file = os.path.normpath(
        os.path.join(FLASK_RESET_FOLDER, 'messages', f'{uid}.json')
    )
    # read json
    if os.path.exists(request_file):
        with open(request_file, 'r') as f:
            request_object = json.load(f)
    # checks if valid
    if_not_valid_code = reset_code != request_object["reset_code"]
    if_not_valid_email_owner = user.email != request_object["email"]
    # if not valid
    if if_not_valid_code or if_not_valid_email_owner:
        log.info(f'not valid reset password')
        flash('Not valid', 'Error')
        return redirect(url_for('users.request_pass_reset'))

    form = NewPassword()
    # if valid
    if form.validate_on_submit():
        if_code_ok = reset_code == request_object["reset_code"]
        #  @todo is this redundant check?
        if if_code_ok:
            try:
                log.info(f'reset password {user.email}')
                # commit new pass
                user.password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
                db.session.commit()
            except Exception as e:
                flash(f'Error with connecting to db, '
                      f'please try in a moment\n{e}')
            else:
                # clean up file
                # @todo adding time check for file can be an overkill but still
                os.remove(request_file)

            return redirect(url_for('users.login'))

    return render_template("reset.html",
                           form=form,
                           title="Provide new password",
                           description="")


@admin_bp.route('/users_table')
@login_required
def users_table():
    session['breadcrumb'] = [('main', 'Back')]
    if not session["is_admin"]:
        return redirect(url_for('main.home'))
    users: Users = Users.query.all()

    desc = """
    This view is for overview purpose not as UI for managing users.
    For editing hit SQL table in SCFS_WEB schema.
     """
    return render_template("users/users_table.html",
                           users=users,
                           title='',
                           description=desc)


@admin_bp.route('/user_edit/<int:id>', methods=['GET', 'POST'])
@login_required
def user_edit(id):
    session['breadcrumb'] = [('main', 'Back')]
    if not session["is_admin"]:
        return redirect(url_for('main.home'))
    log.info(f'{current_user.email}')
    users: Users = Users.query.filter_by(id=id).first()
    projects = Projects.query.order_by(Projects.id).all()
    form = UserForm()

    if request.method == 'GET':
        form.id.data = users.id
        form.email.data = users.email
        form.projects_access.choices = Projects.get_all_projects(projects)
        form.projects_access.process_data(Projects.get_access_id_index(users, projects))
        form.role.process_data(users.role)
        form.account_status.data = str(users.account_status)

    return render_template('users/user_edit.html', form=form, title="", description="")


@admin_bp.route('/users_activity_log')
@login_required
def users_activity_log():
    session['breadcrumb'] = [('main', 'Back')]
    if not session["is_admin"]:
        return redirect(url_for('main.home'))
    page = request.args.get('page', 1, type=int)
    dblog = UserActivityLog.query.order_by(UserActivityLog.timestamp.desc()).paginate(page=page, per_page=100,
                                                                                      error_out=False)
    return render_template("users/users_activity_log.html", dblog=dblog, title='Users log', description='')
