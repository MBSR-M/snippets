-- auto-generated definition
create table SCFS_WEB.Users
(
    id              int identity
        primary key,
    name            varchar(20)  not null,
    email           varchar(120) not null
        constraint AK_email
            unique,
    password        varchar(60)  not null,
    projects_access varchar(200),
    role            varchar(200),
    image_file      varchar(200) not null,
    account_status  varchar(50) default 'active'
)
go

