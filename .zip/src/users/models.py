import logging

from flask import session, flash, redirect, url_for, request
from flask_login import UserMixin

from src import db, login_manager

log = logging.getLogger(__name__)


@login_manager.unauthorized_handler
def handle_needs_login():
    log.info(f'{request.remote_addr}')
    flash("You have to be logged in to access this page.")
    return redirect(url_for('users.login'))


@login_manager.user_loader
def load_user(user_id):
    user: Users = Users.query.get(int(user_id))
    session["is_admin"] = (user.role == 'admin')
    session["projects_access_granted"] = str.split(user.projects_access, ",")
    return user


users_access = db.Table('users_access',
                        db.Column('user_id', db.Integer, db.ForeignKey('SCFS_WEB.Users.id')),
                        db.Column('project_id', db.Integer, db.ForeignKey('SCFS_WEB.Projects.id')),
                        schema='SCFS_WEB'
                        )


class Projects(db.Model):
    __tablename__ = 'Projects'
    __table_args__ = {"schema": "SCFS_WEB"}
    id = db.Column(db.Integer, primary_key=True)
    projects = db.Column(db.String(100), unique=True, nullable=False)
    users = db.relationship('Users', secondary=users_access, back_populates='projects')

    @staticmethod
    def get_all_projects(_projects):
        return [(project.id, f'{project.projects}') for project in _projects]

    @staticmethod
    def get_access_id_index(users, _projects):
        ids = list()
        for index, project in enumerate(_projects):
            if project.projects in users.projects_access:
                ids.append(index)
        return ids

    def __repr__(self):
        return f"Projects('{self.id}', '{self.projects}')"

    def if_project_registered(self, project_name):
        for project in self.projects:
            if project.projects in project_name.split(','):
                log.info(f'yes for :{project.projects}')
            else:
                log.info(f'no for :{project.projects}')


class Users(db.Model, UserMixin):
    __tablename__ = 'Users'
    __table_args__ = {"schema": "SCFS_WEB"}
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    projects_access = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(200))
    image_file = db.Column(db.String(20), default='default.png', nullable=False)
    account_status = db.Column(db.String(50), default='active', nullable=False)
    projects = db.relationship('Projects', secondary=users_access, back_populates='users')

    def __repr__(self):
        return f"User('{self.name}', '{self.name}')"

    @staticmethod
    def is_admin(current_user):
        return current_user.role == 'admin'

    @staticmethod
    def projects_access_granted(project_name):
        """List of urls that user have access
        :param project_name: list of projects that user can have access.
        Depending on level on whit we call this furnction variable can be all implemented projects in app
        or just list of subproject for bigger projects
        :return: list of projects with access granted
        """
        user_access = session["projects_access_granted"]
        if not user_access:
            return []

        if user_access == ['all']:
            return project_name
        set_common = []

        if type(project_name) is list:
            for proj in project_name:
                if proj["code_name"] in user_access:
                    set_common.append(proj)

        if type(project_name) is dict:
            if project_name["code_name"] in user_access:
                for sup_page in project_name["sub_pages"].items():
                    set_common.append(sup_page[1])

        return set_common
