# SCFS : Flask webpage

Prod:
Project page: [https://flask.s2.ms.unilever.com:89/](https://flask.s2.ms.unilever.com:89/)
Project repository: [https://gitea.s2.ms.unilever.com:3000/](https://gitea.s2.ms.unilever.com:3000/)
QA:
Project page: [https://flask_qa.s2.ms.unilever.com:89/](https://flask_qa.s2.ms.unilever.com:89/)
QA Project repository: [https://gitea_qa.s2.ms.unilever.com:3000/](https://gitea_qa.s2.ms.unilever.com:3000/)


* Environment
    * Windows 10
    * 64-bit OS, x64-based processor
    * Python 3.10
* Dependance
  * upit config
  * env file 
  * 
  if missing create file `C:\py_dev\servers_mapping.ini` in each environment that `upit` is running. 
  And yes, for local development, create fld path and file. 
  Add your pc name and pick your target server ( CMD run `hostname` to get you pc name)
    copy past below values
        
  ```ini
  #https://docs.python.org/3.11/library/configparser.html
  # commenting out with `#` or `;`, only one uncommented is allowed
  [servers]
  
  ##PROD  short gcp200034 ==> gnlgfpw200034
  env = gcp200034
  JENKINS_PRE_URL = http://gnlgspw200022
  BOOTSTRAP_BOOTSWATCH_THEME = superhero
    
  ##QA gcp200021 ==> gfrgfqw200021
  #env = gcp200021
  #JENKINS_PRE_URL = http://gfrgsqw200014
  #BOOTSTRAP_BOOTSWATCH_THEME = journal
    
  ##DR gfrgfpw200014  ==> gfrgfpw200014
  #env = gfrgfpw200014
  #JENKINS_PRE_URL = http://gnlgspw200022
  #BOOTSTRAP_BOOTSWATCH_THEME = superhero
  ```

## known issues

* slow IIS start
* slow saving of large files

## Installation

Make sure that you have proper values in development system variables pointing to host url.

Prod

```commandline
setx jenkins_pre_url http://gnlgspw200022
```

QA

```commandline
setx jenkins_pre_url http://gfrgsqw200014
```

OLD BRB

```commandline
setx jenkins_pre_url http://brbsapp26651
```

install 
https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server?view=sql-server-ver15#version-17

```python
import os
jenkins_pre_url = os.environ['jenkins_pre_url']
```

```commandline
git pull
py -3.10 -m venv env
env\Scripts\activate {enter}
py -m pip install -r requirements.txt --no-index --find-links=\\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\UFO-General\INTERFACE\UPIT\pypi\
py -m pip install --upgrade pip
```

Restart IIS sever Check if new changes took effect

### Page graphical layout

Add name in config

* [Bootstrap Theme](https://mkdocs.github.io/mkdocs-bootswatch)

### setup IIS

https://netdot.co/2015/03/09/flask-on-iis/

# Administration

In db aiedugspdb20006 look for schema SCFS_WEB Users - user table Logs - logs for files upload

Logs where moved to local folder and this is reflected in prod /qa setup
``` 
    cd C:/py_dev/proj/scfs_web
    mkdir logs
```

## Adding new user

User register with [register](https://flask.s2.ms.unilever.com:89/users/registration)
user will be prompt for uniq name (check in registerd users names)
valid email password

After confirm:

- json file will be printed in \\S2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\SCFS1\3Informatn\15.
  PROJECT\10.FlaskWeb\new_user
- User will be redirected to wait page.
- Power Flow is monitoring this folder for new files and trigger flow that parse respective new file.Flow usualy takse
  5-7 mins to send notification.
- Json file holds details of new user and send @ notification to administrator.
- Admin needs to manually edit user table by granting access to respective project.

## Deploy

```command
py -m pip download -r requirements.txt -d \\s2.ms.unilever.com\dfs\ES-GROUPS\cor\frd\UFO-General\INTERFACE\UPIT\pypi\ 
```