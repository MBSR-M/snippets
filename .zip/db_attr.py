# -*- coding: utf-8 -*-
sp1p = {
    "S1P": r"//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/UFO-General/INTERFACE/S1P/",
    "P1P": r'//S2.ms.unilever.com/dfs/ES-GROUPS/cor/frd/UFO-General/INTERFACE/P1P/'
}
upit_config_db = '\\\\S2.ms.unilever.com\\dfs\\ES-GROUPS\\cor\\frd\\SCFS1\\3Informatn\\3.THOR\\upit_config.db'
db_attr = {
    "gcp200034": { # PROD
        "driver": "SQL Server",
        "server": "gnlgfpw200034",
        "database": "sqld50016p",
        "trusted": "no",
        "uid": "svc_SCFS-sql-prod",
        "pwd": "Krekelstraat123#",
        "port": "1433",
    },
    "gcp200021": { # QA
        "driver": "SQL Server",
        "server": "gfrgfqw200021",
        "database": "aiedugsqd0000",
        "trusted": "no",
        "uid": "svc_SCFS-sql-prod",
        "pwd": "Krekelstraat123#",
        "port": "1433",
    },
}

