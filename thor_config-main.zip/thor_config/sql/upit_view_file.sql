alter VIEW SCFS_ETL.upit_view_file AS
SELECT ufe.[File_ID],
       upn.[Pattern_Id],
       upn.[Pattern_Name],
       ufe.[File_Name] AS [File_Prefix_Name],
       ufe.[Table_Name],
       uph.[Path_Info] AS [File_Folder],
       ufe.[Column_number],
       ufe.[Key_column],
       ufe.[Key_column_Value],
       ups.[Project_Name],
       ufe.[Delete_flag_fileLevel],
       ufe.[Delete_flag_TableLevel],
       ufe.[File_SP_EtoT],
       ufe.[Process_SP_LtoODS],
       ufe.[Table_SP_TtoL],
       ufe.[File_mandatory_flag],
       ufe.[Project_ID],
       ufe.[Process_ID],
       ups.[Process_Name]
FROM SCFS_ETL.upit_file ufe
         INNER JOIN SCFS_ETL.upit_pattern upn ON ufe.[Pattern_ID] = upn.[Pattern_Id]
         INNER JOIN SCFS_ETL.upit_process ups ON ufe.[Process_ID] = ups.[Process_ID] AND ufe.[Project_ID] = ups.[Project_ID]
         INNER JOIN SCFS_ETL.upit_path uph ON ufe.[Path_ID] = uph.[Path_ID]
WHERE ufe.[Enable_Flag] = 1
go

