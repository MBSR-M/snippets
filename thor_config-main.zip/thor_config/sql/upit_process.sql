--U TABLE -- P Procedure
 IF OBJECT_ID('SCFS_ETL.upit_process', 'U') IS NOT NULL
    DROP Table SCFS_ETL.upit_process;
  go
  

create table SCFS_ETL.upit_process
(
    Process_ID   varchar(max),
    Process_Name varchar(max),
    Project_ID   int,
    Project_Name varchar(max)
)
go

