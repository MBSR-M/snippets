--U TABLE -- P Procedure
 IF OBJECT_ID('SCFS_ETL.upit_pattern', 'U') IS NOT NULL
    DROP Table SCFS_ETL.upit_pattern;
  go
  

create table SCFS_ETL.upit_pattern
(
    Pattern_Id   int,
    Pattern_Name varchar(max)
)
go

