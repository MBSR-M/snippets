--U TABLE -- P Procedure
 IF OBJECT_ID('SCFS_ETL.upit_file', 'U') IS NOT NULL
    DROP Table SCFS_ETL.upit_file;
  go
  

create table SCFS_ETL.upit_file
(
    File_ID                int          not null,
    Pattern_ID             int          not null,
    Project_ID             int          not null,
    Process_ID             varchar(max) not null,
    File_Name              varchar(max),
    Table_Name             varchar(max),
    Column_number          int,
    Path_ID                int,
    Delete_flag_fileLevel  int,
    Key_column             varchar(max),
    Key_column_Value       varchar(max),
    Delete_flag_TableLevel int,
    File_SP_EtoT           varchar(max),
    Table_SP_TtoL          varchar(max),
    Process_SP_LtoODS      varchar(max),
    File_mandatory_flag    int,
    Enable_Flag            int
)
go

