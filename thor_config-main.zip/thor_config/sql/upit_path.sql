--U TABLE -- P Procedure
 IF OBJECT_ID('SCFS_ETL.upit_path', 'U') IS NOT NULL
    DROP Table SCFS_ETL.upit_path;
  go
  

create table SCFS_ETL.upit_path
(
    Path_ID   int,
    Path_Info varchar(max)
)
go

