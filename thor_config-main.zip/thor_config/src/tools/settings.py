# -*- coding: utf-8 -*-
import os

DB_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src')
DB_F = os.path.join(DB_FOLDER, '../upit_config.db')
DB_SCHEMA = os.path.join(DB_FOLDER, '../schema')
DB_DATA = os.path.join(DB_FOLDER, '../data')
DB_VIEW = os.path.join(DB_FOLDER, '../view')
