# -*- coding: utf-8 -*-

import logging
import sqlite3

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')


class LiteEngine:
    def __init__(self, db_path):
        self.conn = sqlite3.connect(db_path)

    def __enter__(self):
        return self.conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.conn.commit()
        self.conn.close()
