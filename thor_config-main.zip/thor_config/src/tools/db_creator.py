# -*- coding: utf-8 -*-

import csv
import logging
import os

from tools.liteEngine import LiteEngine
from tools.settings import DB_DATA, DB_F, DB_SCHEMA, DB_VIEW

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')


class DbCreator:

    def __init__(self, trigger):
        self.trigger = trigger

    def create_db(self):
        if self.trigger:
            logging.info("Start building sqlite3 db file")

            with LiteEngine(DB_F) as lite:
                self.create_tables(lite)
                self.insert_data(lite)
                self.create_view(lite)

            logging.info("DB file created and ready for production")

            raise SystemExit

    def insert_data(self, db_con):
        f: os.DirEntry
        for f in os.scandir(DB_DATA):
            logging.info(f"Inserting data to table using {f.name}")

            tb_name = os.path.splitext(f.name)[0]

            with open(f.path, 'r') as tb_data:
                dict_rows = csv.DictReader(tb_data)
                header = dict_rows.fieldnames
                db_value = self.create_value_list(dict_rows, header)

            insert_to_str = '''
                INSERT INTO {0} ({1}) VALUES ({2})
            '''.format(tb_name, ', '.join(header), '?,' * (len(header) - 1) + '?')

            db_con.execute(f"DELETE FROM {tb_name}")
            db_con.executemany(insert_to_str, db_value)

    def create_value_list(self, dict_rows, header):
        db_value = []

        for row in dict_rows:
            normalized_rows = self.normalize_rows(row, header)
            db_value.append(tuple(normalized_rows))

        return db_value

    @staticmethod
    def create_tables(db_con):
        f: os.DirEntry
        for f in os.scandir(DB_SCHEMA):
            logging.info(f"Creating table using {f.name}")

            with open(f.path, 'r') as f_schema:
                db_con.executescript(f_schema.read())

    @staticmethod
    def create_view(db_con):
        f: os.DirEntry
        for f in os.scandir(DB_VIEW):
            logging.info(f"Creating view of UPIT: {f.name}")

            with open(f.path, 'r') as upit_view:
                db_con.executescript(upit_view.read())

    @staticmethod
    def normalize_rows(row, header):
        normalized_rows = []

        for col in header:

            if row[col] and row[col].isdigit():
                normalized_rows.append(int(row[col]))

            elif row[col].strip() == '':
                normalized_rows.append(None)

            else:
                normalized_rows.append(row[col])

        return normalized_rows
