DROP TABLE IF EXISTS upit_process;
CREATE TABLE upit_process
(
    Process_ID   TEXT PRIMARY KEY,
    Process_Name TEXT,
    Project_ID   INTEGER,
    Project_Name TEXT
);