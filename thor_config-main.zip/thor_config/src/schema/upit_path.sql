DROP TABLE IF EXISTS upit_path;
CREATE TABLE upit_path
(
    Path_ID   INTEGER PRIMARY KEY,
    Path_Info TEXT
);