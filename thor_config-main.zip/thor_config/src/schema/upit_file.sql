DROP TABLE IF EXISTS upit_file;
CREATE TABLE upit_file
(
    File_ID                INTEGER,
    Pattern_ID             INTEGER,
    Project_ID             INTEGER,
    Process_ID             TEXT,
    File_Name              TEXT,
    Table_Name             TEXT,
    Column_number          INTEGER,
    Path_ID                INTEGER,
    Delete_flag_fileLevel  INTEGER,
    Key_column             TEXT,
    Key_column_Value       TEXT,
    Delete_flag_TableLevel INTEGER,
    File_SP_EtoT           TEXT,
    Table_SP_TtoL          TEXT,
    Process_SP_LtoODS      TEXT,
    File_mandatory_flag    INTEGER,
    Enable_Flag            INTEGER,
    PRIMARY KEY (File_ID, Process_ID, Project_ID)
);