DROP TABLE IF EXISTS upit_pattern;
CREATE TABLE upit_pattern
(
    Pattern_Id   INTEGER PRIMARY KEY,
    Pattern_Name TEXT
);