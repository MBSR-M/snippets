DROP TABLE IF EXISTS upit_report;
CREATE TABLE upit_report
(
    Report_ID          INTEGER,
    Project_ID         INTEGER,
    Process_ID         TEXT,
    Template_File_Name TEXT,
    Template_Path_ID   INTEGER,
    Macro_To_Run       TEXT,
    Output_File_Name   TEXT,
    Output_Path_ID     INTEGER,
    Save_New_File      INTEGER,
    Save_File_WithDate INTEGER,
    Enable_Flag        INTEGER,
    PRIMARY KEY (Report_ID, Process_ID, Project_ID)
);