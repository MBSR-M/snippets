import logging

from tools.db_creator import DbCreator

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')


def cli() -> None:
    DbCreator('build').create_db()


if __name__ == '__main__':
    """python src\\cli.py"""
    cli()
