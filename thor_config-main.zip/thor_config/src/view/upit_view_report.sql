DROP VIEW IF EXISTS upit_view_report;
CREATE VIEW upit_view_report AS
SELECT upr.[Report_ID],
       upr.[Project_ID],
       upr.[Process_ID],
       ups.[Process_Name],
       upr.[Template_File_Name],
       uphi.[Path_Info] AS [Template_File_Path],
       upr.[Macro_To_Run],
       upr.[Output_File_Name],
       upho.[Path_Info] AS [Output_File_Path],
       upr.[Save_New_File],
       upr.[Save_File_WithDate],
       upr.[Enable_Flag]
FROM upit_report upr
         INNER JOIN upit_path uphi ON upr.[Template_Path_ID] = uphi.[Path_ID]
         INNER JOIN upit_path upho ON upr.[Output_Path_ID] = upho.[Path_ID]
         INNER JOIN upit_process ups ON upr.[Process_ID] = ups.[Process_ID]
WHERE upr.[Enable_Flag] = 1
